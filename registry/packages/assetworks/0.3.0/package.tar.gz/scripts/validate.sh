#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KUJO_RUNTIME="${KUJO_BIN:-}"
if [[ -z "$KUJO_RUNTIME" ]]; then KUJO_RUNTIME="$(command -v kujo || true)"; fi
if [[ ! -x "$KUJO_RUNTIME" && -x "$KUJO_RUNTIME.exe" ]]; then KUJO_RUNTIME="$KUJO_RUNTIME.exe"; fi
if [[ ! -x "$KUJO_RUNTIME" ]]; then printf 'assetworks: Kujo runtime not found; set KUJO_BIN.\n' >&2; exit 2; fi
cd "$ROOT"
"$KUJO_RUNTIME" check assetworks.kujo
"$KUJO_RUNTIME" run tests/test.kujo
"$KUJO_RUNTIME" run tests/security_test.kujo
"$KUJO_RUNTIME" run tests/storage_test.kujo
"$KUJO_RUNTIME" run tests/domain_test.kujo
"$KUJO_RUNTIME" run tests/hardening_test.kujo
"$KUJO_RUNTIME" run tests/review_test.kujo
"$KUJO_RUNTIME" run tests/integrity_test.kujo
"$KUJO_RUNTIME" run tests/contracts_test.kujo
"$KUJO_RUNTIME" run tests/authentication_test.kujo
"$KUJO_RUNTIME" run tests/public_authentication_test.kujo
"$KUJO_RUNTIME" run tests/streaming_test.kujo
"$KUJO_RUNTIME" run tests/pagination_test.kujo
"$KUJO_RUNTIME" run tests/sharding_test.kujo
"$KUJO_RUNTIME" run tests/backup_test.kujo
"$KUJO_RUNTIME" run tests/filesystem_test.kujo
KUJO_BIN="$KUJO_RUNTIME" "$KUJO_RUNTIME" run tests/recovery_test.kujo
KUJO_BIN="$KUJO_RUNTIME" bash scripts/contention_benchmark.sh
if [[ -n "${FFMPEG_BIN:-}" && -n "${FFPROBE_BIN:-}" ]]; then
  "$KUJO_RUNTIME" run tests/adapter_test.kujo
elif [[ "${ASSETWORKS_REQUIRE_ADAPTER_TESTS:-0}" == 1 ]]; then
  printf 'adapter verification requires FFMPEG_BIN and FFPROBE_BIN.\n' >&2; exit 1
else
  printf 'Adapter tests not requested; set explicit FFMPEG_BIN and FFPROBE_BIN to verify execution.\n'
fi
while IFS= read -r document; do "$KUJO_RUNTIME" run scripts/validate_json.kujo -- "$document"; done < <(find fixtures schemas -type f -name '*.json' -print | sort)
tmp_state="$(mktemp -d)"; tmp_state="$(cd "$tmp_state" && pwd -P)"; trap 'find "$tmp_state" -depth -delete' EXIT
KUJO_BIN="$KUJO_RUNTIME" ./bin/assetworks --help >/dev/null
version_output="$(KUJO_BIN="$KUJO_RUNTIME" ./bin/assetworks --version --json)"
[[ "$version_output" == *'"ok": true'* ]]
if KUJO_BIN="$KUJO_RUNTIME" ./bin/assetworks --version --bogus >/dev/null 2>&1; then
  printf 'validation failed: version accepted unknown flags.\n' >&2; exit 1
fi
KUJO_BIN="$KUJO_RUNTIME" ./bin/assetworks doctor --state "$tmp_state/state" --json >/dev/null
KUJO_BIN="$KUJO_RUNTIME" "$KUJO_RUNTIME" run scripts/release_smoke.kujo -- "$ROOT"
if grep -REn --include='*.kujo' 'python3|node |\.py\b|\.mjs\b' src tests scripts assetworks.kujo kujo.toml; then
  printf 'assetworks validation failed: foreign runtime dependency reference found.\n' >&2; exit 1
fi
test ! -f package.json && test ! -f requirements.txt && test ! -f go.mod && test ! -f Cargo.toml
badge_line() { grep -En -m 1 "$1" README.md 2>/dev/null | cut -d: -f1 || true; }
version_badge="$(badge_line 'shields.io/badge/version-')"
license_badge="$(badge_line 'shields.io/badge/license-')"
kujo_badge="$(badge_line 'shields.io/badge/built%20with-Kujo-')"
ci_badge="$(badge_line 'actions/workflows/validate.yml/badge.svg')"
if [[ -z "$version_badge" || -z "$license_badge" || -z "$kujo_badge" || -z "$ci_badge" ]] ||
   ! (( version_badge < license_badge && license_badge < kujo_badge && kujo_badge < ci_badge )); then
  printf 'validation failed: README badges must be ordered version, license, built with Kujo, then CI.\n' >&2
  exit 1
fi
if ! grep -Eq '^# Kujo ecosystem local artifact ignore block\.$' .gitignore ||
   ! git check-ignore -q .loop-engineering/loop.yml; then
  printf 'validation failed: the standard Kujo local-artifact ignore block is missing or incomplete.\n' >&2
  exit 1
fi
if [[ -n "$(git ls-files '.loop-engineering/**')" ]]; then
  printf 'validation failed: Loop Engineering evidence must remain local and untracked.\n' >&2
  exit 1
fi
git diff --check -- . ':(exclude).loop-engineering/**'
printf 'assetworks validation passed.\n'
