#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RELAY_TEST_TMP_ROOT="$(cd "${TMPDIR:-/tmp}" && pwd -P)"
export RELAY_STATE_ROOT="${RELAY_STATE_ROOT:-$RELAY_TEST_TMP_ROOT/relay-test-state-${UID:-0}-$$}"
KUJO="${KUJO:-${KUJO_BIN:-$ROOT/../kujo/target/release/kujo}}"
WORK="/tmp/relay-store-workspace"
SPEC="/tmp/relay-store-mission.json"

rm -rf "$WORK" "$RELAY_STATE_ROOT" "$SPEC"
trap 'rm -rf "$WORK" "$RELAY_STATE_ROOT" "$SPEC"' EXIT
mkdir -p "$WORK"
git init -q "$WORK"
git -C "$WORK" config user.email relay@example.invalid
git -C "$WORK" config user.name Relay
touch "$WORK/README.md"
git -C "$WORK" add README.md
git -C "$WORK" commit -qm baseline
ruby -rjson -e 'spec=JSON.parse(File.read(ARGV.fetch(0))); spec["repository"]=ARGV.fetch(1); File.write(ARGV.fetch(2), JSON.generate(spec))' "$ROOT/examples/fixture-mission.json" "$WORK" "$SPEC"

export RELAY_ROOT="$ROOT"
result="$($KUJO run "$ROOT/main.kujo" -- missions run "$SPEC" --fixture --skip-agent-smoke --json)"
grep -q '"status":"completed"' <<<"$result"
run_id="$(printf '%s' "$result" | ruby -rjson -e 'print JSON.parse(STDIN.read)["run"]["run_id"]')"
test -n "$run_id"
second_result="$($KUJO run "$ROOT/main.kujo" -- missions run "$SPEC" --fixture --skip-agent-smoke --json)"
second_run_id="$(printf '%s' "$second_result" | ruby -rjson -e 'print JSON.parse(STDIN.read)["run"]["run_id"]')"
test -n "$second_run_id" && test "$second_run_id" != "$run_id"

run_window="$($KUJO run "$ROOT/main.kujo" -- runs list --limit 1 --json)"
printf '%s' "$run_window" | jq -e '.ok == true and .run_count == 2 and (.runs | length) == 1 and .has_more == true and (.next_after | length) > 0' >/dev/null
run_cursor="$(printf '%s' "$run_window" | jq -r '.next_after')"
next_run_window="$($KUJO run "$ROOT/main.kujo" -- runs list --after "$run_cursor" --limit 1 --json)"
printf '%s' "$next_run_window" | jq -e '.ok == true and .run_count == 2 and .offset == 1 and (.runs | length) == 1 and .has_more == false' >/dev/null
set +e
bad_run_limit="$($KUJO run "$ROOT/main.kujo" -- runs list --limit 4097 --json 2>&1)"
bad_run_limit_status=$?
set -e
test "$bad_run_limit_status" -ne 0
grep -q 'run limit must be between 1 and 4096' <<<"$bad_run_limit"

# A corrupt or tampered cache must not become an arbitrary filesystem read.
printf '%s' '{"attacker":{"run_dir":"/etc","status":"completed"}}' > "$RELAY_STATE_ROOT/index.json"
listed="$($KUJO run "$ROOT/main.kujo" -- runs list --json)"
printf '%s\n' "$listed" > "/tmp/relay-run-list-contract-$$.json"
python3 "$ROOT/scripts/validate_json.py" "$ROOT/schemas/run-bundle.schema.json" "/tmp/relay-run-list-contract-$$.json"
rm -f "/tmp/relay-run-list-contract-$$.json"
grep -q "\"$run_id\"" <<<"$listed"
grep -q '"index_source":"validated_cache_or_rebuild"' <<<"$listed"
printf '%s' "$listed" | jq -e --arg run_id "$run_id" '.runs[$run_id].updated_at != null and .runs[$run_id].updated_at != ""' >/dev/null
if grep -q 'attacker' <<<"$listed"; then
  echo "tampered index entry was trusted" >&2
  exit 1
fi

# The cache must be size-bounded before JSON parsing, not only after a large
# attacker-controlled document has already been loaded.
ruby -e 'path=ARGV.fetch(0); File.write(path, "{\"oversized\":\"" + ("x" * 8388609) + "\"}")' "$RELAY_STATE_ROOT/index.json"
oversized_listed="$($KUJO run "$ROOT/main.kujo" -- runs list --json)"
grep -q "\"$run_id\"" <<<"$oversized_listed"
if grep -q 'oversized' <<<"$oversized_listed"; then
  echo "oversized index entry was trusted" >&2
  exit 1
fi

rebuilt="$($KUJO run "$ROOT/main.kujo" -- runs rebuild --json)"
grep -q '"index_source":"rebuild"' <<<"$rebuilt"
grep -q "\"$run_id\"" <<<"$rebuilt"

# A failed index write must not be reported as a successful rebuild.
mv "$RELAY_STATE_ROOT/index.json" "$RELAY_STATE_ROOT/index.json.persistence-backup"
mkdir "$RELAY_STATE_ROOT/index.json"
set +e
failed_rebuild="$($KUJO run "$ROOT/main.kujo" -- runs rebuild --json 2>&1)"
failed_rebuild_rc=$?
set -e
test "$failed_rebuild_rc" -ne 0
grep -q 'Run index could not be persisted' <<<"$failed_rebuild"
rmdir "$RELAY_STATE_ROOT/index.json"
mv "$RELAY_STATE_ROOT/index.json.persistence-backup" "$RELAY_STATE_ROOT/index.json"

export_path="/tmp/relay-run-export-$run_id.json"
rm -f "$export_path"
exported="$($KUJO run "$ROOT/main.kujo" -- runs export "$run_id" --output "$export_path" --json)"
grep -q '"integrity_valid":true' <<<"$exported"
test -f "$export_path"
jq -e --arg run_id "$run_id" '.format == "relay-run-export-v1" and .run_id == $run_id and .integrity_valid == true and .receipts_valid == true and .receipts_consistent == true and (.events | length) > 0 and (.receipts | length) >= 7 and (.receipts | map(.receipt_id) as $ids | (($ids | unique | length) == ($ids | length)))' "$export_path" >/dev/null
jq -e --arg run_id "$run_id" '.events | all(.metadata.mission_id == "relay-fixture-mission" and .metadata.run_id == $run_id and (.metadata | has("tool")) and (.metadata | has("artifact")) and (.metadata | has("retry_id")) and (.metadata | has("repair_id")))' "$export_path" >/dev/null
python3 "$ROOT/scripts/validate_json.py" "$ROOT/schemas/run-export.schema.json" "$export_path"

run_dir="$RELAY_STATE_ROOT/runs/$run_id"
events_path="$run_dir/events.jsonl"
mv "$events_path" "$events_path.regular"
ln -s /etc/passwd "$events_path"
set +e
symlink_events="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --json 2>&1)"
symlink_rc=$?
set -e
test "$symlink_rc" -ne 0
grep -q 'symbolic-linked' <<<"$symlink_events"
rm "$events_path"
mv "$events_path.regular" "$events_path"

receipts_path="$RELAY_STATE_ROOT/runs/$run_id/receipts.json"
cp "$receipts_path" "$receipts_path.backup"
ruby -rjson -e 'path=ARGV.fetch(0); receipts=JSON.parse(File.read(path)); receipts[0]["status"]="tampered"; File.write(path, JSON.generate(receipts))' "$receipts_path"
set +e
tampered_receipts="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --json 2>&1)"
receipts_rc=$?
set -e
test "$receipts_rc" -ne 0
grep -q '"receipts_valid":false' <<<"$tampered_receipts"
mv "$receipts_path.backup" "$receipts_path"

# The state copy is not a substitute for the persisted receipt evidence file.
# Removing the file must fail inspection instead of silently passing through
# the state.json fallback.
mv "$receipts_path" "$receipts_path.missing"
set +e
missing_receipts="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --json 2>&1)"
missing_receipts_rc=$?
set -e
test "$missing_receipts_rc" -ne 0
grep -q '"receipts_valid":false' <<<"$missing_receipts"
mv "$receipts_path.missing" "$receipts_path"

# Run inspection must fail closed when authoritative state is absent; the
# rebuildable index is not a substitute for the per-run state record.
state_path="$run_dir/state.json"
mv "$state_path" "$state_path.missing"
set +e
missing_state="$($KUJO run "$ROOT/main.kujo" -- runs inspect "$run_id" --json 2>&1)"
missing_state_rc=$?
set -e
test "$missing_state_rc" -ne 0
printf '%s' "$missing_state" | jq -e '.ok == false and .failure_class == "state_store_failure"' >/dev/null
mv "$state_path.missing" "$state_path"

# An index entry with placeholder metadata must not make a run with missing
# authoritative state appear listable. This guards the cache validation path
# against accepting its own fallback values as proof of a real state record.
printf '{"%s":{"run_dir":"%s","mission_id":"","status":"unknown","updated_at":""}}' "$run_id" "$run_dir" > "$RELAY_STATE_ROOT/index.json"
mv "$state_path" "$state_path.missing"
set +e
missing_index_state="$($KUJO run "$ROOT/main.kujo" -- runs list --json 2>&1)"
missing_index_state_rc=$?
set -e
test "$missing_index_state_rc" -ne 0
printf '%s' "$missing_index_state" | jq -e '.ok == false and .failure_class == "state_store_failure"' >/dev/null
mv "$state_path.missing" "$state_path"

inspected="$($KUJO run "$ROOT/main.kujo" -- runs inspect "$run_id" --json)"
printf '%s' "$inspected" | jq -e --arg run_id "$run_id" '.ok == true and .run.run_id == $run_id' >/dev/null

verified="$($KUJO run "$ROOT/main.kujo" -- runs verify "$run_id" --json)"
printf '%s\n' "$verified" > "/tmp/relay-run-verification-contract-$$.json"
python3 "$ROOT/scripts/validate_json.py" "$ROOT/schemas/run-verification.schema.json" "/tmp/relay-run-verification-contract-$$.json"
rm -f "/tmp/relay-run-verification-contract-$$.json"
printf '%s' "$verified" | jq -e --arg run_id "$run_id" '.ok == true and .format == "relay-run-verification-v1" and .run_id == $run_id and .integrity_valid == true and .state_valid == true and .events_valid == true and .receipts_valid == true and .receipts_consistent == true and .changes_valid == true and .evaluations_valid == true and .tool_results_required == false and .tool_results_valid == true and .packet_manifest_required == true and .packet_manifest_valid == true' >/dev/null
printf '%s' "$verified" | jq -e '.report_valid == true' >/dev/null

# PackWrite output is a recursive, integrity-bound artifact rather than only a
# hash of MASTER.md. A changed packet file must invalidate verification.
master_path="$run_dir/agent/MASTER.md"
cp "$master_path" "$master_path.packet-backup"
printf '\npacket-integrity-tamper\n' >> "$master_path"
set +e
tampered_packet="$($KUJO run "$ROOT/main.kujo" -- runs verify "$run_id" --json 2>&1)"
tampered_packet_rc=$?
set -e
test "$tampered_packet_rc" -ne 0
printf '%s' "$tampered_packet" | jq -e '.ok == false and .packet_manifest_required == true and .packet_manifest_valid == false and .integrity_valid == false' >/dev/null
mv "$master_path.packet-backup" "$master_path"

# Machine callers can page a verified event stream without requesting the full
# JSONL payload. Integrity is still checked against the complete authoritative
# chain before the window is returned.
window="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --limit 2 --json)"
printf '%s\n' "$window" > "/tmp/relay-event-bundle-contract-$$.json"
python3 "$ROOT/scripts/validate_json.py" "$ROOT/schemas/event-bundle.schema.json" "/tmp/relay-event-bundle-contract-$$.json"
rm -f "/tmp/relay-event-bundle-contract-$$.json"
printf '%s' "$window" | jq -e '.ok == true and .integrity_valid == true and .event_count > 2 and (.events | length) == 2 and .has_more == true and (.next_after | length) > 0 and .events_jsonl == ""' >/dev/null
cursor="$(printf '%s' "$window" | jq -r '.next_after')"
next_window="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --after "$cursor" --limit 2 --json)"
printf '%s' "$next_window" | jq -e '.ok == true and .integrity_valid == true and .offset == 2 and (.events | length) > 0' >/dev/null
set +e
bad_limit="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --limit 4097 --json 2>&1)"
bad_limit_status=$?
set -e
test "$bad_limit_status" -ne 0
grep -q 'event limit must be between 1 and 4096' <<<"$bad_limit"
set +e
zero_limit="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --limit 0 --json 2>&1)"
zero_limit_status=$?
set -e
test "$zero_limit_status" -ne 0
grep -q 'event limit must be between 1 and 4096' <<<"$zero_limit"

# The authoritative state seal must also protect read-side status and
# workspace authority, not only resume and event-sequence checks.
cp "$run_dir/state.json" "$run_dir/state.json.sealed-backup"
ruby -rjson -e 'path=ARGV.fetch(0); state=JSON.parse(File.read(path)); state["status"]="failed"; File.write(path, JSON.generate(state))' "$run_dir/state.json"
set +e
tampered_state_inspect="$($KUJO run "$ROOT/main.kujo" -- runs inspect "$run_id" --json 2>&1)"
tampered_state_rc=$?
set -e
test "$tampered_state_rc" -ne 0
grep -q 'integrity verification failed' <<<"$tampered_state_inspect"
mv "$run_dir/state.json.sealed-backup" "$run_dir/state.json"

# A shape-valid report with the wrong run identity is not valid evidence.
cp "$run_dir/report.json" "$run_dir/report.json.backup"
ruby -rjson -e 'path=ARGV.fetch(0); report=JSON.parse(File.read(path)); report["run_id"]="other-run"; File.write(path, JSON.generate(report))' "$run_dir/report.json"
set +e
tampered_report_verify="$($KUJO run "$ROOT/main.kujo" -- runs verify "$run_id" --json 2>&1)"
tampered_report_rc=$?
set -e
test "$tampered_report_rc" -ne 0
printf '%s' "$tampered_report_verify" | jq -e '.ok == false and .report_valid == false and .integrity_valid == false' >/dev/null
set +e
tampered_report_command="$($KUJO run "$ROOT/main.kujo" -- missions report "$run_id" --json 2>&1)"
tampered_report_command_rc=$?
set -e
test "$tampered_report_command_rc" -ne 0
grep -q 'does not match authoritative state' <<<"$tampered_report_command"
mv "$run_dir/report.json.backup" "$run_dir/report.json"

# The Markdown report is also required evidence for inspection and export.
mv "$run_dir/report.md" "$run_dir/report.md.missing"
set +e
missing_markdown_verify="$($KUJO run "$ROOT/main.kujo" -- runs verify "$run_id" --json 2>&1)"
missing_markdown_rc=$?
set -e
test "$missing_markdown_rc" -ne 0
printf '%s' "$missing_markdown_verify" | jq -e '.ok == false and .report_valid == false' >/dev/null
mv "$run_dir/report.md.missing" "$run_dir/report.md"

# Paused/failed runs may intentionally lack post-verification artifacts. A
# caller must opt into the explicit partial contract; it never claims valid
# evidence and is unavailable for a completed run.
paused="$($KUJO run "$ROOT/main.kujo" -- missions run "$ROOT/examples/fixture-mission.json" --fixture --pause-after-plan --skip-agent-smoke --json)"
printf '%s' "$paused" | jq -e '.ok == true and .run.status == "paused"' >/dev/null
paused_id="$(printf '%s' "$paused" | ruby -rjson -e 'print JSON.parse(STDIN.read)["run"]["run_id"]')"
test -n "$paused_id"
set +e
complete_export="$($KUJO run "$ROOT/main.kujo" -- runs export "$paused_id" --json 2>&1)"
complete_export_rc=$?
set -e
test "$complete_export_rc" -ne 0
grep -q 'run export evidence is incomplete' <<<"$complete_export"
grep -q '"partial_export_available":true' <<<"$complete_export"
partial_export="$($KUJO run "$ROOT/main.kujo" -- runs export "$paused_id" --partial --json)"
printf '%s\n' "$partial_export" > "/tmp/relay-partial-export-contract-$$.json"
python3 "$ROOT/scripts/validate_json.py" "$ROOT/schemas/run-export-partial.schema.json" "/tmp/relay-partial-export-contract-$$.json"
rm -f "/tmp/relay-partial-export-contract-$$.json"
printf '%s' "$partial_export" | jq -e --arg run_id "$paused_id" '.ok == true and .format == "relay-run-export-partial-v1" and .run_id == $run_id and .partial == true and .completeness == "partial" and .integrity_valid == false and .artifact_presence.changes == false and .artifact_presence.evaluations == false and .artifact_presence.report == true and .changes == null and .evaluations == null' >/dev/null

# Run artifact readers must fail closed instead of turning a missing result
# into a successful empty object or array.
changes_path="$run_dir/changes.json"
mv "$changes_path" "$changes_path.missing"
set +e
missing_changes="$($KUJO run "$ROOT/main.kujo" -- runs changes "$run_id" --json 2>&1)"
missing_changes_rc=$?
set -e
test "$missing_changes_rc" -ne 0
grep -q 'run artifact evidence is missing' <<<"$missing_changes"
mv "$changes_path.missing" "$changes_path"

mv "$changes_path" "$changes_path.missing"
set +e
missing_export_changes="$($KUJO run "$ROOT/main.kujo" -- runs export "$run_id" --json 2>&1)"
missing_export_changes_rc=$?
set -e
test "$missing_export_changes_rc" -ne 0
grep -q 'run export evidence is incomplete' <<<"$missing_export_changes"
grep -q '"changes_valid":false' <<<"$missing_export_changes"
mv "$changes_path.missing" "$changes_path"

evaluations_path="$run_dir/evaluations.json"
mv "$evaluations_path" "$evaluations_path.missing"
set +e
missing_evaluations="$($KUJO run "$ROOT/main.kujo" -- runs evaluations "$run_id" --json 2>&1)"
missing_evaluations_rc=$?
set -e
test "$missing_evaluations_rc" -ne 0
grep -q 'run artifact evidence is missing' <<<"$missing_evaluations"
mv "$evaluations_path.missing" "$evaluations_path"

report_path="$run_dir/report.json"
mv "$report_path" "$report_path.missing"
set +e
missing_export_report="$($KUJO run "$ROOT/main.kujo" -- runs export "$run_id" --json 2>&1)"
missing_export_report_rc=$?
set -e
test "$missing_export_report_rc" -ne 0
grep -q 'run export evidence is incomplete' <<<"$missing_export_report"
grep -q '"report_valid":false' <<<"$missing_export_report"
mv "$report_path.missing" "$report_path"

# The authoritative state event list must match the verified JSONL payloads,
# not merely carry the same event IDs. A state-only payload edit is evidence
# divergence and must fail inspection/export.
state_path="$run_dir/state.json"
cp "$state_path" "$state_path.backup"
ruby -rjson -e 'path=ARGV.fetch(0); state=JSON.parse(File.read(path)); state.fetch("events").fetch(0).fetch("payload")["state_only_tampered"]=true; File.write(path, JSON.generate(state))' "$state_path"
set +e
state_divergence="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --json 2>&1)"
state_divergence_rc=$?
set -e
test "$state_divergence_rc" -ne 0
grep -q '"state_consistent":false' <<<"$state_divergence"
mv "$state_path.backup" "$state_path"

cp "$events_path" "$events_path.backup"
# A truncated log must fail closed even when the remaining prefix is internally
# hash-valid, because authoritative state records the expected event sequence.
ruby -e 'path=ARGV.fetch(0); lines=File.readlines(path); lines.pop; File.write(path, lines.join)' "$events_path"
set +e
truncated_events="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --json 2>&1)"
truncated_rc=$?
set -e
test "$truncated_rc" -ne 0
grep -q '"state_consistent":false' <<<"$truncated_events"
mv "$events_path.backup" "$events_path"

# Integrity-sealed event records must fail closed when an on-disk payload is
# modified without recomputing its digest.
ruby -rjson -e 'path=ARGV.fetch(0); lines=File.readlines(path); event=JSON.parse(lines.fetch(0)); event["payload"]["tampered"]=true; lines[0]=JSON.generate(event)+"\n"; File.write(path, lines.join)' "$events_path"
set +e
tampered_events="$($KUJO run "$ROOT/main.kujo" -- runs events "$run_id" --json 2>&1)"
events_rc=$?
set -e
test "$events_rc" -ne 0
grep -q '"integrity_valid":false' <<<"$tampered_events"

set +e
unknown="$($KUJO run "$ROOT/main.kujo" -- runs inspect attacker --json 2>&1)"
rc=$?
set -e
test "$rc" -ne 0
grep -q 'unknown run' <<<"$unknown"

echo "PASS relay store smoke"
