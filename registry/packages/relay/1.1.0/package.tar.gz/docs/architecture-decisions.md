# Architecture Decision Records

These ADRs preserve the context and consequences recorded when each decision landed. Read the concise [current architecture map](architecture.md) first. Later ADRs and the current [command reference](command-reference.md), [compatibility policy](compatibility.md), and [integration matrix](integration-matrix.md) supersede earlier forward-looking statements where the implementation has since advanced.

## ADR-001: New composition repository

Context: Dispatch, Agents SDK, and the workflow kits each own adjacent but different concerns. Decision: create `relay` as a thin composition/runtime repository. Rationale: adding mission coordination to any one subsystem would blur ownership. Consequence: adapters must preserve upstream contracts and report unavailable integrations honestly. Rejected: replacing Dispatch or embedding a second provider SDK.

## ADR-002: Library-first runtime with thin CLI

Context: Paperclip, Hermes, CI, MCP, and humans need the same operation surface. Decision: `src/runtime.kujo` owns state transitions and evidence; `src/cli.kujo` only parses and renders. Rationale: machine callers should not depend on terminal prose. Consequence: the runtime's JSON state is the integration boundary.

## ADR-003: Explicit mission/run vocabulary

Context: existing tools use run, workflow, task, packet, and report with distinct meanings. Decision: mission is the requested bounded objective; run is one execution; workflow is the selected step template. Rationale: matches Dispatch and RunLedger without collapsing their ownership.

## ADR-004: Adapter composition over copied implementations

Context: Kujo currently has no stable cross-repository package import contract for these repos. Decision: use narrow subprocess adapters plus one AI SDK bridge. Rationale: avoids a third provider/tool contract and proves the actual CLIs. Consequence: process startup and path configuration are explicit risks.

## ADR-005: Watchdog is the live AI route

Context: Watchdog owns proxying and telemetry; AI SDK owns normalized provider calls. Decision: live requests use `RELAY_WATCHDOG_URL` as the configured compatible base URL, while fixture mode is explicitly marked as a no-network bypass. Rationale: preserves provider independence and avoids an unverified fake telemetry claim.

## ADR-006: Deterministic completion authority

Context: model claims are not evidence. Decision: completion requires action success plus Eval success; ChangeBucket and RunLedger artifacts are persisted regardless. Rationale: follows Eval and Loop Engineering contracts. Consequence: model-generated plans and adaptive repair are deferred.

## ADR-007: Declarative, least-privilege actions

Context: unrestricted shell/filesystem authority is unsafe. Decision: MVP accepts explicit `write_file` and allowlisted `run_command` actions, with approval metadata, realpath workspace checks, deny patterns, and `allow_writes`. Rationale: makes authority inspectable and testable. Consequence: agents cannot yet invent arbitrary tool calls.

## ADR-008: File artifacts plus JSONL events

Context: RunLedger, PackWrite, ChangeBucket, and Eval already produce inspectable files. Decision: keep run state/report JSON, human Markdown, and AgentEvent-compatible JSONL under one run directory, append JSONL with the Kujo append primitive, and record artifact digests. Rationale: simple resume/export, bounded write cost, and machine-readable integrity evidence without a parallel database.

## ADR-009: Explicit subprocess environment

Context: Kujo's process contract supports `inherit_env`, `env_allow`, `env_deny`, and explicit `env` values, while AI and evidence tools need only a small set of runtime variables. Decision: Relay subprocess adapters disable wholesale environment inheritance, allow baseline runtime variables, and add only explicitly supplied variables; live provider credentials are passed to the AI bridge only when selected by `RELAY_API_KEY_ENV`. Rationale: reduce accidental secret exposure and make process authority auditable. Consequence: a host with unusual tool-specific environment requirements must configure an explicit adapter seam rather than relying on ambient state.

## ADR-010: Fail-closed live routing and bounded execution

Context: Watchdog owns live AI telemetry, and mission state needs explicit stop conditions. Decision: live AI calls require `RELAY_WATCHDOG_URL`; fixture mode is the only direct AI SDK bypass. Mission specs may override non-negative step, repair, and token budgets, and budget exhaustion fails the run with evidence. Rationale: prevent silent telemetry bypass and uncontrolled work. Consequence: `doctor` reports missing live prerequisites and operators must choose `--skip-agent-smoke` explicitly when startup validation is intentionally deferred.

## ADR-011: Operator-facing health and probe commands

Context: a showcase needs a truthful first-run path and machine-callable diagnostics. Decision: add `doctor --json` for dependency/agent/route/credential posture and `models probe` for a minimal fixture or configured-live model call. Rationale: make environment failures actionable without introducing a service layer or placeholder command. Consequence: probes remain bounded checks, not provider certification or benchmark results.

## ADR-012: Explicit detached worktree mode

Context: repository-writing missions must not mutate a caller's source checkout by default, while some local workflows need a real Git workspace. Decision: `workspace_mode: "provided"` preserves the explicit existing behavior; `workspace_mode: "worktree"` resolves an immutable starting commit, creates a detached worktree for the run, records source/worktree/commit metadata, and retains the result until an operator runs `missions cleanup <run-id> --confirm`. Rationale: provide a real isolation primitive without pretending it is a container or identity boundary. Consequence: full workcell isolation, rollback-on-failure, and crash recovery remain follow-up work; cleanup is destructive and therefore explicit.

## ADR-013: Forward streaming and Watchdog proxy authorization through the AI SDK

Context: Relay's stream flag previously stopped at the runtime boundary, and authenticated Watchdog proxy routes need a header without exposing the proxy token in the model request payload. Decision: Relay passes `stream` and optional `X-Watchdog-Proxy-Token` request headers through the existing AI SDK options boundary; the token is injected only into the bounded bridge environment. Rationale: preserve provider independence and keep Watchdog ownership of proxy authentication. Consequence: fixture chat emits normalized JSONL, while true live provider and Watchdog correlation remain environment-dependent.

## ADR-014: Per-run state is authoritative over the run index

Context: a shared JSON index can be malformed, torn, stale, or last-writer-wins under concurrent local processes. Decision: treat `.relay/runs/<run-id>/state.json` as authoritative, validate cached index paths, rebuild from safe run directories when the cache is invalid or incomplete, and expose `runs rebuild`. Rationale: improve recovery without inventing a second database before a locking/storage contract is selected. Consequence: the cache is self-healing but not yet a full multi-process transaction store.

## ADR-015: Explicit mission resource budgets

Context: bounded action count and tokens do not bound repository file writes, command output, or command lifetime. Decision: add positive output/write byte budgets capped at 8 MiB and command timeout validation capped at ten minutes; preserve truncation markers in action evidence. Rationale: reduce denial-of-service and oversized-artifact risk while keeping evidence inspectable. Consequence: missions needing larger limits require a deliberate future storage/workcell policy rather than silently inheriting unlimited process behavior.

## ADR-016: Opt-in fail-closed Watchdog verification

Context: routing a live AI call through Watchdog is necessary but does not by itself prove that the proxy is healthy or that the request was persisted under the intended Relay run correlation. Decision: when `RELAY_WATCHDOG_VERIFY=true`, Relay calls Watchdog's authenticated health, proxy-configuration, and correlation query endpoints and marks the AI result unsuccessful if any required check fails. Correlation is sent through the AI SDK bridge as observation headers and the verification adapter returns only sanitized status fields. Rationale: preserve Watchdog ownership of telemetry while making the evidence boundary executable and provider-independent. Consequence: enabled live calls require a reachable, correctly authenticated Watchdog API; returned telemetry rows and summaries are never copied into Relay output. Rejected: direct Watchdog SQLite reads, trusting route metadata alone, or treating a local HTTP stub as production evidence.

## ADR-017: Execute mission commands as direct argv

Context: policy-denying shell metacharacters still left an unnecessary `/bin/sh -lc` interpreter in the repository-writing path. Decision: tokenize the already restricted command string and execute it through `/usr/bin/env -C <workspace> <argv>` without a shell. Rationale: remove shell parsing, command substitution, globbing, and quoting ambiguity from the tool boundary while preserving the existing allowlist. Consequence: mission commands intentionally support simple allowlisted argv forms; shell pipelines and quoted shell expressions are rejected rather than interpreted.

## ADR-018: Lock the rebuildable index and integrity-seal events

Context: per-run state is authoritative, but concurrent index refreshes could still lose cache updates and JSONL event records had no local tamper signal. Decision: serialize index refreshes with an atomic lock directory, validate cached status against each run's state, reject oversized/symlinked index files, and add deterministic SHA-256 integrity fields to AgentEvent-compatible records. Rationale: improve local concurrency and evidence review without prematurely inventing a database or replacing RunLedger. Consequence: the index remains a rebuildable cache, lock recovery is bounded/stale-aware, and durable retention, export signing, and multi-host storage remain follow-up work.

## ADR-020: Keep subprocess resolution explicit and bind tool workers to their workspace

Context: Relay launches Git, Kujo, and sibling ecosystem tools through bounded subprocess adapters, while the Agents SDK bridge delegates tool calls to a worker process. An inherited PATH and a command-line-only capability made executable substitution and worker-scope confusion harder to audit. Decision: bounded subprocess environments use a fixed system PATH, worker capabilities are passed through the child environment rather than argv, and the capability digest binds run ID, session ID, workspace, and worker purpose. Agent tool calls also have a validated 16-call ceiling and mission-configured limit. Rationale: reduce PATH hijacking and prevent a capability issued for one mission workspace from being replayed against another. Consequence: custom executable locations must be configured through absolute adapter paths, and provider-generated tool planning remains deferred.

## ADR-021: Verify event chains before machine export

Context: individual AgentEvent hashes detect payload mutation, but consumers could still read a reordered, duplicated, truncated, or malformed JSONL stream as if it were valid evidence. Decision: `runs events` parses and verifies event hashes, parent ordering, and unique IDs; `runs export` refuses invalid logs and emits a versioned bundle containing verified events, state, changes, evaluations, and report data. Rationale: give Paperclip, CI, and future machine callers a truthful evidence boundary without inventing a second event store. Consequence: tampered or partially written logs fail closed; signed export and durable retention remain future work.

## ADR-022: Treat event-log completeness as part of evidence validity

Context: a valid hash chain can still be a truncated prefix after a crash or partial copy. Decision: `runs events` and `runs export` compare the parsed event IDs and order with authoritative `state.events`, enforce an 8 MiB inspection bound, and fail closed on missing, oversized, malformed, or sequence-inconsistent logs. Rationale: prevent machine callers from mistaking a valid prefix for a complete run. Consequence: a crash between event append and state persistence is surfaced as an evidence inconsistency for repair rather than silently accepted; durable append-only storage remains future work.

## ADR-023: Put execution context in every Relay event

Context: RunLedger, model, provider, workflow, and packet revision were present in run state but not consistently attached to each AgentEvent-compatible record, making downstream correlation more expensive. Decision: Relay enriches event metadata with workflow, model, provider, packet revision, and RunLedger run ID before resealing the event integrity hash. Rationale: make machine inspection and future Paperclip/Hermes adapters able to correlate evidence without reconstructing context from neighboring files. Consequence: lifecycle receipt IDs now cover the core artifact path; richer retry, escalation, approval, cancellation, and adaptive-repair IDs remain future work.

## ADR-019: Use the Agents SDK Tool Registry behind a Relay policy worker

Context: explicit Relay actions provide deterministic authority, but they do not prove that an Agents SDK agent can request a tool while preserving Relay's workspace and command policy. Decision: mission specs may opt into a narrow `agent_tools` list. A Kujo bridge registers the existing Agents SDK Tool Registry and approval provider, then delegates each approved call to a separate Relay worker process through a capability-bound JSON request. The worker calls Relay's existing policy-checked tool executor; the mission records the summarized result as a signed lifecycle event. Rationale: reuse Agents SDK registry and approval contracts without moving repository authority into the SDK or creating a competing tool protocol. Consequence: one isolated fixture mission and approval-denial path are proven, while provider-driven model tool planning, cancellation, richer tool-result artifacts, and authenticated service mode remain open. Rejected: giving the Agents SDK direct filesystem/shell access, or duplicating its registry and approval semantics inside Relay.

## ADR-094 — Opt-in provider-generated tool planning remains inside the existing authority chain

Context: the AI SDK already normalizes OpenAI-compatible `tool_calls`, while Relay's Agents SDK bridge previously accepted only fixture- or mission-declared calls. That left the normal provider response path disconnected from the real tool registry. Decision: add `agent_tool_mode: "provider"` plus an explicit `agent_tool_allowlist`; Relay sends only generated schemas through Watchdog and AI SDK, normalizes provider arguments, records a typed tool-plan receipt/event, and forwards the calls to the existing Agents SDK registry and Relay policy worker. Rationale: close the provider-to-tool functionality gap without granting model or SDK direct filesystem authority or introducing a second tool protocol. Consequences: provider-enabled missions are more useful and auditable, but live provider behavior remains provider-specific and requires external evidence; planning is disabled by default and malformed calls fail closed. Rejected: allowing arbitrary model-named tools, executing provider calls directly in Relay, or using the declared-call list as an implicit allowlist.

## ADR-024: Use a Relay receipt index over canonical ecosystem artifacts

Context: event metadata correlated runs, but tool, model, packet, ChangeBucket, Eval, and RunLedger evidence still required consumers to infer relationships from filenames and neighboring events. Decision: Relay emits a versioned, SHA-256-sealed `RelayReceipt` index at `receipts.json`; each receipt names its run, step, agent, artifact reference, status, and source payload, and relevant lifecycle events carry the receipt ID. `runs events` and `runs export` verify receipt integrity and exact agreement with authoritative run state before returning evidence. Rationale: provide typed cross-artifact references without replacing RunLedger, PackWrite, ChangeBucket, or Eval as canonical owners. Consequence: receipts improve local correlation and tamper detection, while signed export, durable retention, provider-generated tool loops, and richer retry/repair receipts remain future work. Rejected: copying upstream artifact stores into Relay or treating the receipt index as an independent source of truth.

## ADR-025: Allow only explicit read-only Git argv profiles

Context: shell-free execution removed shell injection, but broad string-prefix checks could still permit unintended Git subcommands or arbitrary pathspec reads through an otherwise approved `git` command. Decision: tokenize mission commands and allow only exact read-only Git subcommands with a small option catalog; reject positional pathspecs, unknown options, destructive subcommands, and script arguments. Rationale: least privilege must constrain the resulting argv, not only the human-readable prefix. Consequence: repository missions can inspect status, bounded diffs, logs, shows, and safe metadata, while advanced Git queries must be added as explicit policy profiles with tests. Rejected: accepting arbitrary read-only-looking Git strings or returning to shell parsing.

## ADR-026: Use bounded lock backoff for the rebuildable index

Context: the local index is a validated cache and concurrent `runs rebuild` callers can briefly contend on its atomic lock. Immediate failure wastes otherwise safe work, while an unbounded wait would hide a stuck writer and weaken operational predictability. Decision: `persist_run_index` retries lock acquisition at most four times with a 20 ms linear backoff; stale-lock recovery remains bounded and authoritative per-run state remains the source of truth. Rationale: improve local multi-process throughput without turning the cache into a durable database or an uncontrolled synchronization point. Consequence: lock stress now has executable evidence; durable multi-host storage, retention, and crash recovery remain separate work.

## ADR-027: Add a bounded live run-event watcher

Context: file-backed AgentEvent JSONL is durable and verifiable, but operators and machine callers otherwise must poll or wait for a mission command to finish before seeing progress. Decision: add `runs watch <run-id>` as a bounded polling watcher that emits each complete AgentEvent-compatible record once, verifies the hash chain on every poll, waits through the final state/file handoff race, and fails closed on malformed, oversized, or inconsistent terminal evidence. Rationale: provide a useful live observation surface without introducing a daemon, second event store, or unbounded follow process. Consequence: local callers can stream mission progress with explicit timeout/poll bounds; true remote sinks, durable subscriptions, and multi-host event fan-out remain future work.

## ADR-028: Record bounded adapter duration metrics

Context: Relay preserved token usage and provider correlation but did not expose elapsed time for AI bridge calls, tool commands, or evidence adapters, making performance regressions and queue/provider comparisons harder to inspect. Decision: every bounded subprocess adapter records non-negative `duration_ms`; AI telemetry and action evidence expose the elapsed value, while existing canonical RunLedger/Watchdog ownership remains unchanged. Rationale: add useful performance evidence without a second metrics backend or unbounded high-cardinality logging. Consequence: local reports can compare call/tool/evidence latency; token cost, queue time, provider availability, and durable metrics aggregation remain future work.

## ADR-029: Add read-only run artifact size inspection

Context: Relay had bounded duration evidence but no machine-readable way to inspect the local disk footprint of a run before future retention or export work. Decision: add `runs sizes <run-id>` as a read-only inventory over the persisted run artifact directory, always exclude and report the repository `workspace` subtree, reject symbolic links and unsupported paths, and cap the inventory at 4096 files. Rationale: provide safe operational evidence without inventing a retention owner or scanning an unbounded repository checkout. Consequence: operators and CI can compare local artifact footprints, while rotation, compaction, retention, transfer metrics, and durable multi-host storage remain deferred. Rejected: deletion/retention flags in the CLI, following links, or counting workspace bytes as Relay-owned evidence.

## ADR-030: Use cooperative cancellation at action boundaries

Context: Relay exposed pause/resume but had no truthful `missions cancel` operation, while forcibly killing arbitrary provider or repository subprocesses would create unsafe partial-work and evidence races. Decision: `missions cancel <run-id>` writes a validated request artifact; the runtime checks it before and after each declared action, transitions the run to `cancelled`, emits a sealed `run_cancelled` event, finishes RunLedger evidence, and preserves the request. Paused runs can transition immediately. Rationale: provide a useful machine-facing stop control without pretending to implement process-group termination, rollback, distributed cancellation, or identity-aware authorization. Consequence: a currently-running external action may finish before cancellation takes effect; callers must inspect terminal evidence and use explicit cleanup. Rejected: silently marking a running process cancelled, killing arbitrary descendants, or treating cancellation as rollback.

## ADR-031: Reject symbolic-linked evidence files

Context: Relay already rejected symbolic-linked run directories and size-inventory entries, but generic JSON reads, JSONL appends, and event inspection could otherwise follow an attacker-replaced artifact symlink. Decision: `read_json_or` and `append_jsonl` reject symbolic links/non-regular files, while `runs watch`, `runs events`, and `runs export` fail closed when `events.jsonl` is symbolic-linked or non-regular. Rationale: prevent evidence redirection and accidental writes outside the run root while preserving the existing atomic write path. Consequence: symlinked evidence is surfaced as invalid and must be repaired; stronger kernel-level no-follow primitives, multi-user ownership, and durable storage isolation remain platform work. Rejected: following links because their target appears readable or trusting only the run-directory path.

## ADR-032: Bound mission-spec files before parsing

Context: Relay bounded action count, budgets, and tool calls but accepted any caller-provided mission path and parsed its entire contents before persistence. Decision: `load_spec` requires an existing regular non-symbolic file no larger than 1 MiB before JSON parsing; larger or symbolic-linked inputs fail closed with explicit errors. Rationale: bound memory, parse, prompt, and state amplification at the first input boundary without constraining repository workspaces or legitimate mission actions. Consequence: larger workflows must use a future versioned packet or durable workflow owner; authenticated input identity and schema negotiation remain deferred. Rejected: parsing first and relying only on action-count limits, or silently truncating a mission document.

## ADR-033: Bound persisted JSON before parsing

Context: mission inputs and event logs had size checks, but the run index,
lock-owner metadata, and state/evidence readers could still parse a large
attacker-controlled JSON document before a later validation noticed its size.
Decision: use a bounded JSON reader at persisted-store boundaries. This
historical decision initially assigned index files 8 MiB and run state 64 MiB;
ADR-122 corrects those values to the pinned runtime's actual 1 MiB JSON parser
ceiling. Lock owners retain a narrower 64 KiB cap before
parsing. Oversized inputs fail closed and let the authoritative rebuild or
caller-facing error path decide the outcome. Rationale: make the memory bound
apply before parsing, not merely after parsing. Consequence: corrupted or
larger future stores need an explicit migration/retention owner; limits do not
claim durable multi-host storage. Rejected: trusting the JSON parser to absorb
arbitrary cache growth or silently truncating evidence.

## ADR-034: Restrict model fallback to retryable failures

Context: `RELAY_FALLBACK_MODEL` previously retried every failed primary call,
including authentication, policy, Watchdog-route, and malformed-bridge errors.
Decision: attempt fallback only for explicitly bounded transient or model
capability failures; skip it for non-retryable failures and record the reason
in `relay_telemetry`. Rationale: avoid duplicate unauthorized/expensive calls,
preserve policy failures, and make routing behavior predictable. Consequence:
providers that expose novel retryable codes require an explicit adapter update;
adaptive routing remains deferred. Rejected: blanket fallback on every error or
silently hiding the second call.

## ADR-035: Bind Agents SDK worker paths to trusted environment

Context: the Agents SDK bridge used payload-supplied `relay_root` and
`kujo_bin` values to launch the policy worker, while its capability digest
covered the workspace but not the executable or source root. Decision: worker
launch paths must match trusted `RELAY_ROOT` and `KUJO_BIN` environment values;
the bridge rejects mismatches and missing or symbolic-linked Relay roots before
launching. Rationale: prevent a caller-controlled payload from redirecting an
otherwise valid workspace capability into another runtime or source tree.
Consequence: embedding applications must configure worker paths in the
process environment, and authenticated service ownership remains deferred.
Rejected: trusting payload paths because the workspace capability is valid, or
adding executable paths to a user-controlled mission packet.

## ADR-036: Bound environment-backed bridge payloads before parsing

Context: the AI bridge, Agents SDK bridge, and tool-worker CLI receive JSON
through environment variables, but those machine-callable boundaries parsed
the entire value and malformed JSON could surface as raw interpreter failures.
Decision: cap each environment-backed payload at 128 KiB before parsing and
return structured invalid or oversized-payload errors; larger future requests
must use an authenticated file or socket transport. Rationale: enforce a
pre-parse resource bound that is practical below common process environment
limits and make machine failures stable. Consequence: very large prompts or
tool plans need a future transport contract; the mission-file boundary remains
1 MiB because it is file-backed. Rejected: relying on OS argument limits,
parsing unbounded environment strings, or silently truncating JSON.

## ADR-037: Validate Watchdog routes before live AI invocation

Context: Relay already required a Watchdog URL for live calls, but the adapter
could pass a malformed scheme or credential-bearing URL onward to the AI SDK
before Watchdog verification ran. Decision: live calls require an HTTP(S)
Watchdog URL without embedded userinfo before any provider subprocess starts;
invalid routes return a structured `invalid_watchdog_route` failure. Rationale:
keep provider routing and credential-bearing endpoints behind the Relay safety
boundary and make route failures deterministic. Consequence: local deployments
must use a plain configured URL and put authentication in the explicit token
environment seams; custom schemes require a future adapter contract. Rejected:
letting the downstream SDK decide route safety or validating only when optional
Watchdog verification is enabled.

## ADR-038: Require HTTPS for non-loopback Watchdog routes

Context: route validation rejected malformed schemes and embedded credentials,
but accepted cleartext HTTP for remote Watchdog hosts. Decision: allow HTTP
only for localhost and loopback IPv4/IPv6 endpoints used by local development;
require HTTPS for every non-loopback Watchdog host. Rationale: prevent remote
AI traffic and bearer-token headers from crossing a cleartext route while
preserving the established local Watchdog fixture path. Consequence: remote
deployments need TLS termination and future route discovery must preserve this
policy; certificate pinning and mTLS remain deferred. Rejected: allowing all
HTTP because the URL has no userinfo, or silently upgrading the configured
endpoint.

## ADR-039: Keep Watchdog route posture secret-safe

Context: `doctor --json` treated any non-empty Watchdog URL as configured and
returned the raw value, even when route validation would reject it. Decision:
reuse the Watchdog route policy in doctor, require a valid route for live
readiness, and report only configured/valid/scheme/reason fields without the
raw URL. Rationale: operator diagnostics must agree with the live invocation
boundary and must not echo credentials or remote route details into CI logs.
Consequence: operators diagnose route classes rather than copying a URL from
doctor output; authenticated route discovery and certificate verification
remain deferred. Rejected: reporting the URL for convenience or making doctor
less strict than the live AI path.

## ADR-043: Fail closed when evidence persistence fails

Context: state, receipt, and event writes returned failure values that callers
ignored, allowing a mission to continue toward a successful terminal status
with incomplete evidence. Decision: mark persistence failures as
`evidence_failure`, force failed status at the next state save, propagate
receipt failures through the runtime, and delete temporary files after failed
atomic writes. Rationale: a successful result without its authoritative
evidence is not a truthful mission result. Consequence: local disk failures
fail missions rather than silently degrading evidence; fsync, append-only
durability, retention, and crash recovery remain deferred. Rejected: logging a
warning and returning success or treating the event file as optional.

## ADR-044: Reject symbolic-linked Relay state roots

Context: evidence-file checks rejected symbolic links below a run, but the
`.relay` root and its `runs` directory could still redirect state and index
writes outside the configured Relay root. Decision: validate both state-store
directories before mission creation, execution, CLI inspection/control, and
doctor readiness; return `state_store_failure` without following either link.
Rationale: the state root is an authority boundary, not merely a cache path.
The existing local filesystem model remains compatible while closing the
redirection gap. Consequence: operators must provision real directories or a
future no-follow durable store; authenticated ownership, kernel-level no-follow
writes, and workcell isolation remain deferred. Rejected: relying on per-file
symlink checks or allowing the index rebuild to treat a redirected directory as
empty.

## ADR-045: Keep Watchdog route telemetry posture-only

Context: the Watchdog route boundary already rejected unsafe live URLs and
`doctor --json` avoided echoing them, but successful AI calls copied the raw
`RELAY_WATCHDOG_URL` into `relay_telemetry`, allowing hostnames and any future
route material to spread into run artifacts. Decision: emit only configured,
valid, scheme, and reason posture fields in AI telemetry, matching doctor.
Rationale: telemetry is persisted and machine-forwarded evidence, so it must
share the same non-disclosure boundary as diagnostics. Consequence: operators
lose convenient raw-route replay from a run, while route troubleshooting stays
classifiable; authenticated route discovery and certificate policy remain
deferred. Rejected: relying on downstream redaction or exposing the URL only in
fixture mode.

## ADR-046: Constrain correlation IDs before transport

Context: Relay includes a correlation ID in AI request headers, persisted
telemetry, and the Watchdog request lookup query. The previous normalization
allowed query delimiters and whitespace, so a caller could alter the lookup
parameters or create ambiguous evidence labels. Decision: accept only a
bounded identifier made of alphanumeric characters, hyphens, and underscores;
replace invalid or oversized values with a generated safe ID. Rationale: the
same identifier must be safe across HTTP headers, URLs, logs, and evidence.
Consequence: callers cannot choose arbitrary correlation syntax; authenticated
caller identity and distributed correlation ownership remain deferred. Rejected:
URL-encoding a permissive identifier or sanitizing only at the Watchdog query
boundary.

## ADR-048: Normalize Watchdog transport failures

Context: `doctor --json` and optional live verification surfaced the HTTP
library's raw request error. On an unreachable route that error included the
configured Watchdog URL, bypassing the posture-only route contract. Decision:
return the stable `Watchdog HTTP request failed` class with status and logical
endpoint path, but never the transport exception text or constructed URL.
Rationale: diagnostics and persisted verification evidence are machine-facing
outputs and must not disclose route material merely because a connection
failed. Consequence: operators get a bounded failure class and status while
transport-specific debugging requires local logs or an explicitly authorized
diagnostic channel. Rejected: applying string redaction to arbitrary HTTP
errors or exposing raw errors only when the route is valid.

## ADR-047: Make concurrent store probes race-safe

Context: concurrent index rebuilds could remove `.relay/.index.lock` between a
presence check and `path_is_symlink`, producing an interpreter error instead of
retrying or reporting bounded contention. Decision: centralize a tolerant
symlink probe that treats a path disappearing during inspection as absent, and
use it throughout the rebuildable store boundary. Rationale: a local
multi-process cache must fail as a bounded contention or recovery case, not
crash because of a normal lock lifecycle race. Consequence: a concurrent
disappearance is re-evaluated by the existing bounded lock protocol; durable
multi-host ownership and a database-backed store remain deferred. Rejected:
adding sleeps around the race or treating interpreter failures as acceptable
stress-test noise.

## ADR-040: Bind resumed actions to checkpoint integrity

Context: a paused run persisted its mission and workspace state, but resume
could trust a locally modified `state.json` and execute actions against a
substituted repository or with altered budgets. Decision: persist a SHA-256
digest of the mission policy and, before resume, verify run identity, policy
digest, workspace/source/Git identity, effective budgets, event-chain integrity,
and receipt integrity. Rationale: preserve the existing local evidence model
while ensuring a checkpoint cannot silently expand authority before the first
resumed action. Consequence: old paused runs without the digest require a new
run; signed state, multi-user ownership, and durable crash recovery remain
deferred. Rejected: trusting state because the run index points to the correct
directory, or validating only the workspace path after resuming.

## ADR-042: Share checkpoint integrity across operator controls

Context: resume and cleanup had explicit state validation, but pause and cancel
could still mutate a non-terminal run after its persisted policy, workspace, or
evidence state had been edited. Decision: route pause and cancel through the
same checkpoint integrity validator before mutation. Rationale: operator
controls are state transitions with authority consequences, even when they do
not write repository files. Consequence: malformed or legacy state fails closed
for local controls; distributed identity, signed state, and authenticated
control channels remain deferred. Rejected: validating only destructive cleanup
and treating pause/cancel as harmless metadata changes.

## ADR-041: Revalidate state before destructive worktree cleanup

Context: confirmed cleanup invoked `git worktree remove --force` using terminal
state fields, while the state itself could be edited after a run completed.
Decision: before cleanup, verify the mission-policy digest, run identity, source
repository, run-owned worktree path, Git metadata, event chain, and receipts;
reject failures as `state_integrity_failure`. Rationale: confirmation expresses
operator intent but does not authorize a tampered target. Consequence: old
artifacts without the policy digest require migration or manual recovery;
rollback, signed state, and authenticated ownership remain deferred. Rejected:
trusting only the run-directory path or checking the workspace path after
starting Git removal.

## ADR-049: Delegate command cancellation to Kujo process groups

Context: Relay's cooperative cancellation request previously stopped only at
action boundaries. An active command could continue running, and a descendant
that inherited the command's output pipes could keep the mission blocked even
after the direct child was killed. Decision: Relay passes its run-owned
`cancel.request.json` to Kujo's `spawn_process` `cancel_file` option for
mission commands; on Unix, Kujo starts each command in a new process group and
terminates that group on cancellation or timeout. Rationale: Relay owns the
mission state transition and evidence, while Kujo owns process lifecycle and
is the only layer that can reliably terminate descendants. Consequence:
Unix cancellation is bounded for descendant processes, while non-Unix runtimes
retain a direct-child fallback; rollback, workcell ownership, and distributed
cancellation remain deferred. Rejected: Relay-managed shell kill commands,
process-name scans, or claiming cooperative cancellation was sufficient without
an executable descendant test.

## ADR-051: Make dependency readiness type- and symlink-aware

Context: `doctor --json` previously treated any existing path as a healthy
dependency. A directory at an executable path or a symlinked runtime could
therefore appear ready even though the configured dependency identity had not
been verified. Decision: required doctor paths must have their expected file or
directory type and must not be symbolic links; machine output reports
`exists`, `expected_type`, `symlink`, and `safe`. Rationale: fail closed before
live or repository-changing operations and give CI/machine callers an explicit
dependency posture. Consequence: symlink-managed installations must point Relay
at the resolved trusted path; signed manifests, hashes, provenance, and
deployment ownership remain deferred. Rejected: checking only `path_exists`,
following symlinks silently, or treating doctor output as a binary signature.

## ADR-050: Redact structured credentials before evidence persistence

Context: Relay already redacted bearer headers and environment-style secret
assignments, but tool output and adapter diagnostics can contain JSON fields or
provider-native token formats. Decision: extend the shared redaction boundary
to API/access/auth tokens, client secrets, passwords, generic secret fields,
common OpenAI/AWS/GitHub/Slack token forms, and private-key markers before
subprocess or adapter evidence is persisted. Rationale: evidence is copied into
run state, receipts, reports, and machine exports, so relying only on a future
Redact integration would leave a local disclosure path. Consequence: values
matching these patterns are intentionally replaced and full prompt/packet
redaction, secret custody, and tenant-aware policy remain deferred. Rejected:
redacting only `KEY=` assignments, trusting downstream readers to sanitize, or
persisting raw tool output for debugging convenience.

## ADR-052: Preserve cancellation and timeout as distinct action failures

Context: an active command cancelled through Kujo or terminated by its timeout
was persisted with the generic `tool_failure` class, even though the runtime
already had separate `cancelled` and `timed_out` signals. Decision: map those
signals to `cancelled` and `timeout` action failure classes and classify
explicit cancellation codes as `cancelled`. Rationale: retry policy, operator
reports, RunLedger evidence, and machine callers must distinguish an expected
stop from a tool defect. Consequence: downstream consumers must handle the
more precise classes; provider-specific taxonomies and typed retry/repair
receipts remain deferred. Rejected: inferring failure type from exit code or
collapsing cancellation and timeout into generic tool failure.

## ADR-053: Prove timeout descendant termination separately

Context: cancellation had a descendant-safe smoke, but timeout termination was
only indirectly covered by the Kujo runtime test and action timeout validation.
Decision: maintain a dedicated Relay timeout smoke that runs a 30-second
descendant task with a one-second action timeout, requires bounded return,
typed `timeout` evidence, and no remaining slow process. Rationale: timeout is
an independent safety boundary and can regress even when operator cancellation
works. Consequence: the local Unix guarantee is executable; non-Unix process
trees, rollback-aware workcells, and cross-host process ownership remain open.
Rejected: treating timeout validation as proof of termination or reusing only
the cancellation request smoke.

## ADR-054: Incrementally parse bounded live event logs

Context: `runs watch` reread and reparsed the entire bounded JSONL event log on
every poll. Long-running missions therefore paid repeated JSON parsing work as
the event stream grew. Decision: retain the parsed event array and previous raw
prefix, parse only newly appended complete lines plus any previously incomplete
line, reject replacement/truncation, and continue validating the full event
chain on every poll. Rationale: reduce watcher CPU while preserving the
append-only evidence and tamper-detection contract. Consequence: the watcher
still retains the bounded raw file and parsed events in memory; remote sinks,
durable subscriptions, and multi-host fan-out remain deferred. Rejected:
skipping integrity validation when the stream changes or introducing a second
event store.

## ADR-055: Fail closed when a watched event log disappears

Context: `runs watch` retained parsed events after reading `events.jsonl`, so a
later deletion could otherwise leave the watcher with a stale in-memory stream
and allow a terminal state to appear complete. Decision: remember that the
event file was observed and return an explicit watcher error if it disappears;
also avoid repeating the full chain walk during unchanged polls. Rationale:
the event file is part of the run's evidence boundary, and disappearance is
evidence loss rather than a normal empty poll. Consequence: local filesystem
watching fails closed on deletion, while authenticated remote subscriptions,
durable event ownership, and no-follow kernel primitives remain deferred.
Rejected: treating deletion as an empty stream, trusting the cached events, or
hashing the full history on every idle poll.

## ADR-056: Seal execution context into every Relay receipt

Context: Relay receipts already named the artifact kind, run, step, agent, and
artifact reference, but machine consumers still had to reconstruct workflow,
model, provider, packet, attempt, repair, RunLedger, and AI-correlation context
from state or neighboring events. Decision: attach the available execution
context metadata to every receipt and include that metadata in its SHA-256
integrity input. Rationale: make each receipt independently useful for
inspection, export, Paperclip/Hermes adapters, and incident analysis without
duplicating upstream artifact ownership. Consequence: older receipts without
metadata remain readable only under their existing contract, while signed
exports, typed retry/repair IDs, and durable retention remain deferred.
Rejected: trusting event adjacency, copying full run state into each receipt,
or adding a second telemetry store.

## ADR-057: Probe dependency versions during doctor readiness

Context: filesystem type and symlink checks established dependency path posture,
but a present executable could still be stale, miswired, or resolve the wrong
Kujo-native package when invoked from a different working directory. Decision:
`doctor --json` runs bounded `--version`/`version` probes for Kujo, PackWrite,
RunLedger, and ChangeBucket with explicit environments and configurable sibling
roots; required probe failures make readiness fail closed. Rationale: catch
broken or stale local composition before a mission mutates a repository while
keeping the probe output machine-readable and provider-independent. Consequence:
doctor performs a few bounded subprocesses and does not yet verify signed
provenance, hashes, semantic compatibility ranges, or deployment ownership.
Rejected: trusting executable existence, parsing README versions, or silently
running version probes with the host environment.

## ADR-058: Support optional executable hash pinning in doctor

Context: bounded version probes catch stale or miswired executables, but a
version string alone cannot identify the exact binary used by a deployment.
Decision: allow operators to configure SHA-256 pins for the Kujo, PackWrite,
RunLedger, and ChangeBucket executables; validate digest format, reject
symlinks, and fail required doctor readiness on mismatch. Rationale: provide a
small, provider-independent integrity control without inventing a signing or
deployment-ownership system. Consequence: pins require operator rotation when
dependencies are upgraded and remain weaker than signed provenance, semantic
compatibility ranges, and attestation. Rejected: silently hashing without an
operator-provided expectation, accepting arbitrary digest formats, or treating
version output as binary identity.

## ADR-059: Deny injection-capable provider credential environment names

Context: `RELAY_API_KEY_ENV` lets an operator select the environment variable
that carries a provider credential, but several otherwise valid-looking names
also control dynamic loading, interpreter startup, Git configuration, or
certificate trust. Passing those names to the AI bridge could widen authority
before provider code runs. Decision: reject dynamic-loader prefixes and a
bounded denylist covering interpreter, Git override, and trust-store variables
before bridge spawn. Rationale: keep provider selection flexible while making
the credential-environment boundary explicit and fail closed. Consequence:
operators using one of the denied names must choose a dedicated uppercase
credential variable; this remains a local process boundary, not a secret
broker or authenticated tenancy system. Rejected: inheriting arbitrary host
environment variables, allowing all uppercase names, or attempting to sanitize
the provider after process startup.

## ADR-060: Treat symlink probe errors as unsafe

Context: Relay used a shared symlink helper at evidence, workspace, dependency,
control, and Agents SDK worker boundaries, but an exception from the underlying
filesystem probe was previously converted to `false`, which could be mistaken
for proof that a path was not a symlink. Decision: return `false` only when a
path is absent or the successful probe confirms no symlink; return `true` when
the runtime cannot inspect the supplied path, and use this helper throughout
Relay's path-sensitive checks. Rationale: an inspection failure is an
authority failure, not a safe state, and one consistent helper reduces drift
between CLI, doctor, runtime, and worker code. Consequence: transient or
permission-related filesystem probe failures fail closed and may require an
operator retry; missing paths retain their prior absent-path semantics. This
does not replace kernel no-follow primitives or multi-user ownership. Rejected:
treating probe exceptions as non-symlinks, duplicating ad hoc try/catch logic,
or silently continuing with an unverified path.

## ADR-061: Check symlink metadata before existence semantics

Context: a fail-closed helper that called `path_exists` before
`path_is_symlink` could misclassify a dangling symbolic link as an absent
path on runtimes whose ordinary existence check follows links. Decision: ask
the runtime's symlink-metadata primitive first; only after a probe exception,
classify a genuinely missing path as absent, and treat all other probe errors
as unsafe. Add a dedicated dangling-link smoke and expose the helper through
all path-sensitive Relay boundaries. Rationale: broken links are still
redirectable filesystem objects and must not bypass evidence or authority
checks. Consequence: dangling links fail closed and missing-path behavior is
preserved; kernel no-follow primitives and authenticated multi-user ownership
remain future work. Rejected: existence-first checks, treating broken links as
missing, or duplicating the ordering logic across callers.

## ADR-062: Reject symlinked state-store parent components

Context: checking only `.relay` and `.relay/runs` protects direct symlink
redirection but leaves a symlinked existing parent directory able to redirect
the entire evidence store while the final paths remain ordinary names.
Decision: walk each path component of the state root and runs root, query
symlink metadata for every existing component, explicitly reject `..` through
`path_has_parent_component`, and fail closed on probe errors. The reusable
symlink walk may inspect normalized sibling paths containing `..`; only the
state-store owner applies the stricter parent-component policy. Rationale: the
state store is Relay's local evidence and control
authority; parent redirection must be rejected before index or run access.
Consequence: unusual relative roots containing `..` and symlinked parent
directories require an explicit safe path, while missing non-symlink components
remain creatable. Kernel no-follow operations, authenticated ownership, and
durable multi-host storage remain open. Rejected: validating only the leaf,
resolving symlinks and trusting the resolved target, or silently canonicalizing
an operator-supplied path.

## ADR-063: Extend parent-component protection to readiness and worker boundaries

Context: the state-store walk closed parent-directory redirection for Relay's
evidence paths, but `doctor` dependency checks and the Agents SDK worker-root
binding still validated only the final executable or root directory. A symlinked
parent could therefore redirect a dependency probe or trusted worker source
before the leaf-level check ran. Decision: reuse
`path_has_symlink_component` in doctor path/dependency checks and in the trusted
Agents SDK worker-root and `main.kujo` validation. Add a dependency-parent
probe to the contract and symlink smoke. Rationale: all path-sensitive trust
boundaries should share one fail-closed component policy rather than relying on
caller-specific leaf checks. Consequence: symlinked parent paths are rejected
for readiness and worker execution, including platform-managed links; missing
non-symlink components remain valid where creation is expected. Kernel
no-follow primitives, authenticated ownership, and durable multi-host storage
remain open. Rejected: resolving links to a supposedly trusted target, or
maintaining separate parent checks in each caller.

## ADR-064: Probe evidence and control links before existence checks

Context: the shared symlink helper already detected dangling links, but JSON
readers, JSONL append, cancellation polling, and the live event watcher still
called ordinary existence checks first. A dangling link could therefore be
treated as an absent optional artifact, cause an append to target a redirected
location, or make a watcher wait for a timeout instead of rejecting unsafe
evidence. Decision: perform the fail-closed symlink probe first in bounded JSON
reads, JSONL append, cancellation-request polling, event inspection/export,
and each watcher poll; cache the watcher existence result for the rest of that
poll. Rationale: metadata-first behavior must be consistent at every evidence
and control boundary, while the cached existence result removes redundant
filesystem probes from long-running watches. Consequence: dangling links fail
immediately and missing paths retain absent semantics; the watcher performs
one symlink and one existence probe per poll rather than repeating existence
checks. Kernel no-follow operations, authenticated ownership, and durable
multi-host storage remain open. Rejected: treating dangling links as missing,
following them to inspect a target, or retaining separate watcher/read/control
probe orderings.

## ADR-065: Preserve sibling-tool module context in subprocess adapters

Context: Relay launches PackWrite, RunLedger, ChangeBucket, and other Kujo
programs from a caller-controlled working directory. The kernel cwd supplied
through `/usr/bin/env -C` did not update `PWD`, and ChangeBucket's launcher also
requires the Kujo module path for its `from cli` compatibility import. This
could make a dependency import Relay's `src/` tree or fail its version and
ChangeBucket evidence probes even when the dependency itself was present.
Decision: when an adapter supplies a cwd, resolve it for `PWD` while retaining
the direct `-C` execution boundary; pass the canonical Kujo module path to
ChangeBucket doctor and mission adapters. Rationale: keep module resolution,
process cwd, and evidence ownership aligned without allowing a caller PATH or
shell to choose the runtime. Consequence: sibling version probes and mission
ChangeBucket evidence work from Relay's launch context; the adapter remains
provider-independent and still records subprocess failures. Rejected: trusting
the inherited `PWD`, changing the caller's cwd globally, or copying sibling
tool implementations into Relay.

## ADR-066: Compare complete authoritative events with the JSONL log

Context: Relay already verified the JSONL event chain and compared its event
IDs/order with the authoritative `state.events` array. That left a divergence
case where a state-only payload or metadata edit preserved IDs and could still
be reported as consistent. Decision: require complete canonical JSON equality
for each authoritative event and corresponding JSONL event, in addition to
length and ID/order checks. Add a store smoke that mutates only authoritative
state and proves `runs events` fails closed. Rationale: event identity is not
evidence integrity; consumers need one exact run history across state, log,
inspection, and export. Consequence: state/log repair must restore the exact
record rather than only its ID sequence; signed exports and durable retention
remain separate concerns. Rejected: comparing IDs only, trusting state over
the log, or introducing a second event store.

## ADR-067: Require persisted receipt and state evidence at read boundaries

Context: `runs events`, `runs watch`, and `runs export` previously allowed a
missing `receipts.json` to fall back to the copy embedded in `state.json`, and
run inspection could return an empty successful result when `state.json` was
missing or malformed. Decision: require a bounded, regular, non-symlinked
`receipts.json` for receipt validation and require a bounded, regular,
identity-matching `state.json` for mission/run inspection and event export.
Rationale: the rebuildable index and embedded state copies are not substitutes
for the persisted evidence objects they describe; otherwise incomplete or
partially deleted runs can be reported as valid. Consequence: operators see a
fail-closed evidence error and must restore the missing artifact; durable
storage, fsync/crash recovery, signed exports, and multi-host ownership remain
open. Rejected: silently falling back to state copies, returning `{}` as a
successful inspection result, or introducing a second receipt store.

## ADR-068: Normalize relative adapter paths before cwd changes

Context: the Loop Engineering harness supplies `KUJO_BIN` as a relative path,
while Relay's adapters launch sibling tools after changing cwd to an SDK, run,
or worktree directory. The mission could complete its local action but lose
ChangeBucket or Eval evidence because the relative Kujo executable no longer
resolved from the new cwd. Decision: normalize Relay roots and all configured
adapter executable/entrypoint paths against the Relay root before spawn, while
retaining fixed executable paths and the existing doctor checks. Rationale:
process cwd and executable identity must be independent, and one shared
adapter resolver prevents each integration from inventing its own path rule.
Consequence: relative overrides are interpreted relative to the Relay checkout;
missing or unsafe targets still fail through the existing subprocess/doctor
boundaries. Rejected: trusting inherited cwd/PWD, adding PATH lookup, or
copying sibling binaries into Relay.

## ADR-069: Expose one read-only run verification boundary

Context: Relay already validated state, events, receipts, ChangeBucket output,
and Eval output in several individual CLI commands, but machine callers had no
single compact verdict and artifact readers could turn a missing changes or
evaluations file into a successful empty response. Decision: add
`runs verify <run-id>` as a read-only `relay-run-verification-v1` contract and
make `runs changes` and `runs evaluations` require bounded, regular,
shape-checked persisted artifacts plus authoritative state. Rationale: CI,
Paperclip, Hermes, and future adapters need one stable evidence gate without
duplicating parser logic or treating absent evidence as success. Consequence:
verification remains local and non-mutating; signed exports, durable storage,
tenant authorization, and repair remain separate concerns. Rejected: trusting
the rebuildable index, returning empty fallbacks, or adding a second evidence
store.

## ADR-070: Do not export incomplete result bundles as valid

Context: `runs export` verified state, events, and receipts but previously read
ChangeBucket, Eval, and report JSON through fallback readers. A deleted result
could therefore be exported as `{}` or `[]` while the bundle still claimed
`integrity_valid: true`. Decision: require bounded, regular, shape-checked
`changes.json`, `evaluations.json`, and `report.json` before producing a valid
export, and expose their validity fields in `runs verify`. Rationale: an export
is an evidence boundary, so absence must be distinguishable from an empty
result and machine consumers must not infer completion from a partial bundle.
Consequence: failed or partially persisted runs return an explicit incomplete
export error until a future partial-export contract is defined; no evidence is
silently synthesized. Rejected: empty fallbacks, embedding only state copies,
or letting the export command define a second result store.

## ADR-071: Make incomplete exports explicit and opt-in

Context: valid exports must reject missing result artifacts, but paused and
failed runs can legitimately stop before ChangeBucket and Eval artifacts are
created. A hard failure alone leaves machine callers unable to inspect those
runs without scraping state files. Decision: add an explicit
`runs export --partial` path for non-completed runs, returning the versioned
`relay-run-export-partial-v1` contract with `integrity_valid: false`,
`completeness: "partial"`, artifact-presence booleans, and null unavailable
artifacts. Completed runs never qualify for this path. Rationale: preserve
truthful failure evidence and resumability without weakening the valid export
boundary or inventing a second store. Consequence: callers must branch on
format and integrity status; signed exports, durable storage, and authenticated
authorization remain open. Rejected: silently treating partial output as a
valid export, allowing completed runs to downgrade, or exposing raw files as
an undocumented machine contract.

## ADR-072: Bound artifact inventory depth and keep the run index cache hot

Context: `runs sizes` recursively walks persisted artifacts, and run
registration rebuilt the authoritative run tree before entering the locked
index persistence path. Deep attacker-controlled artifact trees could exhaust
the Kujo VM call stack, while every registration paid for two full run-tree
scans and the registration record omitted `updated_at`, making the cache look
stale on the next read. Decision: cap artifact inventory recursion at 16
directory levels, use the locked persistence path as the single authoritative
registration scan, and preserve complete `updated_at` metadata in rebuilt index
records. Rationale: bounded traversal is a fail-closed local DoS control, and
removing the redundant scan improves mission/index throughput without changing
state ownership. Consequence: unusually deep artifact layouts are rejected and
the rebuildable index remains a cache rather than a durable store. Rejected:
unbounded recursive inventory, trusting a caller-provided cache record, or
moving run authority into the index.

## ADR-073: Require persisted acceptance artifacts before completion

Context: completion already depended on ChangeBucket and Eval results, but a
successful in-memory adapter result could still be followed by a failed write
of `changes.json`, `evaluations.json`, the report, or the RunLedger finish
record. That would make the terminal status claim stronger than the evidence
available to a later reader. Decision: verify required JSON writes as regular,
non-symlinked, bounded files with the expected shape; require successful
Markdown/JSON report persistence; and treat a failed pass-status RunLedger
finish as an `evidence_failure` with a failed terminal transition. Rationale:
completion is an evidence-backed state, not a process-local result. Consequence:
artifact-write failures are visible to machine callers and cannot be repaired by
an index or embedded state fallback; durable transactions, crash recovery, and
signed export remain open. Rejected: trusting adapter return values, emitting
`run_completed` before RunLedger finish, or silently omitting a required
artifact.

## ADR-074: Verify report identity and Markdown evidence at read boundaries

Context: `report.json` was shape-checked, but a copied or tampered dictionary
could still satisfy a generic object check, and `missions report` returned
paths without proving that the Markdown companion remained present. Decision:
require report run ID, mission ID, and status to match authoritative state and
require a bounded regular `report.md` for verification, export, and report
lookup. Rationale: machine consumers need semantic evidence completeness, not
just parseable JSON. Consequence: stale or copied reports fail closed while the
existing report format remains compatible; signed manifests and durable
retention remain open. Rejected: trusting filenames, accepting any JSON object,
or returning report paths without validation.

## ADR-075: Reject placeholder index records and oversized artifact directories

Context: the rebuildable index could accept its own empty fallback fields when
a run directory existed but authoritative `state.json` was missing. Artifact
inventory also flattened a directory before enforcing the total entry limit,
creating avoidable memory and latency pressure. Decision: require each indexed
run to have a dictionary state with a matching run ID, and reject a directory
whose immediate entry count already exceeds the inventory budget before
recursive flattening. Rationale: the cache must never manufacture evidence, and
resource limits should be enforced at the cheapest boundary. Consequence:
incomplete runs disappear from listing until state is restored, and oversized
artifact directories fail with a clear bound; the index remains a rebuildable
cache and durable multi-host storage remains deferred. Rejected: treating
placeholder metadata as valid, or flattening unbounded directories before
checking limits.

## ADR-076: Revalidate worker-tool policy at the execution boundary

Context: the Agents SDK bridge already applies an approval provider and a
capability-bound worker, but a direct internal worker request could otherwise
reach `execute_action` with caller-supplied write approval or unbounded timeout
and byte-budget values. Decision: recheck `approval.approved`, command timeout,
and output/write byte bounds inside the Relay worker immediately before action
execution. Rationale: every authority boundary must remain safe if an upstream
adapter is bypassed, malformed, or later replaced. Consequence: duplicate
validation is intentional defense in depth and the existing Agents SDK contract
remains compatible; authenticated machine invocation is still deferred.
Rejected: trusting the bridge-only approval decision or treating the capability
hash as caller authentication.

## ADR-077: Watch terminal state through the authoritative evidence reader

Context: `runs watch` validated the event log and receipts but read terminal
state through a generic JSON fallback. A symlinked or malformed state file could
therefore be treated as a non-terminal empty state and cause a misleading
timeout. Decision: pass the requested run ID into the watcher and use the same
identity-checked, regular-file state reader as other read boundaries. Rationale:
watch is a machine-facing evidence interface and must fail immediately on
unsafe state rather than waiting. Consequence: state-link and missing-state
failures are explicit; the bounded local watcher remains non-durable and
single-host. Rejected: raw state fallback or timeout-based detection.

## ADR-078: Redact Agents SDK bridge summaries recursively

Context: the Agents SDK bridge returned model output, tool output, and worker
error text in its machine summary. Those values can contain provider secrets or
repository credentials even when subprocess evidence is redacted elsewhere.
Decision: recursively apply Relay's existing redaction helper to bridge output,
tool-result objects, and error messages before serialization. Rationale: the
bridge is an evidence and authority boundary, so every returned string must
cross the same local secret-safety filter. Consequence: credential-shaped text
is masked while the contract remains structurally compatible; provider-native
classification and full Redact integration remain deferred. Rejected: trusting
the model, SDK, or subprocess layer to sanitize every nested result.

## ADR-079: Centralize boolean environment controls

Context: CLI, adapter, and doctor paths independently compared environment
values to the literal string `true`, while the shared boolean helper already
accepted common shell spellings. This made `1`, `yes`, and case variants behave
inconsistently and could unexpectedly disable fixture safety or verification.
Decision: expose `env_bool(key, fallback)` from the common Kujo module and use it
for `RELAY_OFFLINE_FIXTURE` and `RELAY_WATCHDOG_VERIFY` at every runtime boundary.
Rationale: one parser makes CI and shell configuration predictable while the
fallback remains fail-safe for fixture mode and opt-in for live verification.
Consequence: accepted values are `true`/`false`, `1`/`0`, and `yes`/`no`,
case-insensitively; invalid values retain the documented default. Rejected:
repeating literal comparisons in each command or silently treating unknown
values as live mode.

## ADR-080: Bind the AI bridge to trusted Relay source

Context: the AI SDK adapter accepted `RELAY_AI_BRIDGE` as an arbitrary path and
could execute a caller-selected Kujo source file with the trusted Kujo runtime.
That made a configuration override an unintended source-execution boundary.
Decision: resolve the bridge only when it is a regular, non-symlinked `.kujo`
file inside the configured Relay root; reject invalid values before spawning
the AI bridge, and expose the same readiness result through `doctor`.
Rationale: provider configuration must not widen source authority, and the
machine-facing failure must not echo the rejected path. Consequence: custom
bridges must be reviewed into the Relay source tree or require a future signed
adapter contract; the existing default bridge remains unchanged. Rejected:
trusting any absolute environment path, following symlinks into an external
checkout, or relying on the provider/Kujo process to enforce this boundary.

## ADR-081: Separate model capability from Relay tool planning

Context: `models list` advertised `tool_calls` for the configured
OpenAI-compatible profile even though Relay only executes explicitly declared
mission tools and does not yet support provider-generated tool planning.
Decision: expose truthful chat/streaming capabilities, a visible selection
reason, `tool_planning: false`, and `tool_execution: "declared_mission_only"`
in model list and probe results. Rationale: machine callers must not confuse a
provider's possible API feature with a Relay feature that is not implemented or
evaluated. Consequence: clients can safely gate tool-planning workflows and the
profile can grow when authentic provider evidence exists. Rejected: retaining
the optimistic `tool_calls` claim, hiding the limitation in prose, or silently
attempting provider tools.

## ADR-082: Seal persisted run state without claiming signed authority

Context: events and receipts already carried integrity hashes, but the
authoritative `state.json` could be edited while retaining a valid event and
receipt sequence. Decision: every persisted state record carries an
`integrity_sha256` computed over the state with that field excluded, and read,
resume, cleanup, and report boundaries verify it before trusting state.
Rationale: status, workspace, budget, and completion state are security- and
evidence-sensitive; a consistent local seal detects accidental or unauthorized
mutation without creating a second store. Consequence: pre-seal legacy state
is rejected at strict read/control boundaries and requires regeneration or a
future signed migration; the seal is not a cryptographic signature or
multi-user authorization mechanism. Rejected: trusting only event/receipt
hashes, silently accepting unsealed state, or inventing a parallel database.

## ADR-083: Publish versioned machine schemas and one aggregate local gate

Context: Relay's JSON boundary was documented across command prose and tests,
but machine callers lacked committed schemas and the verification list could
drift as smoke tests were added. Decision: publish forward-compatible JSON
Schemas under `schemas/` for mission, run/report, event, receipt, doctor,
probe, and tool-result contracts, and provide `tests/relay_acceptance.sh` as
the canonical local gate that discovers every committed smoke script.
Rationale: Paperclip, Hermes, CI, MCP, and Kujo callers need discoverable
contracts, while one aggregate gate improves regression coverage and lowers
maintenance cost. Consequence: schemas remain adapters over upstream owners,
not replacements; external-provider, CI, release, and schema-negotiation gates
remain deferred. Rejected: copying upstream provider schemas into Relay,
hand-maintaining a second smoke inventory, or returning undocumented JSON.

## ADR-084: Normalize evidence correlation fields at the Relay boundary

Context: event and receipt records carried many identifiers, but tool, artifact,
evaluation, retry, and repair context was inconsistently nested in payloads.
Decision: Relay adds stable metadata keys for mission, run, workflow, step,
agent, model, provider, packet, tool, artifact, evaluation, retry, repair,
RunLedger, and AI correlation context while preserving upstream payloads.
Rationale: machine callers and later RunLedger/Watchdog adapters need one
searchable correlation surface without inventing a second event or telemetry
store. Consequence: empty retry/repair fields are explicit until their owning
policy is implemented; typed retry receipts and provider-generated tool loops
remain deferred. Rejected: requiring downstream consumers to parse every
payload shape or duplicating Watchdog/RunLedger stores.

## ADR-085: Persist typed model-fallback decisions at mission boundaries

Context: the AI adapter restricted fallback to transient or explicit capability
failures and exposed the decision in telemetry, but a mission run had no
first-class event/receipt for a selected or skipped fallback. Decision:
centralize fallback classification in the adapter and persist a
`model_fallback_selected` or `model_fallback_skipped` AgentEvent plus a typed
`fallback` RelayReceipt when mission planning returns a non-primary decision.
Rationale: machine callers need to distinguish a primary model result from a
retry policy outcome without parsing telemetry alone. AI SDK and Watchdog
remain authoritative for the actual model call and observation. Consequence:
local mission evidence is more explicit, while provider-specific taxonomy,
adaptive routing, signed provenance, and distributed retry ownership remain
deferred. Rejected: silently changing models or retrying non-retryable
policy/authentication failures.

## ADR-086: Bound artifact inventory by total bytes

Context: `runs sizes` capped entries and recursion depth, but many individually
small files could still force an oversized flattened JSON response. Decision:
cap each complete artifact inventory at 8 MiB in addition to the existing
4096-entry and 16-level bounds. Rationale: the inspection result is itself a
machine-facing in-memory artifact; a total-byte ceiling keeps the diagnostic
path bounded without adding retention authority. Consequence: oversized
evidence is reported as invalid and requires a future compaction/retention
owner; workspace bytes remain excluded. Rejected: silently truncating
inventories or following links.

## ADR-087: Page verified event inspection for machine callers

Context: `runs events` verified a bounded log but returned the complete event
array and redundant JSONL string on every request. Decision: accept optional
`--limit 1..4096` and `--after <event-id>` cursors for `runs events`,
verify the complete chain and authoritative state sequence first, then return a
window with `event_count`, `offset`, `has_more`, and `next_after`.
Paged responses omit the redundant JSONL field. Rationale: CI, Paperclip,
Hermes, and future MCP callers can inspect long runs without repeatedly
allocating or transferring the entire verified response. Consequence: this is
a response-size optimization, not a durable remote event sink or a change to
`runs export`; malformed cursors and limits fail closed. Rejected: slicing
before integrity verification or silently truncating the legacy unpaged form.

## ADR-088: Bind cooperative cancellation requests to run identity

Context: a local cancellation request was protected against symlink redirection
but did not carry an identity or integrity seal, so a stale or copied request
could be interpreted as an operator action in another run directory. Decision:
persist the run ID and a SHA-256 seal over the request fields, and require both
to validate before action-boundary cancellation. Rationale: prevent accidental
cross-run control and make cancellation evidence tamper-evident while retaining
the existing cooperative process-group boundary. Consequence: pre-v62 request
files are rejected and require regeneration; authenticated ownership,
replay protection, distributed cancellation, and rollback remain deferred.
Rejected: trusting any readable request file or treating the hash as an
authorization signature.

## ADR-089: Bind Agents SDK worker capabilities to a short-lived nonce

Context: the Agents SDK worker capability was previously derived entirely from
run, session, workspace, and a fixed purpose string. Anyone who knew those
public values could reconstruct a syntactically valid capability for the local
worker boundary. Decision: generate a per-worker nonce in the parent runtime,
include it only in the short-lived parent/child payload, and derive the
capability from that nonce plus the existing identity fields. Requests missing
the nonce or using the legacy deterministic formula fail closed. Rationale:
capability possession should require a value that is not predictable from
machine-visible identifiers while preserving the existing workspace and
approval checks. Consequence: direct worker callers must obtain a fresh
runtime-issued capability; nonce replay protection and authenticated caller
identity remain deferred. Rejected: retaining a hash of public identifiers,
putting a static secret in the repository, or treating the capability as a
replacement for an authenticated service boundary.

## ADR-090: Keep the child executable path authoritative at process boundaries

Context: process options already supplied a fixed `PATH`, but arbitrary extra
environment maps could overwrite it or inject loader, interpreter, Git
override, or trust-store variables. Decision: ignore `PATH` overrides, retain
only safe environment names (plus runtime-derived `PWD`), and reassert the
fixed executable path in both common and Agents SDK worker process builders.
Rationale: the child process is an authority boundary and must not resolve
executables or interpreters through caller-controlled environment state.
Consequence: unsupported environment overrides are dropped rather than passed
through; deployment-specific environment configuration must use explicit safe
names and the existing provider configuration surface. Rejected: inheriting the
ambient environment, allowing caller-selected `PATH`, or relying on the shell
to enforce the boundary.

## ADR-091: Reject parent symlink components for repository authority

Context: validating only the repository directory itself and `.git` metadata
still allowed a path whose parent component redirected through a symbolic link.
Decision: mission repository and Agents SDK tool-workspace paths reject any
symbolic-linked parent component before Git or file authority is granted.
Rationale: realpath containment alone proves the resolved destination, not that
the caller selected a stable non-redirecting trust root; the shared fail-closed
probe already provides this check. Consequence: symlinked checkout aliases must
be canonicalized by the caller before use; full kernel no-follow workcells and
multi-user ownership remain deferred. Rejected: trusting only `realpath`,
following parent links, or adding a second path-policy implementation.

## ADR-092: Preserve specific failure classes before generic tool failures

Context: a generic `tool` substring could classify policy, permission, or
malformed tool failures as `tool_failure`, weakening retry and escalation
decisions. Decision: normalize failure codes and classify authority, workflow,
model, context, implementation, evaluation, repository, tool, and provider
classes with specific policy/permission checks before generic tool matching.
Rationale: machine callers and future CaseFile/repair adapters need a stable
failure taxonomy that does not hide why an action stopped. Consequence:
provider-specific normalization and typed retry/repair ownership remain open;
the local contract now distinguishes the important safety and completion
boundaries. Rejected: treating every non-success as provider failure or letting
substring order determine authority semantics.

## ADR-093: Page validated run-index inspection without changing cache authority

Context: `runs list` returned the complete validated index, which made large
local run collections expensive to transfer to CI, Paperclip, Hermes, and
future MCP callers. Decision: sort validated run IDs deterministically and
support optional `--limit 1..4096` and `--after <run-id>` windows with
`run_count`, `offset`, `has_more`, and `next_after` metadata. Validate the full
cache/authoritative state relationship before slicing, and preserve the legacy
unpaged response. Rationale: machine callers gain bounded response transfer
without a second store or weaker state authority. Consequence: paging is a
response optimization, not retention, remote subscription, or concurrent-store
support; cursors are invalidated by missing IDs or index changes. Rejected:
returning arbitrary dict iteration order, slicing an unvalidated cache, or
silently truncating the legacy response.

## ADR-095: Bound provider tool loops and persist typed tool results

Context: v65 connected one provider-generated tool plan to the Agents SDK
registry, but a model could not receive the result of an approved call and
continue its response. Decision: provider mode now permits a bounded
`max_tool_turns` loop, carries assistant tool-call and `role: tool` messages
through the existing AI SDK bridge, rechecks cancellation and call budgets at
each turn, and persists redacted results as a sealed `relay-tool-result-bundle-v1`
artifact. Rationale: make provider-driven missions useful for real work while
preserving one policy/approval authority and making intermediate results
resumable and inspectable. Consequences: provider mode consumes model and tool
budgets across turns; malformed, cancelled, over-budget, or unpersistable
results fail closed, and providers that do not support the message dialect
remain an explicit capability failure. Rejected: executing a second provider
request without tool results, treating the model's final text as tool evidence,
or creating a separate tool executor/store.

## ADR-096: Fail closed at provider, subprocess, and evidence-size boundaries

Context: the provider bridge, Agents SDK worker, and local evidence files each
had independent transport or inspection limits. A caller-controlled prompt or
provider response could consume the remaining bridge budget, duplicate tool
IDs could make follow-up results ambiguous, proxy environment variables could
redirect child-process network traffic, and an event or receipt log could grow
beyond the read-side verification ceiling before completion was rejected.

Decision: cap serialized AI requests at 112 KiB before bridge spawn, cap
serialized provider responses at 1 MiB, cap provider tool arguments at 64 KiB
per call, reject duplicate or control-character tool-call IDs, deny proxy
environment overrides at the shared child-process boundary, cap persisted
event and receipt evidence at 8 MiB, and require PackWrite to produce a safe
regular `agent/MASTER.md` artifact before mission preflight can pass.

Rationale: keep resource limits below downstream transport/inspection limits,
preserve unambiguous tool-result correlation, reduce network-redirection risk,
and make evidence-size failure explicit at the write boundary. The changes
reuse existing common environment, adapter, PackWrite, and evidence contracts
instead of adding another policy or storage owner.

Consequences: large prompts, provider outputs, tool arguments, event histories,
and receipt histories fail closed with machine-readable evidence rather than
being truncated silently. Provider-specific dialect negotiation, durable
retention/compaction, signed state, authenticated tenancy, and multi-host
storage remain deferred.

Rejected: silently truncating provider messages or evidence, allowing arbitrary
proxy variables for convenience, accepting duplicate IDs and guessing result
order, or treating a successful PackWrite process exit as proof that a usable
packet exists.

## ADR-097: Make provider-generated tool results part of the verified run boundary

Context: the bounded provider-tool loop persisted a redacted
`relay-tool-result-bundle-v1`, but read-side verification could still report a
run as valid after that artifact was deleted or modified. This left a gap
between tool execution evidence and the machine-facing completion verdict.

Decision: when authoritative run state says provider-generated Agents SDK tools
were used, `runs verify` and valid `runs export` require `tool-results.json`,
validate its contract and run identity, recompute its SHA-256, compare it with
the state-recorded artifact digest, and include the verified bundle in exports.
Runs without provider-generated tools retain the existing optional-artifact
behavior.

Rationale: close the evidence gap at the existing CLI read boundary without
creating a second tool-result store or changing the Agents SDK/AI SDK owners.
The provider-tool smoke proves both the valid and tampered cases.

Consequences: provider-generated runs fail closed if tool results are missing,
malformed, or tampered; partial exports expose their tool-result presence and
error. Signed manifests, durable retention, and authenticated ownership remain
future work.

Rejected: trusting the state copy of tool results, treating the artifact as
informational only, or inventing a second receipt/database authority.

## ADR-098: Require exact hashes for repository shell scripts

Context: the direct-argv policy removed shell metacharacters, but allowing
`bash scripts/name.sh` or `sh scripts/name.sh` still permitted any repository
script to execute. A write-enabled mission could create or alter such a script
and then invoke it, widening authority beyond the declared read-oriented
command intent.

Decision: repository shell-script commands require a `scripts/*.sh` path, a
regular non-symbolic file with no symbolic parent, and an exact 64-character
SHA-256 in the mission's `allowed_script_hashes` map. Relay recomputes the
digest at validation and immediately before execution. Hash mismatches,
missing declarations, and symlinked scripts fail closed.

Rationale: preserve bounded script functionality for immutable, explicitly
approved fixtures while making content—not only the interpreter name—part of
the authority contract. This reuses Kujo hashing and Relay path policy rather
than adding a shell sandbox that does not exist.

Consequences: existing script missions must add hashes; scripts changed during
a mission cannot be executed until a new explicitly approved mission revision
is created. Signed provenance, authenticated callers, and workcell-level
network/filesystem isolation remain open.

Rejected: allowing every `scripts/*.sh`, hashing only at mission load, or
replacing the contract with an unrestricted shell denylist.

## ADR-099: Keep artifact hashing opt-in on the bounded size inventory

Context: operators and machine callers need a lightweight way to inspect run
artifact footprints, but integrity comparison and future manifest generation
also need per-file digests. Hashing every file on every `runs sizes` call would
turn a read-only operational probe into unnecessary I/O for large evidence
trees.

Decision: preserve the existing bounded size-only `runs sizes` default and add
`--hashes` as an explicit opt-in. The same depth, entry, byte, regular-file,
and symlink bounds apply; opted-in regular files receive SHA-256 values and
the response declares `hashes_included`.

Rationale: add useful integrity data without regressing normal inspection
latency or creating a second artifact-manifest owner. The sizes smoke proves
both the fast path and digest shape.

Consequences: hash-based comparisons require an explicit flag and are still
local unsigned observations; signed manifests, retention, and durable artifact
ownership remain future work.

Rejected: hashing by default, scanning the excluded workspace, or persisting a
parallel manifest store from a read-only command.

## ADR-100: Bind PackWrite completion to a recursive packet manifest

Context: PackWrite completion previously required a safe `MASTER.md` artifact
and recorded only that file's digest. A changed or newly added packet file could
therefore escape the local read-side evidence boundary while the run remained
valid.

Decision: after PackWrite generation, Relay walks the `agent/` packet tree under
bounded depth, entry, byte, regular-file, and symlink checks; it persists a
versioned `relay-packwrite-manifest-v1` outside the packet tree; and `runs
verify` plus valid export recompute and compare the full manifest. Agents SDK
delegation also preserves the mission's exact script-hash map.

Rationale: make the existing PackWrite artifact the authoritative packet input
without creating a second packet format or trusting a single sentinel file.
The manifest is local tamper evidence, not a signed multi-tenant provenance
system.

Consequences: packet file changes, missing files, extra files, unsafe links, and
digest mismatches fail machine verification. Existing bounded PackWrite
generation remains the owner of packet contents; future signed manifests,
retention, and remote handoff remain open.

Rejected: hashing only `MASTER.md`, persisting the manifest inside the tree it
describes, following links, or silently accepting changed packet contents.
## ADR-101: Make repair replay explicit, typed, and budgeted

Context: Relay exposed `max_repairs` in mission contracts and receipt metadata,
but had no operator-visible repair operation and no enforcement beyond parsing
the integer. A failed run could therefore not be resumed through a bounded,
auditable recovery path.

Decision: add `missions repair <run-id>`. It may replay persisted actions only
for transient/tool/repository/implementation/evaluation failure classes, binds
an incrementing `repair_attempts` count and unique `repair_id`, emits
`repair_started`, `repair_completed`, or `repair_failed` events plus typed
receipts, and caps `max_repairs` at four. Policy, authentication, malformed
authority, cancellation, evidence, and exhausted-budget failures remain
non-repairable.

Rationale: operators get a truthful, machine-readable recovery boundary while
Relay retains control over authority and completion. Explicit replay is safer
than silent loops and is useful for transient repository/tool failures without
pretending that adaptive repair or model rerouting already exists.

Consequences: repair reuses the persisted mission actions and does not yet
change model, context, or workflow; workcell retention and durable repair
history remain future work. The new smoke covers successful one-attempt replay,
typed receipts, and zero-budget denial.

Rejected: silently retrying failed missions, replaying policy/evidence failures,
or allowing unbounded caller-selected repair counts.

## ADR-102: Enforce mission token budgets at the provider boundary

Context: Relay recorded provider usage and checked `used_tokens` after the
model call, but the adapter always requested 700 completion tokens. A mission
with a smaller budget could therefore spend more than its declared limit before
failing, while negative provider usage could reduce the recorded total.

Decision: require positive aggregate mission `max_tokens` values, cap them at
65,536, cap every provider request at 16,384, pass the remaining mission budget
to the AI SDK bridge, reduce each follow-up request to the remaining budget,
and normalize negative usage to zero before accounting.
Drop caller-supplied `PWD` from generic child environment overrides and restore
only the trusted adapter working-directory value.

Rationale: enforce cost and latency limits before provider work begins and
close an environment-metadata injection path without changing AI SDK ownership
or inventing a second usage contract.

Consequences: zero-token missions are rejected during validation; provider
responses that claim negative usage no longer create budget credit; live
provider billing still requires external reconciliation. Existing chat keeps
its bounded 700-token default, while mission calls use their explicit budget.

Rejected: relying only on post-call usage checks, silently clamping an exhausted
mission to one token, or allowing arbitrary environment `PWD` values.

## ADR-103: Reconcile Watchdog usage per provider request

Context: Relay could verify that Watchdog persisted a request under the run
correlation, but correlation alone did not prove that the observed telemetry
belonged to the exact AI SDK response or that token accounting agreed.

Decision: when `RELAY_WATCHDOG_VERIFY=true`, match the Watchdog row by both
correlation ID and AI SDK request ID, sanitize the row, and compare normalized
input, output, and total token usage. Missing observed usage or a mismatch makes
verification fail closed as `watchdog_telemetry_unverified`.

Rationale: close a local evidence gap without taking ownership of Watchdog's
telemetry store or inventing a second usage protocol. Request identity prevents
multi-turn rows from being confused, while total usage remains authoritative
for the Relay budget and provider billing still requires external evidence.

Consequences: authenticated verification is stricter and may reject providers
or Watchdog versions that omit request IDs or usage fields; the returned
verification payload contains only bounded status, identity, and usage fields.
The local Watchdog stub and real Watchdog/stub-provider smokes prove the
contract, but do not prove external-provider billing reconciliation.

Rejected: selecting the latest correlated row, reading Watchdog's database
directly, trusting provider usage without Watchdog reconciliation, or copying
raw telemetry rows into Relay artifacts.

## ADR-104: Trust dependency paths before adapter execution

Context: Relay's doctor checked configured dependency paths, but runtime adapter
invocations still accepted an environment-selected path directly. A symlinked
or non-regular PackWrite, RunLedger, ChangeBucket, Eval, or Capsule target could
therefore pass configuration into a child process even when readiness diagnostics
would have identified the path as unsafe.

Decision: resolve configured dependency paths against the Relay root, reject
symlinked targets and existing symlinked parent components, require regular
files, and fail closed before invocation. The launcher resolves Kujo from an
explicit override, `PATH`, or the sibling release tree and exports that trusted
path as `KUJO_BIN`. Doctor retains the raw configured path for truthful
diagnostics while probes use the trusted path.

Rationale: make the execution boundary enforce the same integrity assumption as
the readiness boundary without introducing a second dependency registry or
changing ownership of sibling tools.

Consequences: symlink-based local wrappers must be replaced with regular files
or an explicit future signed-distribution mechanism. Missing or unsafe targets
fail with the existing adapter/doctor error path. Mode, signature, authenticated
deployment ownership, and immutable manifests remain future controls.

Rejected: trusting doctor-only checks, resolving symlinks and executing the
resolved target, or allowing arbitrary caller-selected child paths.

## ADR-105: Make Agents SDK capabilities short-lived and consumable

Context: Relay's Agents SDK worker capability used a nonce and deterministic
hash, but the tool authority did not persist issuance or consumption. A copied
payload could therefore be replayed in another worker process while the nonce
remained known.

Decision: issue a per-worker registry record containing the run, session,
workspace, nonce, capability digest, expiry, bounded call allowance, and only a
digest of a parent-generated secret. Pass the secret to the child worker through
the bounded environment, validate the registry record at the Relay tool
authority, increment consumption under a lock, and revoke the record when the
worker exits. Direct or legacy requests without an issued record fail closed.

Rationale: close the local replay gap while keeping Agents SDK registry and
Relay policy ownership separate. The registry is an execution-boundary control,
not a second organizational identity or remote authorization system.

Consequences: direct worker tests must use an issued fixture record; failed or
denied calls consume allowance, and crashed processes may leave bounded stale
records until future cleanup. Authenticated multi-host issuance, signed
provenance, and remote revocation remain future work.

Rejected: trusting a caller-supplied nonce, persisting the raw secret, using an
unbounded global replay list, or making Paperclip/Hermes a core dependency.

## ADR-106: Make capability-registry cleanup explicit and bounded

Context: short-lived Agents SDK capability records are revoked on normal worker
exit, but a crashed worker can leave expired or exhausted local records. An
unbounded cleanup pass would create a new denial-of-service and filesystem
authority surface, while silently mutating state during a readiness check would
make operator behavior difficult to audit.

Decision: expose capability-registry posture through `doctor`, scan at most 1024
JSON records, fail closed on unsafe directories or malformed entries, and keep
the default command read-only. Add `doctor --repair` as the explicit mutation
mode; it removes only records that are expired or have exhausted their bounded
call allowance and reports `records`, `stale`, `invalid`, and `cleaned` counts.

Rationale: close the local stale-record hygiene gap without duplicating the
Agents SDK registry or introducing a background daemon. The explicit flag
preserves operator intent, while the fixed scan bound limits cleanup cost.

Consequences: local crash leftovers can be repaired deterministically, but
multi-host reconciliation, authenticated ownership, signed provenance, and
retention remain future concerns. A malformed or unsafe registry still blocks
readiness rather than being deleted.

Rejected: deleting stale records during ordinary doctor execution, scanning an
unbounded directory, persisting raw capability secrets, or creating a second
capability service.

## ADR-107: Serialize capability cleanup with tool consumption

Context: ADR-106 made stale capability cleanup explicit and bounded, but a
repairing doctor could still delete a record while a worker was consuming it.
That race could invalidate an otherwise authorized call or allow the worker's
post-consumption write to recreate a record after cleanup.

Decision: `doctor --repair` acquires the existing per-record `.lock` directory
with an exclusive fixed-path native `mkdir` operation before re-reading and
deleting a stale capability. Active records are skipped and counted as
`locked`; non-directory lock objects and symbolic links are invalid safety
failures. The same exclusive primitive is used by capability consumption and
the run-index lock. The default read-only posture scan does not acquire locks
or mutate state.

Rationale: reuse the Agents SDK worker authority's local lock contract instead
of inventing a second synchronization primitive, while avoiding Kujo's
idempotent `create_dir` for authority acquisition. Re-reading under the lock
ensures cleanup decisions use the latest usage and expiry values.

Consequences: repair is race-safe for the local single-host registry, but a
crashed lock remains conservative until an explicit future reconciliation policy
can prove ownership. Multi-host locking, authenticated ownership, and durable
storage remain open.

Rejected: deleting without a lock, using idempotent directory creation as an
exclusive lock, force-removing active lock directories, or silently treating
malformed lock objects as idle records.

## ADR-108: Create mission state directories with exclusive, symlink-safe mkdir

Context: Relay mission and run state directories were previously created with
Kujo's idempotent `create_dir`. That is suitable for ordinary convenience
directories but does not provide an explicit exclusive-create boundary and
leaves a time-of-check/time-of-use gap when a state path is replaced during
creation.

Decision: use the shared fail-closed path probes for every mission state
directory component and create missing components with the fixed native
`/bin/mkdir` exclusive primitive. Mission creation and run execution fail with
`state_store_failure` when the requested state path is unsafe or cannot be
created; existing safe directories remain reusable.

Rationale: keep state-directory authority aligned with the v78 lock contract,
avoid a second filesystem primitive, and prevent state writes from silently
following symlinked components. The implementation remains Kujo-native and
uses no shell command interpolation.

Consequences: local single-host state creation is more conservative and
truthful under races, while missing kernel no-follow APIs, durable multi-host
storage, authenticated ownership, and crash recovery remain future work.

Rejected: idempotent `create_dir` for state authority, shell-based `mkdir -p`,
best-effort continuation after unsafe directory creation, or a parallel state
directory implementation in the CLI.

## ADR-109: Reuse Kujo atomic file writes for Relay evidence and capability state

Context: Relay's local `write_text_atomic` wrapper used a timestamp/random
temporary filename followed by `write_file` and rename. That preserved the
basic replacement shape but did not inherit Kujo's native exclusive temporary
file creation, flush/sync behavior, or its no-overwrite finalization contract.
Capability-registry directory creation also used the idempotent `create_dir`
helper even though the registry is an authority boundary.

Decision: delegate `write_text_atomic` to Kujo's native `write_file_atomic` with
explicit replacement enabled, and route capability-registry directory creation
through the shared fail-closed `ensure_safe_directory` helper. Keep the Relay
wrapper's boolean return contract and the runtime's existing artifact-path
checks.

Rationale: reuse a first-party Kujo primitive with stronger temporary-file and
rename semantics, remove duplicate filesystem logic, and make mission state and
Agents SDK capability state follow the same local authority policy.

Consequences: evidence writes gain native atomic/fsync behavior and capability
directories no longer depend on idempotent creation. Durability, signed
provenance, multi-host ownership, and kernel-level no-follow guarantees remain
outside Relay's local contract.

Rejected: retaining the predictable custom temporary-file scheme, shell-based
atomic writes, or adding a third Relay-specific filesystem writer.

## ADR-110: Serialize capability issuance and reject record replacement

Context: ADR-109 unified capability-registry directory creation, but two
workers using the same run/session identity could still race at issuance. An
atomic file replacement would allow the later secret to invalidate the earlier
worker's capability and would make capability ownership ambiguous.

Decision: acquire the existing per-record exclusive lock before issuing a
capability, reject non-regular or symbolic-linked record/lock paths, reject an
already registered record, and release the lock only after the record is
persisted. Issuance contention returns `capability_busy`; duplicate identity
returns `capability_already_registered`.

Rationale: keep one lock and one registry authority for issuance, consumption,
and repair. The explicit duplicate failure is safer than silently replacing a
live worker's secret and makes concurrent callers receive a deterministic
machine-readable result.

Consequences: a crashed issuer can leave a conservative local lock until a
future ownership/recovery policy is added. This is single-host coordination;
it does not establish authenticated multi-host capability ownership.

Rejected: overwriting records, using a separate issuance lock namespace,
silently rotating secrets for the same identity, or force-removing stale locks.

## ADR-111: Refresh an invalid run-index cache with one authoritative scan

Context: `load_run_index` validates the rebuildable cache against the
authoritative per-run state tree. When validation failed, it rebuilt the index
and then called the locked persistence path, which rebuilt the same tree a
second time. This duplicated filesystem reads on the recovery path.

Decision: add a dedicated locked `rebuild_and_persist_run_index` path. It
acquires the existing bounded lock, rebuilds the authoritative index once,
persists it, and returns that same result. If the bounded lock cannot be
acquired, it returns one uncached rebuild rather than waiting indefinitely.
Keep `persist_run_index` authoritative for explicit rebuild/register callers.

Rationale: reduce invalid-cache recovery work while preserving the existing
per-run state authority, bounded contention behavior, and fail-closed store
checks. The contract test proves the helper both returns the rebuilt record and
writes the cache.

Consequences: cache recovery performs one authoritative scan instead of two.
The index remains a rebuildable single-host cache; durable transactions,
multi-host coordination, crash recovery, and retention remain deferred.

Rejected: trusting the supplied cache after lock acquisition, removing the
lock from persistence, or adding a second durable index store.

## ADR-112: Serialize capability revocation with the authority lock

Context: capability issuance, consumption, and repair already used the
per-record exclusive lock, but revocation deleted the record without taking
that lock. A parent revoking while a worker consumed a capability could unlink
the record and allow the worker's subsequent usage write to recreate it.

Decision: revocation acquires the same per-record lock with four bounded
backoff attempts, rechecks the record under that lock, deletes only a regular
non-symlinked record, and releases the lock. Contention or unsafe metadata
returns failure instead of claiming revocation succeeded.

Rationale: make issuance, consumption, repair, and revocation share one local
authority protocol. The contract suite proves an active lock prevents
revocation and that a released lock permits removal.

Consequences: local capability shutdown is race-safe within the bounded
single-host protocol. Crash recovery, authenticated remote authorization, and
multi-host ownership remain deferred.

Rejected: deleting without coordination, force-removing active locks, or
introducing a second revocation store.

## ADR-113: Treat native JSONL write failures as evidence failures

Context: `append_jsonl_bounded` validated size and path metadata but ignored the
boolean result of Kujo's native `append_file` and `write_file` operations. A
missing parent directory could therefore leave no evidence file while Relay
returned success to its caller.

Decision: return true only when the selected native append or create operation
returns true; preserve the existing size limit, regular-file, and symlink
checks. Add a deterministic contract case for failed creation.

Rationale: evidence persistence must not claim a write that the runtime
rejected. Using the native result keeps the fix inside the existing Kujo
filesystem contract and avoids a competing writer abstraction.

Consequences: local event/receipt persistence now fails closed on native write
failure. Concurrent append serialization, durable transactions, crash recovery,
and multi-host evidence ownership remain deferred.

Rejected: trusting pre-write metadata, treating a missing parent as success,
or adding a new evidence database solely to compensate for the ignored result.

## ADR-114: Verify run-index persistence before reporting rebuild success

Context: the rebuildable index path already serialized writers and rebuilt from
authoritative per-run state, but it ignored the native `write_json` result. The
CLI could therefore return `ok: true` after an index write failed, while the
caller had no machine-readable indication that the cache was unavailable.

Decision: keep the existing exclusive lock, rebuild once, require the native
write to succeed, read the cache back, and validate its records against the
authoritative run directories before returning a successful persistence result.
`runs rebuild --json` surfaces a bounded state-store failure when any step
fails. Compatibility wrappers retain their existing index-dictionary return
shape for internal callers.

Rationale: machine callers need truthful persistence status, and read-back
verification catches malformed or incomplete cache output without introducing
a second store. The implementation remains composed from existing Kujo
filesystem and Relay cache contracts.

Consequences: failed cache writes are visible and fail closed at the CLI
boundary. The local cache still lacks transactions, retention, crash recovery,
multi-host coordination, and signed export.

Rejected: ignoring write status, trusting an in-memory rebuild as persisted, or
introducing a new database solely to mask this local reporting defect.

## ADR-115: Page provider-visible repository discovery

Context: `relay.list_files` returned every captured tracked path in one tool
result. A repository with a large but valid file list could therefore exceed
the next provider request's fixed payload ceiling, while a process-truncated
Git result could be mistaken for a complete inventory. An empty repository
also produced a one-element array containing an empty string.

Decision: return deterministic pages bounded to 256 paths and 16 KiB of path
text, accept a non-negative file `offset`, expose `next_offset`, `total_files`,
and `has_more`, and reject an underlying Git listing truncated by the mission
output budget. Apply the same behavior to declared and provider-generated tool
calls.

Rationale: keep model context and tool-result evidence bounded while allowing
large repositories to be discovered incrementally. Explicit continuation is
more truthful than silently dropping paths and composes with the existing
tool-call and tool-turn budgets.

Consequences: callers must budget additional tool calls for later pages. A Git
file list larger than `max_output_bytes` fails closed; streaming Git discovery
and server-side cursors remain future work.

Rejected: returning a truncated list as success, sending the full list to the
provider, or adding an unbounded recursive filesystem walk.

## ADR-116: Reject ambiguous CLI input

Context: the generic token parser accepted unknown and duplicate flags, treated
missing values as empty strings, and let commands ignore extra operands. A
misspelled safety or routing option could therefore look accepted while Relay
executed with defaults.

Decision: classify value and boolean options, reject duplicate or missing
values, validate each subcommand's allowed flags and argument count, and
support `--` as the standard option terminator for prompt text.

Rationale: machine callers and operators need configuration mistakes to fail
before provider, repository, or evidence work begins. Per-command validation
preserves the documented stable surface without changing valid invocations.

Consequences: previously ignored invalid input now exits `1`. This is a
security and correctness hardening of unsupported input, not a change to a
documented successful contract.

Rejected: warning while continuing, silently selecting the last duplicate
value, or maintaining a permissive unknown-option namespace.

## ADR-117: Add an optional transactional single-host index

Decision: retain per-run evidence as authority and unsigned JSON as the default
cache, while allowing a confirmation-gated migration to SQLite with WAL,
`synchronous=FULL`, schema migration metadata, and transactional replacement.
Startup validates the cache against bounded authoritative directories and
rebuilds it after absence or corruption. This proves crash-rebuildable local
indexing, not multi-host evidence durability.

## ADR-118: Recover only explicitly expired owned locks

Decision: capability and index locks carry versioned owner identity and bounded
lease expiry. Recovery validates the owner, refuses active or malformed locks,
and persists a sealed recovery receipt before removal. Elapsed directory age
alone never grants cleanup authority.

## ADR-119: Keep enterprise composition boundaries local and opt-in

Decision: negotiate versioned Spec/Dispatch envelopes, expose a disabled-by-
default authenticated machine authorization/audit primitive, and require policy
selection plus confirmation for redacted failed-run handoff. These primitives
are transport-neutral and do not claim hosted tenancy or network isolation.

## ADR-120: Separate signed exports from unsigned v1

Decision: preserve `relay-run-export-v1`; an explicit `--signed` operation
wraps its canonical digest in `relay-signed-export-v1` using operator-owned
HMAC-SHA256 keys selected by key ID. A key map supports rotation and old-key
verification. HMAC is shared-key authentication, not asymmetric identity,
notarization, or non-repudiation.

## ADR-121: Bound discovery independently from agent-visible output

Decision: collect Git's tracked-file index inside the runtime's fixed 16 MiB
process ceiling, then return only 256 paths/16 KiB per cursor page. This lets a
small mission response budget traverse a materially larger repository while
still failing closed above the independent collection ceiling.

## ADR-122: Align parsed JSON evidence with Kujo's runtime ceiling

Context: Relay checked several parsed JSON artifacts at 8 or 64 MiB, but pinned
Kujo 1.0.0 rejects `parse_json` input above 1 MiB. Those larger checks could
therefore admit a file that every reader would later treat as malformed.

Decision: cap every parsed JSON evidence document at 1 MiB, bound state event
projection and receipt persistence before writes, and reserve a 900 KiB payload
envelope for signed exports. Keep independently streamed JSONL event logs and
unparsed Markdown artifacts at their existing 8 MiB boundaries.

Consequences: documented and executable limits now agree and oversized state
fails before creating unreadable success evidence. Larger future JSON evidence
requires a versioned streaming/chunked contract rather than a misleading size
constant.
