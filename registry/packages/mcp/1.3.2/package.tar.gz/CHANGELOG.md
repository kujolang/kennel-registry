# Changelog

All notable changes to this project are documented in this file.

## [Unreleased]

## [1.3.2] - 2026-10-14

### Fixed

- Admit in-root file operations on Windows by normalizing canonical path separators for permission comparisons. Preserve POSIX literal backslashes, traversal and sibling-prefix rejection, and relative read-only patterns. Native Windows regression coverage now runs in CI.

### Compatibility

- Keep the Kujo 1.7.0 minimum and existing file-tool contracts. No configuration migration is required.
- The independently packaged `kujo-ability` npm bridge remains 1.3.1: this fix is in the Kujo framework, outside that package. Historical host certification retains its original version and scope.

## [1.3.1] - 2026-10-12

### Fixed

- Correct the packaged Ability bridge verification commands so they run from
  the documented MCP repository root before the first npm publication.

## [1.3.0] - 2026-10-02

### Added

- `kujo mcp make` is now a first-class Kujo CLI command for the repo-specific
  generator. It accepts no argument (current directory), `.` and `./repo`
  relative paths, and absolute paths, forwards all generator options
  (`--out`, `--artifacts`, `--ai-sdk-path`, `--profile-only`,
  `--artifacts-only`, `--no-ai`, `--validate`, `--dry-run`), and runs the
  canonical package VM-first without `--interpreter`. Package resolution
  order: `KUJO_MCP_PATH`, walk-up `kennel.toml` identity, the analyzed
  repository's Kennel lockfile, and the ecosystem install root
  (`$KUJO_INSTALL_ROOT/sources/mcp`, default `~/.kujo/sources/mcp`).
  Repository tests cover the first-class help surfaces, cwd/relative/absolute
  repository targeting, option forwarding, deterministic generation,
  preserved safety classifications, dry-run no-write behavior, and
  missing-repository failures.
- Add standard MCP JSON-RPC initialization, ping, tools, resources, and prompts
  methods to the demo and generated HTTP servers.
- Add hard recursive scan ceilings, symlink exclusion, truncation metadata, an
  opt-in minute-bounded cache, and a fail-closed shared-gateway rate-limit hook.
- Add the canonical demo `mcp.manifest.json`, an architecture overview, and an
  authoritative repository roadmap.

### Changed

- README and command reference document `cd my-project && kujo mcp make` for
  runtimes that contain the new command group. Release compatibility remains
  explicit: the examples and Kennel make alias retain `kujo run mcp.kujo
  --interpreter make ...` until the runtime change ships in a release.
- Generated `mcp-findings` artifacts no longer report a missing native CLI
  dispatch now that the runtime exposes `kujo mcp`. Enrichment findings now
  report actual provider outcomes instead of recommending an interface that
  already exists, and enrichment launches the child runtime with structured
  argv/environment handling so credentials never enter shell command text.
- Add a non-publishing release preflight for validating the first-class CLI,
  ecosystem-installed MCP package resolution, and the complete standalone CLI
  regression suite against an exact candidate or published Kujo binary.
- Generated servers now fail closed on invalid configuration and enforce host,
  authentication, request-body, rate, tool/resource enablement, timeout, and
  maximum-file-size settings.
- Audit logs retain bounded operation metadata without arguments, results,
  untrusted tool names, or raw failure text.
- CI and package compatibility now target published Kujo 1.7.0.

## [1.2.0] - 2026-09-29

### Added

- Experimental Dispatch-controlled local STDIO Ability execution, host-owned one-use admission, bounded content references and explicit completion uncertainty.
- Request/tool/Ability/Dispatch correlation with duplicate, framing, substitution and privacy checks. Dispatch alone decides replay.

### Changed

- Pin the released Ability 1.2.0 source and regenerate its immutable Kennel lock; canonical v1 projection/receipt contracts remain unchanged.
- Reconcile the release runtime to published Kujo 1.6.0 and refresh package version metadata. Stable Ability contracts remain unchanged; controlled handoffs remain alpha and opt-in.
- Preserve historical host certificates as exact-version evidence. This release does not promote remote trust or publish separate participant SDKs.


## [1.1.1] - 2026-09-04

### Fixed

- Preserve executable file modes for both portable Ability package launchers so npm installs expose the `kujo-ability` command instead of removing an invalid non-executable bin entry.
- Fetch full Git history in CI so immutable host-certification ancestor checks work on hosted runners.

### Changed

- Refresh the host compatibility evidence against VS Code 1.136.1 and the current release source.

## [1.1.0] - 2026-09-02

### Added

- Add automated host evidence capture and a freshness-gated compatibility matrix with explicit non-certification tiers.
- Add the executable canonical Ability gateway with principal-aware discovery,
  policy/approval/idempotency delegation, and normalized MCP receipts.
- Add a tested portable STDIO host package with a Codex plugin, Ability skill,
  Cursor, VS Code, and generic MCP configuration.
- Add Agent Plugins 1.0 packaging, Copilot guidance, a secret-safe connector
  lifecycle, request cancellation, and contract-drift checks.
- Add local, customer-hosted, and managed deployment boundaries plus the
  enterprise security and release-control checklist.
- Add metadata-only Watchdog lifecycle projection for MCP correlation.
- Pin the production-stable Ability 1.0.1 contract package.
- Pin the canonical `ability` package, remove projection-local definition
  validation, add definition digests, and project enabled canonical MCP
  registry exposures with collision checks.

### Security

- Bound repository profiling, skip symlink traversal, cap discovery work, and reject unsafe manifest paths.

### Docs

- Publish the independently versioned CMS, SSG, and MCP Ability Pack launch catalog and final verification evidence.

## [1.0.0] - 2026-08-08

### Added

- Added launch-readiness Spec, Eval suite, Kujo project metadata, and scanner-visible examples surface for prelaunch review gates.
- Added first-party `mcp make` flow (`kujo run mcp.kujo --interpreter make <repo>`) that deterministically analyzes local repositories and generates:
	- repo-specific MCP server scaffold under `.mcp/generated-server`
	- `repo-profile.json` and `mcp.manifest.json`
	- safety-classified tools/resources/prompts with allowlisted safe commands
	- full artifact packet under `.mcp/artifacts` including backlog, validation, handoff, and MCP findings files.
- Added generated-server resource-root enforcement, bounded generated POST request bodies, and stricter manifest allowlist validation.
- Added `docs/MCP_REVIEW_BACKLOG_2026_06_19.md` to capture the next production-readiness, security, performance, functionality, and presentation pass.
- Added modular make pipeline modules under `src/make/` and command orchestration in `src/commands/make.kujo`.
- Added new test coverage for make safety/profile units and full generation integration (`tests/test_04_make_*.kujo`, `tests/feat_06_mcp_make.sh`).

- Defined release/versioning policy and changelog conventions in `docs/release-versioning-policy.md`.
- Added shared runtime resolution scripts (`scripts/find_kujo_runtime.sh` and `scripts/run_server.sh`) and updated tests/docs to avoid PATH collisions with non-runtime `kujo` binaries.
- Added deterministic required-argument validation across tool handlers and a dedicated regression suite (`tests/sec_07_tool_argument_validation.sh`) to prevent exception-style fallback errors.
- Enforced `server.name` and `server.version` config validation and made `/` + `/mcp/v1/health` return identity fields sourced from config instead of hardcoded values.
- Added multi-root integration coverage (`tests/feat_05_multi_root_contracts.sh`) for `project://docs`, `search_files`, and `list_tree_recursive` root-label behavior, and hardened directory normalization in tool resolvers.
- Fixed safe write/read error handling to stringify structured runtime errors safely and avoid transport-level exceptions in tool responses.
- Made safe writes overwrite existing files deterministically and expanded multi-root contracts to assert sequence-safe `write_text_safe` behavior.
- Added repeated-write assertions in multi-root integration coverage to verify overwrite semantics remain stable under the same file path.
- Updated multi-root contract test cleanup to remove generated root1 patch artifacts, keeping local runs and CI worktrees deterministic.
- Clarified `write_text_safe` overwrite semantics and multi-root create-target rules in `docs/mcp-reference.md`.

### Fixed

- Fixed the README version badge to match `kennel.toml` package metadata.
