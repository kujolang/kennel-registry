# Runtime bundles and offline installation

Runtime bundles contain the complete SearchBridge source tree and the exact
Kujo executable used to qualify it. The launchers prefer `runtime/kujo` (or
`runtime/kujo.exe`) and therefore need no network access or machine-wide Kujo
installation after extraction.

`scripts/build_runtime_bundle.sh` accepts `linux-x64`, `macos-x64`,
`macos-arm64`, or `windows-x64` and requires `KUJO_BIN` plus the pinned
`KUJO_COMMIT`. It normalizes timestamps and archive ordering, writes an embedded
manifest binding both source and runtime, and creates an adjacent SHA-256 file.
The checksum names only the archive basename, so it remains verifiable after
download or relocation to any directory.

The retained release-candidate artifact also contains `RC-SHA256SUMS`, rooted
at the artifact extraction directory, for one-command verification of every
bundle, SDK package, benchmark, SBOM, and provenance document.

The platform workflow builds each runtime from the pinned Kujo commit, creates
the bundle twice, requires byte-identical hashes, extracts it into a clean
temporary directory, and executes an offline fixture with an empty environment.
The bundle and checksum are retained as workflow evidence.

To install from the supported GitHub release channel, download the archive and
its adjacent `.sha256`, verify the checksum, extract the archive, and put its
directory on `PATH` or invoke `searchbridge` / `searchbridge.ps1` directly.
Credentials are still supplied only through the operator's environment for live
runs; they are never included in a bundle.

To upgrade, repeat those steps into a new directory, run `doctor` plus a fixture
smoke before switching `PATH`, and retain the previous verified directory for
rollback. Uninstall by removing only the extracted SearchBridge directory;
cache, evidence, and task-state directories are operator data and are not
removed automatically.

Independent source-release verification (`scripts/verify_release.kujo`) also
requires Node.js and a GitHub CLI version supporting `gh attestation verify`.
It verifies the signed tag and both release attestations, restricts attestation
identity to this repository's release workflow, and compares bounded TAR/ZIP
members to `git archive` without extracting them. Source-release archives with
links, unsafe paths, unsupported extended metadata, mismatched executable bits,
or altered contents fail closed. Set `SEARCHBRIDGE_VERIFY_ARCHIVE_HELPER` only
when the checked-in Node helper is installed at a different path. Runtime
bundles and ordinary CLI execution do not acquire new dependencies.
