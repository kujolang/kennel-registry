# SiteKit Design System

Generated for SiteKit 1.0.0 by scripts/generate-design-md. Edit tokens, components, recipes, and standards first.

## Purpose

SiteKit v1 is a stable, AI-readable, human-verifiable design system for accessible, semantic, token-driven websites and web interfaces.

## Philosophy

- Clarity, context, and control.
- Local-first where possible.
- Agent-readable and human-verifiable.
- Accessible, semantic, tokenized, modular, and extensible by default.

## Consumer Contract

Copy or vendor `dist/` as a unit. Use `dist/sitekit.css` as the supported CSS entry point and keep its sibling `fonts/` directory. Add `dist/sitekit.js` only when a consumer opts into behavior enhancement. The bundle is ordered reset, tokens, themes, base, components, utilities and works from `file://` or a local HTTP server. npm registry publication is outside the v1 contract. See [README.md](README.md) and [docs/components.md](docs/components.md).

## Stable v1 Scope

- Design tokens and bundled themes.
- Component schemas and semantic HTML templates.
- Generated component CSS and layout recipes.
- Documented accessibility, responsive, and progressive-enhancement contracts.
- `dist/sitekit.css`, optional `dist/sitekit.js`, and bundled Departure Mono font assets and license.
- Deterministic generation, validation, and representative static HTML consumers.

The v1 promise does not include npm publication, a hosted component service, universal framework compatibility, accessibility certification for arbitrary downstream compositions, unsupported-browser visual parity, or behavior for markup that omits documented hooks.

## Optional Behavior

Dropdowns, popovers, drawers, modals, tooltips, theme controls, and icon-button contracts are progressive enhancements. Static HTML remains readable without JavaScript. Behavior hooks are documented in each relevant component and in the generated component index.

## Visual Identity

Technical, architectural, command-surface minimalism with high contrast, near-white page foundations, white panels, black linework, no decorative shadows, monospace metadata labels, and square geometry.

## Accessibility Standard

WCAG 2.2 AA is the design and test baseline for SiteKit source components, documented usage, and tested reference compositions. Prefer native HTML before ARIA. Interactive controls require keyboard access, visible focus, and reduced-motion-safe behavior. This is not certification of arbitrary downstream markup.

## Semantic HTML Standard

Use landmarks, ordered headings, real buttons, real links, lists for lists, and tables for tabular data. ARIA only fills gaps that native HTML cannot express.

## Token System

Tokens are split into primitive tokens in tokens/core.json, semantic tokens in tokens/semantic.json, and theme overrides in tokens/themes/*.json. Component CSS consumes semantic tokens and never owns theme values.

## Themes

- bzby: Compact commercial theme with sharper signal states.
- kujo-dark: Dark Kujo technical interface theme.
- kujo-light: Monochrome Kujo command surface with white panels and hard black structure.
- personal-dark: Personal publishing dark theme with restrained contrast.

## Components

- Accordion: A stacked disclosure control for expandable sections.
- Alert: A status message for success, warning, error, or neutral feedback.
- Avatar: A compact visual identity marker for a person, team, or object.
- Badge: A compact status, category, or metadata label.
- Bento Grid: A square-cornered modular grid for grouped capabilities, proof points, or portfolio services.
- Breadcrumbs: A navigational trail that shows the current page location.
- Button: A semantic action control for links, form submits, and interface commands.
- Card: A bounded content region for a single object, summary, or grouped action.
- Carousel: A grouped media or content sequence with explicit navigation controls.
- Checkbox: A binary input that can be checked or unchecked.
- Checkout Summary: A commerce order summary with totals, taxes, discounts, and trust metadata.
- Code Block: A readable code or command block with caption and copy action.
- Color Picker: A native color control with an accessible label.
- Combobox: An autocomplete text input paired with suggested options.
- Command Strip: A compact operational metric strip for status, filters, or system state.
- Content Section: A responsive editorial section with copy, actions, and an optional media or proof panel.
- CTA: A conversion block with a clear next action.
- Date Input: A native date input with label and help text.
- Date Picker: A compact date-picker surface with a visible calendar grid.
- Drawer: A side panel for secondary navigation or contextual actions.
- Dropdown Menu: A menu button with grouped actions.
- Ecosystem Map: A semantic map of projects, packages, docs, and relationships.
- Empty State: A clear message for empty collections with optional recovery action.
- Error State: A recoverable error message with next steps and support context.
- Feature Grid: A responsive list of capabilities or benefits.
- Fieldset: A grouped set of form controls with a legend.
- File: A file metadata row for selected or attached files.
- File Upload: A file input drop area with a clear label.
- Footer: A semantic page footer for navigation, metadata, and legal links.
- Form: A semantic form layout for labeled controls and actions.
- Form Field: A labeled input group with help, validation, and autocomplete support.
- Generator Panel: A form-forward tool panel for small generators, prompts, and preview controls.
- Header: A top-level site header with navigation and primary action.
- Heading: A typographic heading pattern with optional supporting text.
- Hero: A first-viewport introduction for product, documentation, and launch pages.
- Icon: A small symbolic marker with an accessible name when meaningful.
- Image: A responsive image frame with optional caption.
- Label: A compact text label for form fields or metadata.
- Link: A text link with visible focus and hover states.
- List: A semantic ordered or unordered list with consistent spacing.
- Metadata Panel: A compact key-value panel for operational metadata and object facts.
- Modal: An interruptive dialog that requires deliberate focus management.
- Navigation: A semantic navigation region for primary or secondary links.
- Newsletter Signup: A focused email capture block with semantic form controls and compact supporting copy.
- Pagination: A page navigation control for long result sets.
- Partners Strip: A logo or partner proof row with semantic list structure and theme-safe styling.
- Popover: A small contextual surface anchored to a trigger.
- Pricing Table: A commercial pricing comparison layout with plans and features.
- Product Card: A semantic commerce product summary with media, price, and actions.
- Product Grid: A responsive product listing surface.
- Product Showcase: A compact commerce or template showcase adapted from legacy landing-page demos.
- Progress Bar: A horizontal progress meter for determinate completion.
- Progress Indicator: A compact step or status indicator for multi-step flows.
- Promo Banner: A dismissible commercial or release announcement banner.
- Quote: A pull quote or testimonial block with citation.
- Radio Button: A single-choice input within a related option group.
- Rating: A rating display or input for qualitative feedback.
- Recent Posts: A semantic article-list component for blog previews and latest insights.
- Resource Links: A compact link collection for docs, examples, templates, and external references.
- Rich Text Editor: A text editing surface with formatting controls.
- Roadmap: A chronological product timeline for milestones, launches, and upcoming work.
- Search Input: A search field with a visible submit action.
- Segmented Control: A compact grouped control for switching modes.
- Select: A native select control with label and options.
- Separator: A semantic visual divider between related sections.
- Skeleton: A placeholder surface that indicates loading content.
- Skip Link: An accessible link for skipping directly to page content.
- Slider: A range input for selecting a numeric value.
- Spinner: A compact indeterminate loading indicator.
- Stack: A vertical layout primitive for consistent spacing.
- Stats Bar: A semantic metric strip for proof points, performance numbers, or portfolio counters.
- Stepper: A numeric input with increment and decrement actions.
- Table: A semantic table for structured comparison or tabular data.
- Tabs: A keyboard navigable view switcher for related panels.
- Team Grid: A responsive people grid for profiles, roles, and compact bios.
- Testimonial Rail: A scroll-safe testimonial layout for customer quotes and builder proof.
- Text Input: A single-line text input with a visible label.
- Textarea: A multi-line text input with label and help text.
- Toast: A non-modal notification for transient feedback.
- Toggle: A binary switch-style control using a native checkbox.
- Tooltip: A short contextual text hint for an adjacent control.
- Tree View: A hierarchical navigation or selection tree.
- Trust Strip: A compact proof row for security, shipping, warranties, or social proof.
- Video: A responsive video embed frame with caption.
- Visually Hidden: A utility wrapper for content available to assistive technology only.

## Layout Recipes

- Blog Index: Composable blog index recipe.
- Source of Truth Dashboard: Composable operational dashboard recipe for repository metadata, status, filters, and source links.
- Docs Home: Composable documentation home recipe.
- Ecommerce Page: Composable ecommerce recipe.
- Ecosystem Page: Composable ecosystem map recipe.
- Launch Page: Composable launch page recipe using SiteKit components.
- Pricing Page: Composable pricing page recipe.
- Product Page: Composable product page recipe.

## Agent Rules

1. Read this file and relevant component schemas before generating UI.
2. Use existing components before creating new patterns.
3. Use tokens instead of raw visual values.
4. Preserve semantic HTML and accessibility behavior.
5. Run npm run build and npm run lint after changes.

## Anti-Patterns

- One-off card styles.
- Raw hex colors in component CSS.
- Clickable divs.
- Skipped heading hierarchy.
- Inaccessible modals or tabs.
- Decorative motion without reduced-motion fallback.
- Generic purple AI gradients or unrelated visual language.

## Validation Commands

npm run format:check
npm run build
npm run lint
npm run validate
npm run snapshot
npm run smoke
npm run browser:test
npm run release:check

## Extension Process

Add a component folder with schema, template, CSS, docs, and examples. Add token dependencies to semantic tokens if a visual decision must be themeable. Add or update recipes only after component contracts exist.
