# SiteKit Agent Instructions

SiteKit is source-driven. Treat tokens, schemas, templates, component CSS, recipes, and standards as authoritative. DESIGN.md is generated or generator-ready guidance, not the only source of truth.

SiteKit v1 is a stable source-vendored distribution. Keep `private: true`, treat `dist/` as the supported consumer artifact, preserve the sibling `fonts/` relationship, and do not hand-edit generated outputs. npm publication of the root asset package and hosted component services are outside the v1 contract. The separately versioned `packages/sitekit-cli` package is the authorized optional npm developer tool; keep its releases independent of asset releases and Kujo core.

## Before Creating Or Editing UI

1. Read DESIGN.md.
2. Read relevant component schemas.
3. Use existing components before creating new ones.
4. Use tokens, never raw visual values.
5. Preserve semantic HTML.
6. Preserve accessibility behavior.
7. Run validation checks.
8. If a component fails, fix the reusable component source, not only the page.
9. If a new pattern is needed, propose it as a documented component.
10. Run formatting, generation, validation, browser, and release-content gates before release changes.

## Anti-Patterns

- Do not invent one-off card styles.
- Do not use raw hex colors in component CSS.
- Do not skip heading hierarchy.
- Do not replace buttons with clickable divs.
- Do not remove focus styles.
- Do not create inaccessible modals.
- Do not add decorative motion without reduced-motion fallback.
- Do not introduce unrelated visual language.

## Public project boundary

Keep unrelated customer, client, brand, personal-site and course-project identities out of Kujo source, documentation, fixtures, commit messages and published artifacts. Generalize requirements and use synthetic examples. Do not copy private repository links, chat identifiers, memory IDs or customer-specific evidence into public work. Keep necessary private provenance in local memory only.
