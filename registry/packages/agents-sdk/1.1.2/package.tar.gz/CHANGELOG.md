# Changelog

## 1.1.2 — 2026-09-28

- Restore the required ArtifactStore module in Kennel distributions after reconciling both the reusable workflow and its publisher source checkout. Runtime source remains unchanged from 1.1.0.
- Use 1.1.2 for registry installation. The 1.1.0 and 1.1.1 GitHub source releases are intact, but their immutable registry archives omitted `src/agents/artifacts/store.kujo`.

## 1.1.1 — 2026-09-28

- Attempted a new immutable package after the Kennel publisher fix to restore `src/agents/artifacts/store.kujo` in registry distributions. Runtime source is unchanged from 1.1.0.
- Superseded by 1.1.2: the workflow still checked out the older publisher. Do not use 1.1.1 for registry installation; the 1.1.0 GitHub source is intact, but its registry archive omitted this required module and is retained unchanged.


## 1.1.0 — 2026-09-28

### Context accounting

- Verify real observer delivery after hook composition, retain non-sensitive durable evidence under the existing redaction policy, and export the context APIs with an offline example.
- Integrate opt-in context preparation, typed child evidence, verified resume, dispatch receipts and CI token regression checks without changing default payloads.
- Add explicit progressive skill loading with mandatory safety artifacts, exact triggers and dependency validation.
- Add deterministic tool catalogs/schema expansion, executable registry scoping, and exact structural repository selection.
- Add typed handoff validation and compact SessionStore recovery state with full evidence retained in ArtifactStore.
- Add versioned context manifests as existing Artifact metadata, with hash-verified retrieval and fail-closed source invalidation.
- Add opt-in metadata-only context cost observation at the AI adapter boundary; provider usage remains distinct from heuristic estimates.

### Integration

- Pin the production-stable Ability 1.0.1 contract and runtime package.
- Pin the canonical `ability` package, remove the duplicated schema, expose
  definition digests, and register Ability projections through the standard
  Tool registry.
- Add receipt-validating remote Ability gateway tools and preserve canonical
  receipts in Tool execution metadata.
- Add `convert_agent_to_dispatch` and `validate_dispatch_agent_conversion` helpers for producing executable Dispatch model-agent definitions from the shared agent contract.
- Add launch readiness spec and deterministic Eval suite for prelaunch review evidence.
- Preserve the existing stable local-first API contracts; controlled interoperability remains experimental.

### Experimental controlled Ability interoperability

- Add experimental host-admitted Ability gateway tools and bounded immutable
  handoff references; standalone gateway tools retain their existing behavior.
- Carry model-call and SDK invocation attribution only for controlled tools.
- Add a real offline SDK participant for Dispatch beta review/replay integration,
  private receipt retention and existing Watchdog lifecycle observations.

- Validate the full offline and context gates on Kujo 1.6.0. Dispatch remains the sole replay/admission authority.

## 1.0.0 - 06/10/2026

- initial release
