#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB_PATH="${CMS_DB_PATH:-${ROOT_DIR}/cms.db}"
LIMIT="${CMS_WEBHOOK_PROCESS_LIMIT:-50}"
RETRY_BASE_SEC="${CMS_WEBHOOK_RETRY_BASE_SEC:-30}"
CONNECT_TIMEOUT_SEC="${CMS_WEBHOOK_CONNECT_TIMEOUT_SEC:-3}"
MAX_TIME_SEC="${CMS_WEBHOOK_MAX_TIME_SEC:-10}"
CLAIM_TTL_SEC="${CMS_WEBHOOK_CLAIM_TTL_SEC:-900}"
ALLOW_HTTP="${CMS_PLUGIN_HOOK_ALLOW_HTTP:-false}"
ALLOW_PRIVATE="${CMS_PLUGIN_HOOK_ALLOW_PRIVATE:-false}"
SCRIPT_LABEL="Webhook outbox processor"

fail() {
	echo "${SCRIPT_LABEL}: $1"
	exit 1
}

require_command() {
	local command_name="$1"
	if ! command -v "${command_name}" >/dev/null 2>&1; then
		fail "${command_name} is required"
	fi
}

delivery_status() {
	local status="$1"
	local outbox_id="$2"
	local event_type="$3"
	local details="$4"
	echo "[${status}] outbox_id=${outbox_id} event=${event_type} ${details}"
}

if [[ ! -f "${DB_PATH}" ]]; then
	fail "database not found at ${DB_PATH}"
fi

require_command sqlite3
require_command python3
source "${ROOT_DIR}/scripts/worker-lifecycle.sh"

sqlite3() {
	command sqlite3 -cmd ".timeout 5000" "$@"
}

if ! [[ "${CLAIM_TTL_SEC}" =~ ^[0-9]+$ ]] || [[ "${CLAIM_TTL_SEC}" -lt 30 ]]; then
	CLAIM_TTL_SEC="900"
fi
if ! [[ "${MAX_TIME_SEC}" =~ ^[0-9]+$ ]] || [[ "${MAX_TIME_SEC}" -lt 1 ]]; then
	MAX_TIME_SEC="10"
fi
minimum_claim_ttl="$((MAX_TIME_SEC + 30))"
if [[ "${CLAIM_TTL_SEC}" -lt "${minimum_claim_ttl}" ]]; then
	CLAIM_TTL_SEC="${minimum_claim_ttl}"
fi

WORKER_TOKEN="$(python3 -c 'import secrets; print(secrets.token_hex(16), end="")')"

sql_escape() {
	printf '%s' "$1" | sed "s/'/''/g"
}

decode_hex() {
	printf '%s' "$1" | xxd -r -p
}

now_epoch() {
	date +%s
}

resolve_handler_target() {
	local handler_url="$1"
	python3 - "${handler_url}" "${ALLOW_HTTP}" "${ALLOW_PRIVATE}" "${CONNECT_TIMEOUT_SEC}" <<'PY'
import ipaddress
import json
import subprocess
import sys
from urllib.parse import urlsplit

url = urlsplit(sys.argv[1])
allow_http = sys.argv[2].strip().lower() in {"1", "true", "yes", "on"}
allow_private = sys.argv[3].strip().lower() in {"1", "true", "yes", "on"}

if url.scheme not in ({"http", "https"} if allow_http else {"https"}):
    raise SystemExit(1)
if not url.hostname or url.username is not None or url.password is not None:
    raise SystemExit(1)

labels = url.hostname.lower().split(".")
numeric_alias = bool(labels)
for label in labels:
    if label.startswith("0x"):
        try:
            int(label[2:], 16)
        except ValueError:
            numeric_alias = False
            break
    elif not label.isdigit():
        numeric_alias = False
        break
if numeric_alias:
    canonical_decimal = len(labels) == 4 and all(
        label.isdigit() and (label == "0" or not label.startswith("0")) and 0 <= int(label, 10) <= 255
        for label in labels
    )
    if not canonical_decimal:
        raise SystemExit(1)

port = url.port or (443 if url.scheme == "https" else 80)
try:
    # DNS occurs before curl, so it needs its own bounded process lifetime.
    resolver = "import json,socket,sys; print(json.dumps(sorted({item[4][0] for item in socket.getaddrinfo(sys.argv[1],int(sys.argv[2]),type=socket.SOCK_STREAM)})))"
    resolved = subprocess.run([sys.executable, '-c', resolver, url.hostname, str(port)],
                              capture_output=True, text=True, check=True, timeout=float(sys.argv[4]))
    addresses = json.loads(resolved.stdout)
except (OSError, ValueError, subprocess.SubprocessError):
    raise SystemExit(1)
if not addresses:
    raise SystemExit(1)

translation_networks = (
    ipaddress.ip_network("64:ff9b::/96"),
    ipaddress.ip_network("64:ff9b:1::/48"),
    ipaddress.ip_network("2001::/32"),
    ipaddress.ip_network("2002::/16"),
)
for address in addresses:
    parsed = ipaddress.ip_address(address)
    if not allow_private and not parsed.is_global:
        raise SystemExit(1)
    if not allow_private and parsed.version == 6 and any(parsed in network for network in translation_networks):
        raise SystemExit(1)

selected = addresses[0]
if ":" in selected:
    selected = f"[{selected}]"
try:
    ipaddress.ip_address(url.hostname)
    output_host = "DIRECT"
except ValueError:
    output_host = url.hostname
print(f"{output_host}|{port}|{selected}")
PY
}

rows="$(sqlite3 -separator '|' "${DB_PATH}" "SELECT id FROM webhook_outbox WHERE (status IN ('pending','retry') AND CAST(next_attempt_at AS INTEGER) <= CAST(strftime('%s','now') AS INTEGER)) OR (status = 'running' AND CAST(COALESCE(claim_expires_at, 0) AS INTEGER) <= CAST(strftime('%s','now') AS INTEGER)) ORDER BY id ASC LIMIT ${LIMIT};")"

if [[ -z "${rows}" ]]; then
	echo "${SCRIPT_LABEL}: no due deliveries"
	exit 0
fi

processed=0
delivered=0
retried=0
dead_lettered=0

while IFS= read -r outbox_id; do
	[[ -z "${outbox_id}" ]] && continue
	now_value="$(now_epoch)"
	claim_expires_at="$((now_value + CLAIM_TTL_SEC))"
	claimed="$(sqlite3 -separator '|' "${DB_PATH}" "BEGIN IMMEDIATE; UPDATE webhook_outbox SET status = 'running', claim_token = '${WORKER_TOKEN}', claim_expires_at = '${claim_expires_at}', updated_at = '${now_value}' WHERE id = ${outbox_id} AND ((status IN ('pending','retry') AND CAST(next_attempt_at AS INTEGER) <= ${now_value}) OR (status = 'running' AND CAST(COALESCE(claim_expires_at, 0) AS INTEGER) <= ${now_value})); SELECT hook_id, event_id, event_type, hex(payload_json), hex(handler_url), hex(shared_secret), attempt_count, max_attempts FROM webhook_outbox WHERE id = ${outbox_id} AND claim_token = '${WORKER_TOKEN}'; COMMIT;")"
	if [[ -z "${claimed}" ]]; then
		continue
	fi
	IFS='|' read -r hook_id event_id event_type payload_hex handler_url_hex shared_secret_hex attempt_count max_attempts <<< "${claimed}"
	processed=$((processed + 1))
	start_worker_heartbeat webhook_outbox "${outbox_id}" "$$"

	payload_json="$(decode_hex "${payload_hex}")"
	handler_url="$(decode_hex "${handler_url_hex}")"
	shared_secret="$(decode_hex "${shared_secret_hex}")"

	signature="$(printf '%s' "${payload_json}.${shared_secret}" | shasum -a 256 | awk '{print $1}')"
	policy_error=""
	resolved_target=""
	if ! resolved_target="$(resolve_handler_target "${handler_url}")"; then
		policy_error="egress_policy_denied"
	fi

	if [[ -n "${policy_error}" ]]; then
		http_status="000"
		curl_exit_code=90
	else
		IFS='|' read -r resolved_host resolved_port resolved_ip <<< "${resolved_target}"
		curl_resolution_args=( --noproxy "*" )
		if [[ "${resolved_host}" != "DIRECT" ]]; then
			curl_resolution_args+=( --resolve "${resolved_host}:${resolved_port}:${resolved_ip}" )
		fi
		set +e
		http_status="$(curl "${curl_resolution_args[@]}" -sS -o /dev/null -w "%{http_code}" -X POST "${handler_url}" \
			-H "Content-Type: application/json" \
			-H "X-CMS-Webhook-Event: ${event_type}" \
			-H "X-CMS-Webhook-Id: ${event_id}" \
			-H "X-CMS-Webhook-Signature: sha256=${signature}" \
			--connect-timeout "${CONNECT_TIMEOUT_SEC}" \
			--max-time "${MAX_TIME_SEC}" \
			--data "${payload_json}")"
		curl_exit_code=$?
		set -e
	fi
	stop_worker_heartbeat

	now_value="$(now_epoch)"
	if [[ ${curl_exit_code} -eq 0 && "${http_status}" =~ ^2[0-9][0-9]$ ]]; then
		next_attempt_count=$((attempt_count + 1))
		updated="$(sqlite3 "${DB_PATH}" "UPDATE webhook_outbox SET status = 'delivered', attempt_count = ${next_attempt_count}, last_error = NULL, last_status_code = ${http_status}, delivered_at = '${now_value}', updated_at = '${now_value}', claim_token = NULL, claim_expires_at = NULL WHERE id = ${outbox_id} AND claim_token = '${WORKER_TOKEN}'; SELECT changes();")"
		if [[ "${updated}" != "1" ]]; then continue; fi
		delivered=$((delivered + 1))
		delivery_status "DELIVERED" "${outbox_id}" "${event_type}" "status=${http_status}"
		continue
	fi

	next_attempt_count=$((attempt_count + 1))
	error_message=""
	if [[ -n "${policy_error}" ]]; then
		error_message="${policy_error}"
	elif [[ ${curl_exit_code} -ne 0 ]]; then
		error_message="curl_exit_${curl_exit_code}"
	else
		error_message="http_${http_status}"
	fi
	escaped_error="$(sql_escape "${error_message}")"

	if [[ ${next_attempt_count} -ge ${max_attempts} ]]; then
		updated="$(sqlite3 "${DB_PATH}" "BEGIN IMMEDIATE; UPDATE webhook_outbox SET status = 'dead_letter', attempt_count = ${next_attempt_count}, last_error = '${escaped_error}', last_status_code = ${http_status:-0}, updated_at = '${now_value}' WHERE id = ${outbox_id} AND claim_token = '${WORKER_TOKEN}'; SELECT changes(); INSERT OR REPLACE INTO webhook_dead_letters (outbox_id, hook_id, event_id, event_type, payload_json, handler_url, shared_secret, attempt_count, last_error, last_status_code, failed_at, created_at) SELECT id, hook_id, event_id, event_type, payload_json, handler_url, shared_secret, attempt_count, '${escaped_error}', ${http_status:-0}, '${now_value}', '${now_value}' FROM webhook_outbox WHERE id = ${outbox_id} AND claim_token = '${WORKER_TOKEN}'; UPDATE webhook_outbox SET claim_token = NULL, claim_expires_at = NULL WHERE id = ${outbox_id} AND claim_token = '${WORKER_TOKEN}'; COMMIT;")"
		if [[ "${updated}" != "1" ]]; then continue; fi
		dead_lettered=$((dead_lettered + 1))
		delivery_status "DEAD-LETTER" "${outbox_id}" "${event_type}" "attempts=${next_attempt_count}/${max_attempts}"
	else
		next_attempt_at=$((now_value + (RETRY_BASE_SEC * next_attempt_count)))
		updated="$(sqlite3 "${DB_PATH}" "UPDATE webhook_outbox SET status = 'retry', attempt_count = ${next_attempt_count}, last_error = '${escaped_error}', last_status_code = ${http_status:-0}, next_attempt_at = '${next_attempt_at}', updated_at = '${now_value}', claim_token = NULL, claim_expires_at = NULL WHERE id = ${outbox_id} AND claim_token = '${WORKER_TOKEN}'; SELECT changes();")"
		if [[ "${updated}" != "1" ]]; then continue; fi
		retried=$((retried + 1))
		delivery_status "RETRY" "${outbox_id}" "${event_type}" "attempts=${next_attempt_count}/${max_attempts}"
	fi

done <<< "${rows}"

echo "${SCRIPT_LABEL} summary: processed=${processed} delivered=${delivered} retried=${retried} dead_lettered=${dead_lettered}"
