# SiteKit Docs Template

A polished, self-contained documentation starter for [Kujo SSG](https://github.com/kujolang/ssg), styled with [SiteKit](https://github.com/kujolang/site-kit). It is the reusable, product-neutral version of the design created for the Kujo language documentation site.

The repository is intentionally boring to adopt: download it, edit a few values, replace the example Markdown, and build. The SSG entrypoint, SiteKit distribution, local search generator, templates, assets, and validation script are already included.

## Start in one minute

You need the `kujo` CLI on your `PATH`.

```bash
git clone https://github.com/kujolang/sitekit-docs-template.git my-docs
cd my-docs
./scripts/build.sh
kujo serve output --port 4178
```

Open <http://127.0.0.1:4178>. The first build requires no package install and no network access.

Before publishing, edit `site_title`, `site_tagline`, and `site_url` in `kujo-ssg.yml` or override the URL for one build:

```bash
SITE_URL=https://docs.example.com ./scripts/build.sh
```

## Make it yours

| Change | File or directory |
| --- | --- |
| Site name, URL, output, sorting | `kujo-ssg.yml` |
| Homepage message and links | `templates/page-home.html` |
| Header, footer, and search | `templates/layout.html` |
| Documentation pages | `content/pages/` |
| Guides, concepts, or reference | matching folders under `content/` |
| Visual extensions | `assets/css/style.css` |
| Search, menu, and copy behavior | `assets/js/docs.js` |

Replace the example Markdown with your own content. Top-level folders other than `pages` and `posts` become collections automatically. For example, `content/guides/install.md` becomes `/guides/install/`, and the SSG creates `/guides/` from `templates/page-guides.html`.

The primary navigation is generated from visible pages and collections. Set `nav_hide: true` on a page when it should be reachable without appearing in navigation.

## Page metadata

Use the `docs` template when you want the sidebar, page metadata, prerequisites, previous/next controls, and table of contents:

```yaml
---
title: Install the CLI
description: Install the command-line tools and verify your environment.
custom_url: install
template: docs
section: Getting started
nav_title: Install
order: 20
audience: developer
difficulty: beginner
status: stable
version: current
prerequisites:
  - A supported operating system
previous: /start-here/
next: /guides/first-guide/
tags: [install, cli]
---
```

Useful fields include `title`, `description`, `custom_url`, `template`, `section`, `nav_title`, `nav_hide`, `order`, `audience`, `difficulty`, `status`, `version`, `last_updated`, `prerequisites`, `previous`, `next`, `tags`, `draft`, `search_exclude`, and the standard SEO fields documented by Kujo SSG.

## Content model

- `content/pages/` creates root pages such as `/start-here/`.
- `content/posts/` creates dated articles under `/blog/`.
- Any other direct child of `content/` becomes a collection with its own index.
- `template: docs` selects `templates/page-docs.html` for pages and `templates/post-docs.html` for posts or collection items.
- A collection can override its listing with `templates/page-<collection>.html`.

The checked-in examples demonstrate all three content shapes without describing a specific product or ecosystem.

## Design system boundary

`assets/sitekit/` is the complete, unmodified SiteKit 1.0.0 consumer distribution. Keep the directory intact: `sitekit.css` expects its sibling `fonts/` folder.

Template-specific CSS lives in `assets/css/style.css`. It uses SiteKit semantic tokens and preserves the source site's monochrome, square-cornered technical style. Extend that file for site compositions; change SiteKit itself in the upstream SiteKit repository and replace the complete distribution when upgrading.

The template uses SiteKit's `kujo-light` theme identifier because that is the stable name of the monochrome light theme in SiteKit 1.0.0. It does not add Kujo branding or Kujo-specific documentation content.

## Build, test, and package

```bash
./scripts/build.sh
bash scripts/test-template.sh
./scripts/package.sh
```

- `build.sh` refreshes the local search index, runs the SSG, and validates generated HTML.
- `test-template.sh` checks the source contract and verifies representative generated routes and assets.
- `package.sh` creates `dist/sitekit-docs-template-v1.0.0.tar.gz`, excluding generated output and Git metadata. Extract it into an empty directory.

Generated files go under `output/`; do not edit them by hand.

## Upgrade the vendored tools

The pinned versions and local patch are documented in `UPSTREAM.md`. Upgrade deliberately:

1. Replace `build.kujo` with a reviewed Kujo SSG release entrypoint.
2. Reapply or remove the documented generic collection-label patch.
3. Replace `assets/sitekit/` with the complete SiteKit release `dist/` directory.
4. Run `bash scripts/test-template.sh` and review the rendered desktop and mobile site.

## License

The template is MIT licensed. Vendored dependencies and the Departure Mono font retain their own notices; see `THIRD_PARTY_NOTICES.md` and `assets/sitekit/`.
