---
title: Write your first guide
description: Add a task-oriented page with useful metadata, clear steps, and a next action.
custom_url: first-guide
template: docs
section: Guides
order: 10
audience: documentation author
difficulty: beginner
status: stable
version: current
prerequisites:
  - A specific reader task
previous: /start-here/
next: /concepts/documentation-structure/
tags: [writing, guides]
---

A guide should help one reader complete one meaningful task. Start from the result, then include only the context needed to reach it safely.

## Create the file

Add a Markdown file under `content/guides/`:

```text
content/guides/connect-a-service.md
```

Use `template: docs` in frontmatter to enable the metadata panel, prerequisites, table of contents, and previous/next controls.

## Write for completion

1. Name the outcome in the title and description.
2. List prerequisites that can actually block the task.
3. Keep commands and examples copyable.
4. Describe the result the reader should observe.
5. Link to troubleshooting or the next likely task.

## Build and inspect

```bash
./scripts/build.sh
kujo serve output --port 4178
```

Your new page appears at `/guides/connect-a-service/` and in the generated Guides listing.

