---
title: Site configuration
description: Reference for the starter's most important Kujo SSG settings and build overrides.
custom_url: site-configuration
template: docs
section: Reference
order: 10
audience: maintainer
difficulty: reference
status: stable
version: current
previous: /concepts/documentation-structure/
next: /customize/
tags: [configuration, build]
---

The root `kujo-ssg.yml` file controls the site identity and build directories.

## Core settings

| Setting | Purpose | Starter value |
| --- | --- | --- |
| `site_url` | Absolute production origin used for canonical URLs and feeds | `http://127.0.0.1:4178` |
| `site_title` | Brand text and metadata name | `Your Project Docs` |
| `site_tagline` | Default description and footer copy | Generic starter copy |
| `content` | Markdown source root | `content` |
| `templates` | HTML template root | `templates` |
| `assets` | Static asset root | `assets` |
| `output` | Disposable generated site | `output` |
| `sort_by` | Ordering for posts and collection items | `order` |

## Publication settings

The starter uses `robots: private` so an unchanged example is not intentionally indexed. Change it to `public` when the site is ready. `llms: public` emits a machine-readable documentation index when `site_url` is set.

## One-build URL override

Use the environment variable supported by the wrapper:

```bash
SITE_URL=https://docs.example.com ./scripts/build.sh
```

Any additional arguments passed to `scripts/build.sh` are forwarded to the vendored SSG entrypoint.

