---
title: Start here
description: Find the shortest path through this example documentation site.
custom_url: start-here
template: docs
section: Getting started
nav_title: Start here
order: 10
audience: all readers
difficulty: beginner
status: stable
version: current
next: /guides/first-guide/
tags: [orientation, onboarding]
---

This starter organizes documentation around what a reader is trying to accomplish. Replace this introduction with the first successful path for your project.

## Pick a direction

- **I am brand new** → explain the smallest useful outcome on this page.
- **I have a task to complete** → send readers to the [guides](/guides/).
- **I need background** → collect mental models under [concepts](/concepts/).
- **I need an exact detail** → keep lookup material under [reference](/reference/).

## Make the first path concrete

1. State what the reader will accomplish.
2. List any real prerequisites.
3. Give copyable steps in the order they should run.
4. Show the successful result.
5. Link to one sensible next step.

## Next step

Read [your first guide](/guides/first-guide/) to see the full page contract, or open [Customize the template](/customize/) to begin replacing the starter content.

