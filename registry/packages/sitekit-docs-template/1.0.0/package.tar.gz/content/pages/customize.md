---
title: Customize the template
description: Change the identity, navigation, content, and style without fighting the starter.
custom_url: customize
template: docs
section: Maintainers
nav_title: Customize
nav_hide: true
order: 90
audience: maintainer
difficulty: beginner
status: stable
version: current
prerequisites:
  - A local copy of this template
  - The Kujo CLI on PATH
previous: /reference/site-configuration/
tags: [customization, theme]
---

The template separates content, composition, visual extensions, and vendored dependencies so routine changes stay small.

## Change the site identity

Edit `kujo-ssg.yml`:

```yaml
site_url: https://docs.example.com
site_title: Example Product Docs
site_tagline: Practical guidance for building with Example Product.
```

The title flows into metadata, the text brand, the footer, feeds, the sitemap, and `llms.txt`.

## Replace the homepage

Edit `templates/page-home.html`. Keep one `main` landmark with `id="main-content"`, preserve the heading order, and use normal links or buttons for actions.

## Change navigation

Navigation is generated from pages and collections. Use `nav_title` to shorten a page label and `nav_hide: true` to keep a page out of the primary and sidebar navigation.

## Extend the look

Add template-specific rules to `assets/css/style.css`. Reuse the `--sk-*` SiteKit tokens already mapped at the top of the file. Do not edit `assets/sitekit/sitekit.css`; replace the complete SiteKit distribution when upgrading it.

## Verify the result

```bash
bash scripts/test-template.sh
kujo serve output --port 4178
```

Review the home page, a docs page, a collection listing, search, keyboard focus, and the mobile menu before publishing.

