---
title: Documentation starter ready
description: The first build includes a responsive docs design, local search, and example content shapes.
date: 2026-08-08
order: 10
author: Documentation Team
tags: [release, documentation]
---

This example post proves the time-based documentation path. Replace it with release notes, migration announcements, or remove `content/posts/` when the site does not need a blog.

## Included in the starter

- Responsive header, sidebar, and page layouts.
- Local search and code-copy controls.
- Generic pages, guides, concepts, and reference examples.
- Deterministic build, validation, packaging, and CI scripts.

