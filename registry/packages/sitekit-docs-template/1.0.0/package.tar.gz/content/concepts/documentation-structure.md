---
title: Documentation structure
description: Separate learning, tasks, explanations, and lookup material so readers know where to go next.
custom_url: documentation-structure
template: docs
section: Concepts
order: 10
audience: documentation author
difficulty: beginner
status: stable
version: current
previous: /guides/first-guide/
next: /reference/site-configuration/
tags: [information architecture, content model]
---

Readers arrive with different intentions. A small, predictable structure makes the right page easier to find and each page easier to write.

## Pages orient

Use `content/pages/` for root-level entry points such as onboarding, installation, support, and maintenance policies.

## Guides complete tasks

Use `content/guides/` for procedures with a concrete result. A guide should have prerequisites, ordered steps, validation, and a next action.

## Concepts explain

Use `content/concepts/` for architecture, tradeoffs, boundaries, and mental models. Concept pages should help a reader make a decision, not disguise a procedure.

## Reference answers exact questions

Use `content/reference/` for settings, commands, APIs, schemas, and compatibility facts. Optimize these pages for scanning and stable links.

## Posts record change

Use `content/posts/` for time-based release notes and migration announcements. Keep durable task guidance in guides so it does not disappear into a news archive.

