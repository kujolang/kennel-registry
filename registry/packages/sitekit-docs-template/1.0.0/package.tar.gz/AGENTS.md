# Agent Guide

This repository is a reusable documentation template. Keep its rendered content product-neutral and its first build self-contained apart from the Kujo CLI.

## Canonical surfaces

- `content/`: generic example documentation that users replace.
- `templates/`: semantic Kujo SSG templates.
- `assets/css/style.css`: template-specific styles built entirely on SiteKit tokens.
- `assets/sitekit/`: vendored, unmodified SiteKit distribution.
- `assets/js/docs.js`: mobile navigation, local search, and code-copy behavior.
- `build.kujo`: vendored Kujo SSG 1.0.0 entrypoint with the generic collection action label patch documented in `UPSTREAM.md`.

## Rules

- Do not add product-specific claims, logos, repository inventories, or ecosystem navigation to starter content.
- Keep SiteKit's `fonts/` directory beside `sitekit.css`.
- Use semantic HTML, real controls, ordered headings, visible focus, and reduced-motion-safe behavior.
- Use SiteKit tokens instead of raw visual values in template CSS.
- Do not hand-edit `output/` or `assets/js/docs-search-index.json`.

## Validation

```bash
bash scripts/test-template.sh
```

