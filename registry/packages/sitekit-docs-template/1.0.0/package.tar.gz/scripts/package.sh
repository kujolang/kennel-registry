#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VERSION="$(tr -d '[:space:]' < "$REPO_ROOT/VERSION")"
PACKAGE_NAME="sitekit-docs-template-v$VERSION"
DIST_DIR="$REPO_ROOT/dist"
ARCHIVE="$DIST_DIR/$PACKAGE_NAME.tar.gz"

mkdir -p "$DIST_DIR"
tar \
	--exclude='.git' \
	--exclude='dist' \
	--exclude='output' \
	--exclude='assets/js/docs-search-index.json' \
	-C "$REPO_ROOT" \
	-czf "$ARCHIVE" \
	.

printf 'Template package: %s\n' "$ARCHIVE"
