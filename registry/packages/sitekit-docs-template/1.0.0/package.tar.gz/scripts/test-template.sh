#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

fail() {
	printf 'FAIL: %s\n' "$1"
	exit 1
}

assert_path() {
	[[ -e "$1" ]] || fail "missing path: $1"
}

assert_contains() {
	grep -Fq "$2" "$1" || fail "expected '$2' in $1"
}

bash -n scripts/build.sh scripts/package.sh scripts/test-template.sh scripts/validate-generated-output.sh

assert_path assets/sitekit/LICENSE
assert_path assets/sitekit/sitekit.css
assert_path assets/sitekit/sitekit.js
assert_path assets/sitekit/fonts/DepartureMono-Regular.woff2
assert_path assets/sitekit/fonts/DepartureMono-LICENSE.txt

if rg -n 'Kujo Docs|Learn Kujo|Build with Kujo|Kujo ecosystem|docs\.kujolang\.ai' content templates assets/css assets/js; then
	fail "product-specific Kujo documentation leaked into reusable template surfaces"
fi

SITE_URL=https://docs.example.test bash scripts/build.sh

assert_path output/index.html
assert_path output/start-here/index.html
assert_path output/guides/index.html
assert_path output/guides/first-guide/index.html
assert_path output/concepts/documentation-structure/index.html
assert_path output/reference/site-configuration/index.html
assert_path output/blog/index.html
assert_path output/404.html
assert_path output/assets/sitekit/sitekit.css
assert_path output/assets/sitekit/fonts/DepartureMono-Regular.woff2
assert_path output/assets/js/docs-search-index.json

assert_contains output/index.html 'Your Project Docs'
assert_contains output/index.html 'class="sk-hero docs-home-hero"'
assert_contains output/start-here/index.html 'class="docs-shell"'
assert_contains output/start-here/index.html 'class="docs-meta"'
assert_contains output/start-here/index.html 'href="#pick-a-direction"'
assert_contains output/guides/first-guide/index.html '<pre><code class="language-text"'
assert_contains output/assets/js/docs-search-index.json '"title": "Write your first guide"'
assert_contains output/robots.txt 'Disallow: /'
assert_contains output/sitemap.xml 'https://docs.example.test/guides/first-guide/'

printf 'Template contract passed\n'

