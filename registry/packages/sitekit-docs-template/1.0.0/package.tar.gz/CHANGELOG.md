# Changelog

## 1.0.0 - 2026-08-08

- Extract the documentation design used by the Kujo language site into a neutral, reusable starter.
- Vendor Kujo SSG 1.0.0 and the complete SiteKit 1.0.0 distribution for offline, repeatable builds.
- Include generic pages, collections, local search, responsive navigation, code-copy controls, validation, packaging, and CI.

