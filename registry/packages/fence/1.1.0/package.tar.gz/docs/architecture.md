# Architecture

Fence is implemented entirely in Kujo: an entry point (`fence.kujo`) plus
focused modules under `src/`. Functions are kept small and call chains shallow
because the Kujo VM has a limited call stack.

## Pipeline

```mermaid
flowchart LR
    cfg[load_config] --> walk[walk source files]
    walk --> imp[extract imports]
    imp --> res[resolve target]
    res --> zone[map file to zone]
    zone --> rule[apply rule engine]
    rule --> rep[render report]
```

1. **load_config** (`config.kujo`) parses `fence.toml` and normalizes defaults.
2. **walk** (`walk.kujo`) traverses `source_roots`, applying include/exclude
   globs, via an explicit stack (no recursion).
3. **extract imports** (`imports.kujo`, `imports_ext.kujo`) scans each file
   line-by-line, or delegates to an explicitly configured offline parser
   adapter, and records one-based source lines plus confidence.
4. **resolve** (`resolve.kujo`) maps a raw import to an internal file, an
   external package, or unknown.
5. **map zone** (`zones.kujo`) finds the first zone whose `paths` match.
6. **rule engine** (`rules.kujo`) decides allowed/denied and builds violations.
7. **render** (`reports.kujo`, `graph.kujo`) produces human/JSON/markdown/SARIF.

The orchestration lives in `analyze.kujo` (`analyze_files`), driven by the
command modules. Analysis maintains per-run import-resolution and zone-match
caches. `check --cache` can persist import records keyed by source SHA-256,
extractor version, and adapter configuration fingerprint. Custom adapters always
execute; only built-in extraction is persisted. Digest/version-mismatched or
malformed entries are re-extracted and do not affect report bytes. Cache contents remain trusted local state, not authenticated evidence.

`graph --observed` reuses the pipeline to compare configured allowed edges with
cross-zone internal edges actually found. Same-zone edges are omitted.

## Module map

| Module | Responsibility |
| --- | --- |
| `fence.kujo` | Entry point: `args()` → `cli_dispatch` → `exit(code)`. |
| `cli.kujo` | Command dispatch. |
| `cliargs.kujo` | Parse `command`, positionals, and `--flags`. |
| `meta.kujo` | Version string and help text. |
| **Commands** | |
| `cmd_init.kujo` | `init` |
| `cmd_check.kujo` | `check` (walk → analyze → render → output → exit) |
| `cmd_explain.kujo` | `explain <path>` |
| `cmd_graph.kujo` | `graph` (+ `--cycles`) |
| `cmd_baseline.kujo` | `baseline create` |
| `cmd_validate.kujo` | `validate` |
| `cmd_doctor.kujo` | `doctor` |
| `cmd_workspace.kujo` | `workspace init` manifest discovery. |
| `cmd_ignores.kujo` | `ignores list/check` policy-debt audit. |
| **Config** | |
| `config.kujo` | Load, compose, and normalize local TOML/JSON config. |
| `validate.kujo` | Structural validation, overlap + cycle warnings. |
| `templates.kujo` | Starter config templates. |
| **Analysis** | |
| `walk.kujo` | Iterative file traversal + include/exclude filtering. |
| `glob.kujo` | Pragmatic glob matcher (`**`, `*`, `?`). |
| `imports.kujo` | Import extraction: Kujo, JS/TS, Python. |
| `imports_ext.kujo` | Import extraction: Rust, PHP, Go. |
| `parser_adapters.kujo` | Structured offline parser-adapter contract. |
| `decisions.kujo` | Shared dependency and ignore decisions for check/explain. |
| `cache.kujo` | Versioned content-digest import cache. |
| `resolve.kujo` | Import resolution (internal/external/unknown). |
| `zones.kujo` | File → zone mapping. |
| `rules.kujo` | Dependency rule engine + external rules + suggestions. |
| `ignores.kujo` | Reasoned, expiring structured exceptions. |
| `cycles.kujo` | Dependency-cycle detection (Kahn's algorithm). |
| `analyze.kujo` | The walk→…→violations orchestration. |
| **Output** | |
| `reports.kujo` | human / JSON / markdown / SARIF renderers + summary. |
| `graph.kujo` | Architecture graph renderers (human/json/dot/mermaid). |
| `baseline.kujo` | Baseline fingerprints, load/apply. |
| `output.kujo` | Path-safe file writing. |
| **Foundations** | |
| `paths.kujo` | Path safety + manipulation helpers. |
| `git.kujo` | Safe Git integration (changed-only, diagnostics). |
| `util.kujo` | Shared helpers (sort, join, predicates). |

## Adding a language extractor

1. Add `extract_<lang>(content)` returning records
   `{ kind, path, raw, line }` (see existing extractors in `imports.kujo` /
   `imports_ext.kujo`). Scan line-by-line; keep it best-effort.
2. Register the file extension(s) in `extract_for_ext` (`imports.kujo`).
3. If the import syntax needs new resolution behavior, extend
   `module_to_path` / `resolve_import` in `resolve.kujo`.
4. Add include globs for the extension to the templates in `templates.kujo`.
5. Add assertions to `tests/fence_tests.kujo` and run
   `kujo run tests/fence_tests.kujo`.

## Result-object conventions

Fence functions that can fail return a dictionary rather than throwing, so
callers branch explicitly. Two shapes are used consistently:

- **Operation result** — `{ "ok": bool, "error": string, ... }`. Used by
  `output.write_safe`, `reports`/`graph` render helpers (`text` payload), and
  similar. On failure, `ok` is `false` and `error` is a human-readable message.
- **Command/IO result with an exit code** — `{ "ok": bool, "error": string,
  "code": int, ... }`. Used where the failure maps to a process exit code
  (`git.changed_files` → `code`, the `check` file-selection helper, etc.). The
  command layer returns that `code` from `cli_dispatch`.

Config loading uses a richer variant: `{ found, ok, error, path, config }` so
callers can distinguish "no config" (`found = false`, exit 2) from "bad config"
(`ok = false`, exit 3). Predicate helpers live in `util.kujo`
(`dict_has`, `truthy`, `arr_has`) and should be used instead of comparing
`has_key(...)`/`contains(...)` to `true`, because those builtins return `1`.

The single source of truth for the version string is `meta.fence_version()`.

## Kujo VM constraints (must respect)

These are runtime/compiler realities that shaped the code; ignore them and you
will hit crashes or `kujo check` failures:

- **One `for` per function** and **no duplicate `let` names** across `if`
  branches in a function — use `while` loops with unique names.
- **Imports must be `from src.x import name`**; qualified `src.x.f()` is not
  supported. Exports require `export func`.
- **`ProcessResult` fields use dot access** (`r.success`, `r.stdout`).
- **`has_key(...)` and string `contains(...)` return `1`, not `true`** — use
  `dict_has` / `truthy` (in `util.kujo`).
- **Multi-line string literals need `\n`** (no literal newlines); `\"` escapes a
  quote.
- **`pop(a)` returns `[new_array, element]`** and does not mutate in place.
- **Tree walks are iterative** (explicit stack) to avoid recursion-in-loop state
  corruption.
- **Shallow call stack (~6 user frames):** keep call chains flat; prefer
  top-level helpers over deep nesting.

See `agent/DECISIONS.md` (D4) for the verified details behind each item.

Import candidates are lexically normalized before file lookup and zone matching;
alias/direct imports cannot retain dot segments that disguise their target zone.
Human check/explain and Markdown check renderers escape repository-provided data
at presentation time. JSON/SARIF retain original evidence. Baseline operations
build temporary fingerprint indexes without changing their persisted v1 format.

## Embedding a private snapshot

`src.analyze.analyze_snapshot(files, cfg, inventory)` supports hosts that copy a
bounded source snapshot into a private working directory. `cfg` is a normalized,
validated Fence config. `inventory` is a dictionary whose keys are the available
regular-file paths, including targets that are not selected for analysis; values
are ignored. Every analyzed source must be present in that inventory.

`src.walk.select_inventory_files(inventory, source_roots, include, exclude)`
selects source paths without a filesystem walk, using the normal glob matcher.
It rejects escaping roots and non-normalized inventory paths. Root `.` selects
from the whole inventory; returned paths are sorted.

The API rejects configured parser adapters and persistent extraction caching.
It uses the same extraction, resolution precedence, zone rules, exception policy,
limits and result shape as ordinary analysis. Resolution only consults the
supplied inventory, including for extension and directory-index candidates; an
empty dictionary never falls back to ambient files. The caller's configuration
is not modified. `src.resolve.resolve_import_with_inventory` exposes the same
lookup mode for focused consumers; pass a dictionary, not `false` (the legacy
filesystem mode used by ordinary resolver entry points). Other argument types
are rejected.

This is a library integration boundary, not an OS sandbox. The host must perform
bounded, beneath-root reads, reject unsafe config/source paths and symlinks,
create private source copies, and bound execution/output. Analysis still reads
the listed source files from its working directory. Include the complete copied
file inventory so an excluded analysis target can still resolve correctly;
report omitted source coverage separately. Do not silently remove configured
parser adapters or weaken architecture rules to obtain a result.

The CLI continues to use filesystem-backed resolution, including existing
absolute-alias behavior. Snapshot integration does not change CLI flags, config
schema or JSON/SARIF result contracts.
