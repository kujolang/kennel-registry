# Configuration

Fence is configured by a single `fence.toml` at your repo root. A `fence.json`
file with the same shape is accepted as a fallback. Generate a starter with
`kujo run fence.kujo -- init`.

## Full example

```toml
version = 1
extends = ["config/base.toml"]
source_roots = ["src"]
default_severity = "error"
fail_on = "error"
unknown_dependency_policy = "warn"
output_roots = ["reports", ".fence"]
go_module = "github.com/acme/product"

[limits]
max_files = 10000
max_imports = 50000
max_report_bytes = 10485760

[scan]
include = [
  "src/**/*.ts", "src/**/*.tsx", "src/**/*.js", "src/**/*.jsx",
  "src/**/*.py", "src/**/*.rs", "src/**/*.php", "src/**/*.go", "src/**/*.kujo"
]
exclude = ["node_modules/**", "dist/**", "build/**", "**/*.min.js", "**/*.generated.*"]

[aliases]
"@" = "src"
"~" = "src"

# Optional trusted argv adapters. Fence appends the source path.
[parser_adapters]
".ts" = ["tree-sitter-fence-adapter", "--language", "typescript"]

# Optional: treat specific third-party packages as forbidden.
[external]
deny = ["lodash"]
allow = []

[zones.ui]
paths = ["src/ui/**", "src/components/**", "src/pages/**"]
can_depend_on = ["domain", "shared"]
cannot_depend_on = ["database", "infra"]
severity = "error"
owner = "team-ui"

[[ignores]]
from_zone = "ui"
to_zone = "database"
file = "src/ui/legacy/**"
import = "../database/users"
reason = "Migration tracked in ARCH-123"
expires = "2026-12-31"

[zones.domain]
paths = ["src/domain/**", "src/core/**"]
can_depend_on = ["shared"]
cannot_depend_on = ["ui", "http", "database", "infra"]
severity = "error"
```

## Top-level keys

| Key | Type | Default | Meaning |
| --- | --- | --- | --- |
| `version` | int | `1` | Config schema version. Non-`1` produces a warning. |
| `source_roots` | string[] | `["src"]` | Directories Fence walks. |
| `default_severity` | string | `"error"` | Fallback severity for zones without one. |
| `fail_on` | string | `"error"` | Threshold that fails the command: `none`/`warning`/`error`. |
| `unknown_dependency_policy` | string | `"warn"` | What to do with unmappable targets: `allow`/`warn`/`deny`. |
| `output_roots` | string[] | `[]` | Optional repo-relative directories allowed for `--output`. |
| `go_module` | string | `""` | Go module prefix used to resolve module-qualified internal imports. |
| `extends` | string[] | `[]` | Local config files merged dependency-first before this file. |

## `[limits]`

All limits default to `0` (unlimited). Exceeding one fails with runtime exit `4`
before a report is written. File limits apply after selection, import limits
during analysis, and report limits after rendering. These are enforcement
ceilings, not bounds on directory traversal, individual source/adapter/cache
payload allocation, or total process memory.

| Key | Meaning |
| --- | --- |
| `max_files` | Maximum source files selected for one check. |
| `max_imports` | Maximum imports analyzed. |
| `max_report_bytes` | Maximum UTF-8 bytes in the rendered report. |

## `[[ignores]]`

Structured exceptions match `from_zone`, `to_zone`, `file` glob, and exact
`import`; omitted match fields default to `*`. Every exception requires a
non-empty `reason` and ISO `expires` date. Expired entries are inactive. Ignored
violations remain visible in JSON and summary counts.

Use `ignores list --within-days 30` for an inventory and `ignores check` as a
CI expiry gate. `--fail-expiring` also fails entries inside the review window.

## Config composition

`extends` accepts only local, repo-relative TOML/JSON paths. Dependencies load
first; the child overrides scalar values and merges `zones`, `aliases`,
`external`, `scan`, `limits`, and `parser_adapters` one level. Fence rejects
cycles, chains deeper than 16, parent traversal, absolute paths, and symlink
escapes. Composition performs no network access.

## `[parser_adapters]` (optional)

Keys are extensions and values are non-empty argv arrays. Fence never invokes a
shell; it appends the source path and expects one JSON object:

```json
{"schema":"fence.parser-adapter/v1","imports":[{"kind":"import","path":"./x","raw":"import x from './x'","line":1}]}
```

Adapter records receive `confidence: "exact"`; built-in detectors report
`best_effort`. Adapters are executable code, so enable them only in trusted,
reviewed configuration and pin their installation outside Fence.

## `[scan]`

| Key | Type | Meaning |
| --- | --- | --- |
| `include` | string[] | Glob patterns a file must match to be scanned. Empty = include all. |
| `exclude` | string[] | Glob patterns that remove files from scanning. `.git` is always skipped. Fully excluded literal subtrees are pruned before
reading their contents; other globs still filter individual files. Identical
source roots are visited once. Directory symlink cycles and unreadable
directories fail the scan; non-file special entries are not read. |

Glob support is pragmatic: `**/*.ext` (suffix), `prefix/**` (tree),
`prefix/**/*.ext`, `?` for one character, and one or more `*` within a path
segment. No `{}`, `[]`.

## `[aliases]`

Maps an import prefix to a real directory. `"@" = "src"` makes `@/domain/user`
resolve as `src/domain/user`. Both exact (`@`) and prefixed (`@/x`) forms work.

## `[external]` (optional)

| Key | Type | Meaning |
| --- | --- | --- |
| `deny` | string[] | Third-party packages that are violations when imported. |
| `allow` | string[] | Packages explicitly allowed (wins over `deny`). |

Matching is by exact name or subpath (`lodash` matches `lodash` and
`lodash/fp`). By default all external packages are allowed. Per-zone overrides
are supported via `external_allow` / `external_deny` inside a `[zones.*]` block.

## `[zones.<name>]`

| Key | Type | Meaning |
| --- | --- | --- |
| `paths` | string[] | Globs that define zone membership. First matching zone wins. |
| `can_depend_on` | string[] | Zones this zone may import from. |
| `cannot_depend_on` | string[] | Zones this zone may **not** import from. |
| `severity` | string | `info` / `warning` / `error` for this zone's violations. |
| `external_allow` | string[] | (optional) zone-scoped external allow-list. |
| `external_deny` | string[] | (optional) zone-scoped external deny-list. |
| `owner` | string | (optional) provider-neutral owner identifier surfaced in findings. |

### Rule precedence

For a dependency `from_zone -> to_zone`:

1. Same zone → always allowed.
2. `to_zone` in `cannot_depend_on` → **violation** (explicit deny wins).
3. `to_zone` in `can_depend_on` → allowed.
4. Otherwise → `unknown_dependency_policy` (`allow` / `warn` / `deny`).

## Severities & thresholds

Violation severities: `info`, `warning`, `error`. The `fail_on` threshold
decides which fail the command:

- `fail_on = "error"` — only error-level violations fail.
- `fail_on = "warning"` — warnings and errors fail.
- `fail_on = "none"` — everything is reported but nothing fails.

Override per-run with `check --fail-on <level>`.

## Validation

`kujo run fence.kujo -- validate` checks for: invalid `fail_on` /
`unknown_dependency_policy` / severities, missing zones, references to undefined
zones, allow/deny conflicts, zones with no paths, **overlapping zone paths**,
**dependency cycles** in allowed edges, and unsupported `version`.

Malformed container types (including zones, scan lists, and aliases) are rejected
while loading config, with a config error instead of a later runtime exception.

### Exception validation and scan ceilings

Ignore reasons must be non-empty strings; optional `file`, `import`,
`from_zone`, and `to_zone` selectors must be strings. Expiry must be a real
calendar date in `YYYY-MM-DD` form (including leap-year validation).
Invalid exception configuration returns exit 2 before matching or date auditing.

`max_files` also applies to baseline create/prune and observed graphs. Analysis
shards share the total file/import ceilings; splitting a scan cannot reset the
budget. These ceilings do not bound allocations during directory traversal,
source extraction or report rendering.

Portable source paths cannot represent literal POSIX backslashes: a full walk
fails with exit 4 and identifies the unsupported entry. Rename the entry or
exclude its enclosing subtree. Import dot segments are normalized before zone
classification, so aliases cannot disguise a denied cross-zone dependency.
