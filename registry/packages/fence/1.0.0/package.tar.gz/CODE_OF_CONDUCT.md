# Code of Conduct

## Our pledge

We as members, contributors, and maintainers pledge to make participation in the
Fence project a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, religion, or sexual identity and
orientation.

## Our standards

Examples of behavior that contributes to a positive environment:

- Showing empathy and kindness toward other people.
- Being respectful of differing opinions, viewpoints, and experiences.
- Giving and gracefully accepting constructive feedback.
- Taking responsibility, apologizing to those affected by our mistakes, and
  learning from the experience.
- Focusing on what is best for the community and the project.

Unacceptable behavior includes harassment, insulting or derogatory comments,
personal or political attacks, publishing others' private information without
permission, and other conduct that could reasonably be considered inappropriate
in a professional setting.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to the project maintainer. All complaints will be reviewed and
investigated promptly and fairly. Maintainers are obligated to respect the
privacy and security of the reporter of any incident.

## Attribution

This Code of Conduct is adapted from the
[Contributor Covenant](https://www.contributor-covenant.org), version 2.1.
