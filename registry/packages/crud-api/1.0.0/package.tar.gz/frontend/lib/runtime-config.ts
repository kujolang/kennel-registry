export const api_base_url = process.env.NEXT_PUBLIC_API_BASE_URL || "http://127.0.0.1:4100";
