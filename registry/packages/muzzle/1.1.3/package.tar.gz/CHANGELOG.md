# Changelog

## 1.1.3 — 2026-10-21

- Update supported Node.js versions for workflow-runner regression tests and tooling.
- Preserve local execution, policy, redaction, versioned installation and JSON contracts.

All notable changes to Muzzle are documented here.

## [1.1.2] - 2026-10-12

- Declare the Bash wrapper as the Kennel command entrypoint so global installations locate execution helpers correctly outside the package directory.
- Add an installed-package regression that executes a workflow from a separate project.

## [1.1.1] - 2026-10-12

- Create initialization files atomically without following dangling destination symlinks or overwriting concurrently created files.
- Ignore all local state in newly initialized projects, including loop notes and policy verification snapshots; preserve existing user ignore files.

- Reject missing loop-note values before state mutation; guard persisted note/timestamp types.
- Enforce `allow_extra_args: false` under `--validate-args` even when optional `args` metadata is omitted.

- Reject missing and empty cleanup values before selecting artifacts; share one parsed command result for cleanup.
- Preserve inspection and loop positional arguments when `--json` appears before them.
- Reject unreachable persisted loop states without mutation while preserving the documented single-writer model.

- Parse run options once, treating consumed values as data rather than approval or execution flags; retain literal arguments and first-value precedence.
- Honor cleanup preview `-n` in either order with `--json`, without deleting artifacts.
- Confine policy-verification snapshots and execution cleanup before accessing symlinked state; exclude unsafe artifact entries from inspection and tolerate malformed timestamps.
- Preserve newline-containing script paths through snapshot splitting and filename-independent hashing.
- Preserve diagnostics after same-line secret blocks, and reject failed concurrent runs in benchmark receipts.

- Rank retention artifacts once, preserving numeric timestamps, filename ties, per-workflow/type limits, and deterministic receipts; skip malformed artifact names and directories.
- Preserve workflow names containing `.md` when deriving companion JSON report paths.
- Fail log initialization before execution and report verbose log-sink failures instead of false success; retain existing nonzero workflow exits and bounded, redacted helper diagnostics.
- Redact failure logs before selecting their excerpts so long and unterminated key blocks cannot leak their tails; retain complete logs and explicit oversized-line diagnostics.
- Batch snapshot sibling links with bounded argv size while retaining digest validation, runner identity, and lifecycle cleanup.
- Reuse validated manifests during execution and discovery; preserve repeated filename suffixes and exclude directories/escaping scripts from discovery.
- Validate loop entries, atomically replace loop state, and preserve JSON output on repeated loop starts.
- Make Kujo lint failures fail the quality gate, add focused behavioral regressions, and remove machine-specific paths from the Eval adapter.

- Add a reproducible before/after hardening evaluation with matched Kujo Eval outcomes, paired runtime distributions, raw evidence, a machine-readable receipt, and a public technical case study.

## [1.1.0] - 2026-08-30

- Spool full workflow output to disk with bounded in-process capture and explicit terminal truncation metadata.
- Terminate Unix workflow process groups on timeout, cancel-file requests, and forwarded interruption; standardize exits 124 and 130.
- Add strict manifest schemas, operational argument validation, enforce-mode safety policy, script checksum pins, and signed policy bundles.
- Add versioned JSON command/error contracts, `doctor`, `integrity`, and bounded artifact-retention commands.
- Add a versioned installer, Bash/Zsh completions, pinned Linux/macOS CI, repeatable performance signals, and process/install regressions.
- Restore the documented `muzzle version` command path.
- Align README version badge with `kennel.toml` and CLI output.
- Add deterministic Eval suite for prelaunch review evidence.
- Reject symlinked or non-directory Muzzle roots that escape project-local workflow, artifact, or loop-state boundaries.
- Report invalid numeric options, malformed manifest/session/loop state, invalid loop transitions, and cleanup failures without raw runtime crashes or false success.
- Serialize concurrent session-counter updates so successful parallel runs are not lost.
- Escape free-form loop notes so `muzzle loop summary` remains a valid one-row-per-iteration Markdown table.
- Sort workflow, loop, log, and report discovery for deterministic output across filesystems.
- Apply workflow-name validation consistently to inspection commands and reject malformed safety metadata cleanly.
- Include redacted failure excerpts in Markdown reports and correct stale output/version documentation.
- Add a canonical local quality gate and a copyable manifest-backed build-check example.
- Create logs and reports with owner-only permissions and bind signed-policy parsing to the bytes verified by OpenSSL.
- Bind validated workflow bytes to digest-verified private execution snapshots while preserving supported runner identity and import behavior.
- Pin the Kujo CI revision, reject unsafe forced-install paths, and publish the additive `muzzle.run/v1` JSON Schema contract.

## [1.0.0] - 2026-08-08

- Declared the trusted-local CLI, manifest, compact-summary, logging, reporting, and loop contracts stable.
- Aligned the launcher, runtime, manifest, Spec, and README at 1.0.0.

## [0.2.0] - 2026-06-27

- Prepared Muzzle for public release with quiet workflow execution, manifest-backed workflow metadata, loop tracking, compact JSON summaries, and wrapper regression coverage.
