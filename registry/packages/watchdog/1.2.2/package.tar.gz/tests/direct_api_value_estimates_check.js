#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const shared = fs.readFileSync(path.join(root, 'src/watchdog_shared.kujo'), 'utf8');
const server = fs.readFileSync(path.join(root, 'src/dashboard_server.kujo'), 'utf8');
const dashboard = fs.readFileSync(path.join(root, 'src/dashboard.html'), 'utf8');
const providerCatalog = JSON.parse(fs.readFileSync(path.join(root, 'config/provider_pricing_catalog.json'), 'utf8'));
const catalog = JSON.parse(fs.readFileSync(path.join(root, 'config/openrouter_pricing_catalog.json'), 'utf8'));

function contains(text, expected, message) {
	if (!text.includes(expected)) throw new Error(message + ': missing ' + expected);
}

function assert(condition, message) {
	if (!condition) throw new Error(message);
}

contains(shared, 'DEFAULT_PROVIDER_PRICING_CATALOG_PATH := "config/provider_pricing_catalog.json"', 'Shared module should load a checked-in provider catalog');
contains(shared, 'DEFAULT_OPENROUTER_PRICING_CATALOG_PATH := "config/openrouter_pricing_catalog.json"', 'Shared module should load a checked-in OpenRouter catalog');
contains(shared, 'lookup_catalog_pricing_record(PROVIDER_PRICING_CATALOG, "ollama-cloud/" + model_key)', 'Ollama cloud aliases should resolve through the provider catalog');
contains(shared, 'watchdog-fallback-estimate:v1', 'Fallback pricing should be explicitly marked');
contains(shared, '"pricing_kind": "fallback"', 'Unknown models should remain explicit fallback estimates');
contains(shared, '"pricing_kind": "unknown"', 'Known-but-unpriced models should remain explicit unknowns');
contains(shared, 'ALTER TABLE requests ADD COLUMN cached_input_rate_per_million REAL NOT NULL DEFAULT 0.0', 'Request pricing provenance should persist cache read rates');
contains(shared, 'ALTER TABLE traces ADD COLUMN cache_write_input_rate_per_million REAL NOT NULL DEFAULT 0.0', 'Trace pricing provenance should persist cache write rates');
contains(shared, 'if has_key(aliases, model_key)', 'Runtime pricing lookup should honor explicit aliases before same-name catalog records');
assert(shared.indexOf('if has_key(aliases, model_key)') < shared.indexOf('if has_key(models, model_key)'), 'Runtime aliases should take precedence over same-name model records');
contains(shared, 'CREATE TABLE IF NOT EXISTS pricing_reprice_runs', 'Reprice runs should be auditable');
contains(shared, 'CREATE TABLE IF NOT EXISTS pricing_reprice_changes', 'Reprice changes should preserve before/after records');
contains(server, 'cached_tokens := to_int_or_zero(safe_dict_get(trace, "cached_input_tokens", 0))', 'Trace intake should persist cached token counts');
contains(server, 'cache_write_tokens := to_int_or_zero(safe_dict_get(trace, "cache_write_input_tokens", 0))', 'Trace intake should persist cache write token counts');
contains(server, 'excluded.cached_input_tokens > traces.cached_input_tokens', 'Trace persistence should keep replay-safe cumulative cached token counts');
contains(server, 'excluded.input_cost_usd > traces.input_cost_usd', 'Trace persistence should keep replay-safe cumulative cost components');
contains(dashboard, 'Est. API Value', 'Dashboard summary label should remain present');

assert(providerCatalog.catalog_id === 'watchdog-provider-catalog:2026-10-18', 'Provider catalog snapshot should be versioned with the refresh date');
assert(providerCatalog.models['gpt-4.1'].cached_input_rate_per_million === 0.5, 'Direct OpenAI prompt caching should come from the provider catalog');
assert(providerCatalog.models['gpt-6-sol'].cache_write_input_rate_per_million === 2.5, 'GPT-6 Sol cache-write pricing should come from OpenAI');
assert(providerCatalog.models['gpt-6.1-sol'].cached_input_rate_per_million === 0.1, 'GPT-6.1 Sol cached-input pricing should come from OpenAI');
assert(providerCatalog.models['gpt-6-luna'].output_rate_per_million === 0.5, 'GPT-6 Luna output pricing should come from OpenAI');
assert(providerCatalog.models['gpt-5.6-sol'].cache_write_input_rate_per_million === 5, 'Current promotional Codex model cache-write pricing should come from OpenAI');
assert(providerCatalog.models['gpt-daybreak-blue-latest'].priced_model === 'gpt-5.6-sol', 'Daybreak Blue should use its documented GPT-5.6 Sol alias basis');
assert(providerCatalog.models['claude-sonnet-5'].cache_write_input_rate_per_million === 2.5, 'Anthropic cache write assumptions should be explicit in the provider catalog');
assert(providerCatalog.models['claude-sonnet-5.5'].cache_write_input_rate_per_million === 2.5, 'Claude Sonnet 5.5 cache-write pricing should come from Anthropic');
assert(providerCatalog.models['claude-sonnet-5.5'].cached_input_rate_per_million === 0.1, 'Claude Sonnet 5.5 should use Anthropic current five-percent cache-read rate');
assert(providerCatalog.models['claude-haiku-5.5'].input_rate_per_million === 0.1, 'Claude Haiku 5.5 short-context pricing should come from Anthropic');
assert(providerCatalog.models['claude-opus-5.5'].cached_input_rate_per_million === 0.2, 'Claude Opus 5.5 cache-read pricing should come from Anthropic');
assert(providerCatalog.models['gemini-3.5-flash'].output_rate_per_million === 9, 'Current Gemini 3.5 Flash output pricing should come from Google');
assert(providerCatalog.models['gemini-3.5-flash-lite'].cached_input_rate_per_million === 0.03, 'Current Gemini 3.5 Flash-Lite cache pricing should come from Google');
assert(providerCatalog.models['deepseek-v3.1-pro'].has_pricing === false, 'Direct DeepSeek models without current public rates should stay explicitly unknown');
assert(providerCatalog.models['deepseek-v4-pro'].input_rate_per_million === 1.32, 'DeepSeek V4 Pro cache-miss input pricing should use the current peak rate');
assert(providerCatalog.models['deepseek-v4-pro'].pricing_source === 'deepseek-pricing:2026-09-20:peak-rate', 'DeepSeek V4 Pro provenance should identify the current public pricing tier');
assert(providerCatalog.models['deepseek-chat'].priced_model === 'deepseek-flash', 'Deprecated DeepSeek aliases should resolve to their current documented pricing basis');
assert(providerCatalog.models['deepseek-v4.1-flash'].cached_input_rate_per_million === 0.006, 'DeepSeek V4.1 Flash should preserve current cache-hit pricing');
assert(providerCatalog.models['grok-4.6'].cached_input_rate_per_million === 0.5, 'Active xAI OAuth inventory should use public xAI direct-API equivalent pricing');
assert(providerCatalog.models['tencent/hy3:free'].has_pricing === false, 'Removed OpenRouter suggestions should become explicit unknowns instead of generic paid fallbacks');
assert(providerCatalog.models['anthropic/claude-opus-4.8-fast'].has_pricing === false, 'Removed OpenRouter fast routes should remain explicit unknowns rather than borrowing direct-provider pricing');
assert(providerCatalog.models['stealth/ox-alpha'].has_pricing === false, 'Unconfirmed Hermes free suggestions should become explicit unknowns instead of invented zero prices');
assert(providerCatalog.models['stealth/missingno'].has_pricing === false, 'Hermes-only models without a public token rate should be explicit unknowns');
assert(providerCatalog.models['inclusionai/ling-3.0-flash-fin:free'].has_pricing === false, 'Removed Hermes routes should become explicit unknowns instead of generic paid fallbacks');
assert(providerCatalog.models['meituan/longcat-2.5-preview:free'].has_pricing === false, 'Unlisted Hermes suggestions should become explicit unknowns instead of generic paid fallbacks');
assert(providerCatalog.models['kimi-k3'].cache_write_input_rate_per_million === 3, 'Direct Kimi K3 pricing should include Moonshot cache-write rates');
assert(providerCatalog.aliases['ollama-cloud/kimi-k3:cloud'].target_model_id === 'ollama-cloud/kimi-k3', 'Ollama Cloud Kimi K3 should resolve to Ollama public pricing');
assert(providerCatalog.models['ollama-cloud/kimi-k3'].output_rate_per_million === 15, 'Ollama Cloud Kimi K3 should use Ollama public output pricing');
assert(providerCatalog.aliases['ollama-cloud/kimi-k2.6'].target_model_id === 'kimi-k2.6', 'Ollama cloud aliases should point at their pricing basis');
assert(providerCatalog.aliases['ollama-cloud/kimi-k2.6'].pricing_source === 'ollama-cloud-pricing:2026-10-18', 'Ollama aliases listed in the public table should retain Ollama provenance');
assert(providerCatalog.models['glm-5.3'].input_rate_per_million === 1.4, 'GLM 5.3 pricing should come from Z.AI');
assert(providerCatalog.models['glm-5.3-flash'].output_rate_per_million === 0.5, 'GLM 5.3 Flash pricing should come from Z.AI');
assert(providerCatalog.models['ollama-cloud/gemma4'].cached_input_rate_per_million === 0.05, 'Ollama Cloud Gemma 4 should use Ollama public cache pricing');
assert(providerCatalog.aliases['ollama-cloud/nemotron-3-nano:30b'].target_model_id === 'ollama-cloud/nemotron-3-nano', 'Ollama model variants should resolve to their published cloud rate');
assert(catalog.catalog_id === 'openrouter-public-catalog:2026-10-18', 'Catalog snapshot should be versioned with the refresh date');
assert(catalog.models['openai/gpt-5.4'].input_rate_per_million === 2.5, 'GPT-5.4 prompt pricing should come from the catalog');
assert(catalog.models['anthropic/claude-sonnet-5'].cache_write_input_rate_per_million === 2.5, 'Claude Sonnet 5 cache write pricing should come from the catalog');
assert(catalog.models['anthropic/claude-sonnet-5.5'].cache_write_input_rate_per_million === 2.5, 'Claude Sonnet 5.5 cache write pricing should come from the refreshed catalog');
assert(catalog.aliases['~anthropic/claude-haiku-latest'].target_model_id === 'anthropic/claude-haiku-5.5', 'Alias map should normalize Claude Haiku latest');

console.log('direct_api_value_estimates_check: PASS');
