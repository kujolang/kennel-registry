# Watchdog Deployment And Hardening Runbook

This runbook documents secure deployment defaults, operational checks, retention controls, and troubleshooting steps for Watchdog.

For architecture topology patterns (single-node/scaled), see `docs/ENTERPRISE_DEPLOYMENT_ARCHITECTURE.md`.

## 1. Hardened Environment Baseline

Use explicit environment variables before starting Watchdog:

```bash
export KUJO_BIN=${KUJO_BIN:-kujo}
export WATCHDOG_ROOT=/path/to/kujo-watchdog
export WDG_PORT=7700
export WDG_DB_PATH="$WATCHDOG_ROOT/data/watchdog.db"
export WDG_PROXY_CONFIG_PATH="$WATCHDOG_ROOT/watchdog_proxy_config.json"
export WDG_DEPLOYMENT_PROFILE=production
export WDG_API_AUTH_MODE=token
export WDG_API_AUTH_TOKEN='replace-with-long-random-token'
export WDG_PROXY_AUTHZ_MODE=token
export WDG_PROXY_AUTHZ_TOKEN='replace-with-long-random-proxy-token'
export WDG_PROXY_AUTHZ_ALLOWLIST='/healthz,/readyz'
export WDG_REDACTION_MODE=basic
export WDG_RATE_LIMIT_MODE=basic
export WDG_RATE_LIMIT_MAX_REQUESTS=120
export WDG_RATE_LIMIT_WINDOW_SECS=60
export WDG_RATE_LIMIT_MAX_BUCKETS=5000
export WDG_RATE_LIMIT_BUCKET_TTL_SECS=600
export WDG_IDENTIFIER_MAX_LEN=128
export WDG_EXPORT_MAX_ROWS=10000
export WDG_MAX_PROXY_BODY_BYTES=1048576
export WDG_MAX_PARSE_BODY_BYTES=524288
export WDG_CHARTJS_LOCAL_PATH=vendor/chart.umd.min.js
export WDG_BACKUP_ENABLED=true
export WDG_BACKUP_INTERVAL_MINUTES=1440
export WDG_BACKUP_DIR="$HOME/Dropbox/Watchdog Backups"
export WDG_BACKUP_RETENTION_COUNT=30
export WDG_BACKUP_ENCRYPTION_ENABLED=true
export WDG_BACKUP_ENCRYPTION_KEY_FILE="$HOME/.config/watchdog/backup-encryption-key"
```

Production profile startup policy:

- In `WDG_DEPLOYMENT_PROFILE=production`, startup fails closed unless API and proxy token auth are fully configured.
- Break-glass override is available via `WDG_ALLOW_INSECURE_STARTUP=true` and should only be used for tightly controlled recovery scenarios.

Start server:

```bash
"$KUJO_BIN" run --interpreter dashboard_server.kujo
```

`dashboard_server.kujo` is the documented root compatibility entrypoint and mirrors `src/dashboard_server.kujo`.

## 2. Network Exposure Guidance

- Watchdog defaults to all interfaces (`0.0.0.0`); set `WDG_HOST=127.0.0.1` for loopback-only access.
- For non-local deployments, do not rely on network defaults alone.
- Require `WDG_API_AUTH_MODE=token`.
- Require `WDG_PROXY_AUTHZ_MODE=token`.
- Restrict inbound access with firewall rules and/or place Watchdog behind a reverse proxy.

## 3. Operational Verification Checks

Run these checks after each deploy:

```bash
curl -s http://127.0.0.1:7700/healthz
curl -s http://127.0.0.1:7700/readyz
curl -s http://127.0.0.1:7700/api/version -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/api/stats -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/api/proxy-config -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/api/audit-events -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/api/requests -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s "http://127.0.0.1:7700/api/sessions?tenant_id=example_tenant" -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s "http://127.0.0.1:7700/api/charts/status-breakdown?project_id=example_project" -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/api/admin/diagnostics -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/api/export -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s http://127.0.0.1:7700/proxy/v1/models -H 'X-Watchdog-Proxy-Token: replace-with-long-random-proxy-token'
curl -s http://127.0.0.1:7700/ | grep -q 'integrity="sha384-bs/nf9FbdNouRbMiFcrcZfLXYPKiPaGVGplVbv7dLGECccEXDW+S3zjqSKR5ZEaD"'
```

Expected shape for successful API checks:
- JSON includes `"ok": true`.

Optional proxy path smoke check:

```bash
curl -i -s -X POST http://127.0.0.1:7700/proxy/v1/chat/completions \
	-H 'Content-Type: application/json' \
	-d '{"model":"gpt-4.1-mini","messages":[{"role":"user","content":"runbook smoke"}]}'
```

Optional export payload-bound check:

```bash
curl -s "http://127.0.0.1:7700/api/export?max_rows=500" -H 'X-Watchdog-Token: replace-with-long-random-token'
curl -s "http://127.0.0.1:7700/api/export?format=json&chunk_size=500&cursor=0" -H 'X-Watchdog-Token: replace-with-long-random-token'
```

Optional benchmark baseline check:

```bash
node scripts/benchmark_profiles.js --profiles=quick,soak --json-out=tmp/benchmark-report.json
```

Optional restricted-network dashboard fallback setup:

```bash
mkdir -p "$WATCHDOG_ROOT/vendor"
# Copy vetted chart.umd.min.js to $WATCHDOG_ROOT/vendor/chart.umd.min.js
curl -s http://127.0.0.1:7700/assets/vendor/chart.umd.min.js | head -c 80
```

## 4. Retention Tuning And Pruning

Preview prune impact before delete:

```bash
curl -s -X POST http://127.0.0.1:7700/api/admin/prune \
	-H 'Content-Type: application/json' \
	-H 'X-Watchdog-Token: replace-with-long-random-token' \
	-d '{"before_ms": 1700000000000, "dry_run": true}'
```

Apply pruning:

```bash
curl -s -X POST http://127.0.0.1:7700/api/admin/prune \
	-H 'Content-Type: application/json' \
	-H 'X-Watchdog-Token: replace-with-long-random-token' \
	-d '{"before_ms": 1700000000000, "dry_run": false}'
```

## 5. Backup Strategy

Use the dashboard Backups tab or the protected API to manage online SQLite
backups. Backups are integrity-checked, receive SHA-256 sidecars, and do not
require stopping Watchdog.

```bash
mkdir -p "$HOME/.config/watchdog"
openssl rand -base64 48 > "$HOME/.config/watchdog/backup-encryption-key"
chmod 600 "$HOME/.config/watchdog/backup-encryption-key"

curl -s -X PUT http://127.0.0.1:7700/api/admin/backups/settings \
	-H 'Content-Type: application/json' \
	-H 'X-Watchdog-Token: replace-with-long-random-token' \
	-d '{"enabled":true,"interval_minutes":1440,"backup_dir":"/absolute/path/to/Dropbox/Watchdog Backups","retention_count":30,"encryption_enabled":true}'

curl -s -X POST http://127.0.0.1:7700/api/admin/backups/run \
	-H 'X-Watchdog-Token: replace-with-long-random-token'
```

The encryption key file must be backed up separately from encrypted database
files. Without that key, encrypted backups cannot be recovered.

Restore an encrypted backup into a separate file and validate it before
replacing any live database:

```bash
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -md sha256 \
	-in watchdog-backup-TIMESTAMP.db.enc \
	-out restored-watchdog.db \
	-pass file:"$HOME/.config/watchdog/backup-encryption-key"
sqlite3 restored-watchdog.db 'PRAGMA quick_check;'
```

## 6. Troubleshooting Proxy Errors

- `401 Unauthorized` from `/proxy/v1/...`:
	- In `WDG_PROXY_AUTHZ_MODE=token`, this indicates a missing proxy auth token.
	- In passthrough mode, this can also be an upstream auth failure when no upstream credential is provided.
- `403 Forbidden` from `/proxy/v1/...`:
	- Proxy token was present but did not match `WDG_PROXY_AUTHZ_TOKEN`.
- `500 Proxy auth mode is token but WDG_PROXY_AUTHZ_TOKEN is empty`:
	- Set `WDG_PROXY_AUTHZ_TOKEN` when token mode is enabled.
- `FATAL: production startup policy violations: ...`:
	- Set `WDG_DEPLOYMENT_PROFILE=production` with `WDG_API_AUTH_MODE=token`, `WDG_API_AUTH_TOKEN`, `WDG_PROXY_AUTHZ_MODE=token`, and `WDG_PROXY_AUTHZ_TOKEN`.
	- Use `WDG_ALLOW_INSECURE_STARTUP=true` only for short-lived break-glass recovery situations.
- `500 Proxy auth_mode=override requires ...`:
	- Set `WDG_UPSTREAM_API_KEY` or `WDG_UPSTREAM_API_KEY_ENV`.
- `413 Proxy request body exceeds configured max bytes`:
	- Increase `WDG_MAX_PROXY_BODY_BYTES` or send smaller payloads.
- `413 JSON body exceeds configured parse limit`:
	- Increase `WDG_MAX_PARSE_BODY_BYTES` or reduce JSON request size.
- `429 Too Many Requests`:
	- Increase `WDG_RATE_LIMIT_MAX_REQUESTS`, raise `WDG_RATE_LIMIT_WINDOW_SECS`, or disable limiting for local-only workflows.
- `502 Upstream request failed`:
	- Verify upstream URL and network path in proxy config.

### Rate-limit trust boundary

Basic session buckets are cooperative accounting: callers control session,
forwarded-address and Host headers. They are not an abuse-prevention boundary.
For network exposure, enforce a separate pre-authentication limit at the reverse
proxy using its authenticated peer identity, strip untrusted forwarding headers,
and keep both Watchdog token modes enabled. Tenant/project filters do not grant
separate tenant authorization; the API token grants administrative authority.
