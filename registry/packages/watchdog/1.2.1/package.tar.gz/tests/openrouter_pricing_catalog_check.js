#!/usr/bin/env node

const assert = require('assert');
const path = require('path');
const {
	loadProviderCatalog,
	loadOpenRouterCatalog,
	resolvePricing,
	computeBreakdown
} = require('../scripts/pricing_catalog_lib');
const { buildModelEntry } = require('../scripts/refresh_openrouter_pricing_catalog');

const root = path.join(__dirname, '..');
const providerCatalog = loadProviderCatalog(path.join(root, 'config', 'provider_pricing_catalog.json'));
const openrouterCatalog = loadOpenRouterCatalog(path.join(root, 'config', 'openrouter_pricing_catalog.json'));

const missingPromptRate = buildModelEntry({ id: 'test/missing-prompt', pricing: { prompt: null, completion: '0.001' } }, 'test-catalog');
assert.equal(missingPromptRate.has_pricing, false, 'null base rates must not be published as free pricing');
const emptyCompletionRate = buildModelEntry({ id: 'test/missing-completion', pricing: { prompt: '0.001', completion: '' } }, 'test-catalog');
assert.equal(emptyCompletionRate.has_pricing, false, 'empty base rates must not be published as free pricing');

const gpt54 = resolvePricing('openai/gpt-5.4', { providerCatalog, openrouterCatalog });
assert.equal(gpt54.pricing_kind, 'catalog');
assert.equal(gpt54.input_rate_per_million, 2.5);
assert.equal(gpt54.output_rate_per_million, 15);
assert.equal(gpt54.cached_input_rate_per_million, 0.25);

const astra = resolvePricing('gpt-6-astra', { providerCatalog, openrouterCatalog });
assert.equal(astra.pricing_kind, 'catalog');
assert.equal(astra.input_rate_per_million, 10);
assert.equal(astra.cached_input_rate_per_million, 1);
assert.equal(astra.cache_write_input_rate_per_million, 12.5);
assert.equal(astra.output_rate_per_million, 50);

const sol61 = resolvePricing('gpt-6.1-sol', { providerCatalog, openrouterCatalog });
assert.equal(sol61.pricing_kind, 'catalog');
assert.equal(sol61.input_rate_per_million, 2);
assert.equal(sol61.cached_input_rate_per_million, 0.1);
assert.equal(sol61.cache_write_input_rate_per_million, 2.5);
assert.equal(sol61.output_rate_per_million, 10);

const opus5 = resolvePricing('anthropic/claude-opus-5', { providerCatalog, openrouterCatalog });
assert.equal(opus5.pricing_kind, 'catalog');
assert.equal(opus5.input_rate_per_million, 5);
assert.equal(opus5.output_rate_per_million, 25);
assert.equal(opus5.cache_write_input_rate_per_million, 6.25);

const glm52 = resolvePricing('z-ai/glm-5.2', { providerCatalog, openrouterCatalog });
assert.equal(glm52.input_rate_per_million, 0.06);
assert.equal(glm52.output_rate_per_million, 7);
assert.equal(glm52.cached_input_rate_per_million, 0.059);

const alias = resolvePricing('~anthropic/claude-haiku-latest', { providerCatalog, openrouterCatalog });
assert.equal(alias.pricing_kind, 'catalog');
assert.equal(alias.priced_model, 'anthropic/claude-haiku-5.5');
assert.equal(alias.input_rate_per_million, 0.1);
assert.equal(alias.output_rate_per_million, 0.5);

const openaiDirect = resolvePricing('gpt-4.1', { providerCatalog, openrouterCatalog });
assert.equal(openaiDirect.pricing_kind, 'catalog');
assert.equal(openaiDirect.pricing_source, 'openai-api-pricing:2026-07-19');
assert.equal(openaiDirect.cached_input_rate_per_million, 0.5);

const codexModel = resolvePricing('gpt-5.6-terra', { providerCatalog, openrouterCatalog });
assert.equal(codexModel.pricing_kind, 'catalog');
assert.equal(codexModel.pricing_source, 'openai-api-pricing:2026-08-23:standard-short-context');
assert.equal(codexModel.input_rate_per_million, 2);
assert.equal(codexModel.cached_input_rate_per_million, 0.2);
assert.equal(codexModel.cache_write_input_rate_per_million, 2.5);
assert.equal(codexModel.output_rate_per_million, 12);

const daybreakAlias = resolvePricing('gpt-daybreak-blue-latest', { providerCatalog, openrouterCatalog });
assert.equal(daybreakAlias.priced_model, 'gpt-5.6-sol');
assert.equal(daybreakAlias.input_rate_per_million, 4);
assert.equal(daybreakAlias.output_rate_per_million, 20);

const grok46 = resolvePricing('grok-4.6', { providerCatalog, openrouterCatalog });
assert.equal(grok46.pricing_kind, 'catalog');
assert.equal(grok46.input_rate_per_million, 2);
assert.equal(grok46.cached_input_rate_per_million, 0.5);
assert.equal(grok46.output_rate_per_million, 6);

const codexSpark = resolvePricing('gpt-5.3-codex-spark', { providerCatalog, openrouterCatalog });
assert.equal(codexSpark.pricing_kind, 'unknown');
assert.match(codexSpark.pricing_source, /not-supported-in-public-api-model-cache$/);

const deepSeekChat = resolvePricing('deepseek-chat', { providerCatalog, openrouterCatalog });
assert.equal(deepSeekChat.pricing_kind, 'catalog');
assert.equal(deepSeekChat.priced_model, 'deepseek-flash');
assert.match(deepSeekChat.pricing_source, /^deepseek-pricing:2026-09-20#deprecated-alias/);
assert.equal(deepSeekChat.input_rate_per_million, 0.3);
assert.equal(deepSeekChat.cached_input_rate_per_million, 0.006);
assert.equal(deepSeekChat.output_rate_per_million, 1.2);

const deepSeekReasoner = resolvePricing('deepseek-reasoner', { providerCatalog, openrouterCatalog });
assert.equal(deepSeekReasoner.priced_model, 'deepseek-flash');
assert.equal(deepSeekReasoner.input_rate_per_million, 0.3);
assert.equal(deepSeekReasoner.cached_input_rate_per_million, 0.006);
assert.equal(deepSeekReasoner.output_rate_per_million, 1.2);

const deepSeekCurrent = resolvePricing('deepseek-v4.1-flash', { providerCatalog, openrouterCatalog });
assert.equal(deepSeekCurrent.priced_model, 'deepseek-flash');
assert.equal(deepSeekCurrent.input_rate_per_million, 0.3);
assert.equal(deepSeekCurrent.cached_input_rate_per_million, 0.006);
assert.equal(deepSeekCurrent.output_rate_per_million, 1.2);

const ollamaKimiK3 = resolvePricing('kimi-k3:cloud', { providerCatalog, openrouterCatalog });
assert.equal(ollamaKimiK3.pricing_kind, 'catalog');
assert.equal(ollamaKimiK3.priced_model, 'ollama-cloud/kimi-k3');
assert.match(ollamaKimiK3.pricing_source, /^ollama-cloud-pricing:/);
assert.equal(ollamaKimiK3.output_rate_per_million, 15);

const ollamaGlm53Flash = resolvePricing('glm-5.3-flash:cloud', { providerCatalog, openrouterCatalog });
assert.equal(ollamaGlm53Flash.pricing_kind, 'catalog');
assert.equal(ollamaGlm53Flash.priced_model, 'glm-5.3-flash');
assert.match(ollamaGlm53Flash.pricing_source, /^ollama-cloud-pricing:/);

const ollamaGemma4 = resolvePricing('gemma4:31b', { providerCatalog, openrouterCatalog });
assert.equal(ollamaGemma4.pricing_kind, 'catalog');
assert.equal(ollamaGemma4.priced_model, 'ollama-cloud/gemma4');
assert.equal(ollamaGemma4.cached_input_rate_per_million, 0.05);

const ollamaEquivalent = resolvePricing('kimi-k2.6', { providerCatalog, openrouterCatalog });
assert.equal(ollamaEquivalent.pricing_kind, 'catalog');
assert.equal(ollamaEquivalent.input_rate_per_million, 0.95);
assert.equal(ollamaEquivalent.cached_input_rate_per_million, 0.16);

const sonnetBreakdown = computeBreakdown('anthropic/claude-sonnet-5', {
	input_tokens: 1000,
	output_tokens: 200,
	cached_input_tokens: 500,
	cache_write_input_tokens: 250
}, { providerCatalog, openrouterCatalog });
assert.equal(sonnetBreakdown.input_cost_usd, 0.002);
assert.equal(sonnetBreakdown.output_cost_usd, 0.002);
assert.equal(sonnetBreakdown.cached_input_cost_usd, 0.0001);
assert.equal(sonnetBreakdown.cache_write_input_cost_usd, 0.000625);

const directSonnet = resolvePricing('claude-sonnet-5', { providerCatalog, openrouterCatalog });
assert.match(directSonnet.pricing_source, /launch-rate-confirmed-standard/);

const gemini38 = resolvePricing('gemini-3.8-flash', { providerCatalog, openrouterCatalog });
assert.equal(gemini38.pricing_kind, 'catalog');
assert.equal(gemini38.input_rate_per_million, 0.75);
assert.equal(gemini38.cached_input_rate_per_million, 0.075);
assert.equal(gemini38.output_rate_per_million, 3.75);

const unpricedAudio = resolvePricing('whisper-1', { providerCatalog, openrouterCatalog });
assert.equal(unpricedAudio.pricing_kind, 'unknown');
assert.equal(unpricedAudio.pricing_source, 'openai-api-pricing:2026-07-19#audio-minute-pricing');

const unpricedDeepSeek = resolvePricing('deepseek-v3.1-pro', { providerCatalog, openrouterCatalog });
assert.equal(unpricedDeepSeek.pricing_kind, 'unknown');
assert.equal(unpricedDeepSeek.pricing_source, 'deepseek-pricing:2026-07-19:not-listed-on-current-public-pricing-page');

const fallback = resolvePricing('unknown/provider-model', { providerCatalog, openrouterCatalog });
assert.equal(fallback.pricing_kind, 'fallback');
assert.equal(fallback.pricing_source, 'watchdog-fallback-estimate:v1');

const unknown = resolvePricing('openrouter/auto-beta', { providerCatalog, openrouterCatalog });
assert.equal(unknown.pricing_kind, 'unknown');
assert.equal(unknown.input_rate_per_million, 0);
assert.equal(unknown.output_rate_per_million, 0);

console.log('openrouter_pricing_catalog_check: PASS');
