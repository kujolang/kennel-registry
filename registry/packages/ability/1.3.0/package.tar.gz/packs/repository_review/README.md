# Trusted local repository review pack

This canonical Ability pack binds existing PatchBrief and ChangeBucket implementations through `bindings/json_process.kujo`. It belongs to Ability, independently of any host. Hosts discover the `sdk` registry and may register their own exposure records without changing definitions or handlers.

`create_repository_review_registry(config)` accepts operator-owned absolute paths: `kujo`, `git`, `repository`, `patchbrief`, `changebucket`, and an empty private `home`; `path` is the operator's trusted executable search path. `revisions` maps `patchbrief.kujo` and `changebucket.kujo` to reviewed immutable source commits. The installer must verify those checkouts before construction; metadata is provenance, not proof of integrity. The application supplies durable audit services and uses the canonical runtime. `repository_review_policy` permits declared reads only.

The two versioned definitions are `kujo.patchbrief.changes.summarize@1.0.0` and `kujo.changebucket.changes.measure@1.0.0`. Inputs are empty objects: the repository cannot be changed by a model. PatchBrief's output schema is loaded directly from its published schema file. ChangeBucket has no published JSON Schema; this pack owns a minimal required-key object contract over its documented JSON report. Neither report proves correctness. Both are observational and may change when the worktree changes; intrinsic idempotency is not result caching.

The pack disables ambient Git global/system configuration, prompts, fsmonitor and hooks. Before each execution it rejects repository executable `filter.*` and `diff.*.(command|textconv)` declarations. It requires PatchBrief with textconv disabled (a4da594 or a reviewed successor). PatchBrief internally uses fixed shell command strings; its process alone receives `--allow-shell-exec`. ChangeBucket uses structured process argv. No host tool accepts shell commands. No filesystem write capability is granted to the child Kujo programs.

This is **trusted local execution only**. The executable path, checkout, Git directory and local machine must remain operator-controlled. Configuration checks are not atomic with Git execution and are not a sandbox. A hostile concurrent local actor, executable replacement, unusual Git configuration, or compromised dependencies require an isolated snapshot/provider. Do not expose this pack remotely or describe it as safe for arbitrary uploaded repositories. Credential-bearing configuration and raw child diagnostics are never returned. Source integrity and repository authorization remain application responsibilities.

Run `KUJO_BIN=/absolute/kujo node tests/repository_review.mjs` from Ability with sibling PatchBrief and ChangeBucket checkouts. The integration test uses a disposable Git repository, executes both real CLIs through canonical Ability, verifies changed-file results, and rejects executable-filter configuration for both. Ordinary core tests remain independent of optional product checkouts.

## Optional release signals

Supply an operator-controlled `shipcheck` checkout and `revisions["shipcheck.kujo"]` to add `kujo.shipcheck.repository.scan@1.0.0`. Existing configurations still expose exactly the original two definitions. The published ShipCheck JSON schema is loaded without modification. Its fixed `scan --dir <configured repository> --format json` command receives shell capability only for its quoted Git repository detection helper. It shares the same configuration guard and local trust restrictions.

A scan with `summary.gate_passed = 0` is a successful observation of failing readiness checks, not an execution error or release approval. ShipCheck does not run test suites, linters, builds, artifact verification or publishing. Its output must be combined with independently executed evidence before a release decision. No model-supplied path or command is accepted.

Run the same integration test with `KUJO_REVIEW_RELEASE=1` and a sibling ShipCheck checkout to verify all three real CLIs, including a successful scan whose domain gate fails, and three executable-filter rejections.
