# Tribunal 1.0.0 release-owner checklist

Tribunal 1.0.0 is a stable local or operator-controlled decision-evidence engine. This checklist does not certify hosted, regulated, multi-tenant, shared-filesystem, identity-provider, remote-custody, or organization-specific deployments. Those environments require their own controls and certification.

The release owner must use the exact candidate revision, Kujo runtime revision, commands, evidence paths, and results recorded below. An unchecked item is not complete.

## Candidate identity

- Product version: `1.0.0`
- Application-source candidate: `1ceed3010c9c554fb9d44b8e38c91f9c998b80fb`, reviewed and merged in [PR #1](https://github.com/kujolang/tribunal/pull/1). The `v1.0.0` tag points to the later reviewed release-policy merge on `main`, which changes release automation and documentation but not application logic.
- Kujo runtime: `1.0.0` at `9b77dce592047121cb71066629836ad89252f3ce`
- Local macOS x86_64 runtime SHA-256: `a8175b084398a1623cf24cabb6aafb05f316cd6b15eb5e2015089501dd9d8215`; architecture-specific CI digests are in the platform receipts.
- API version: `1.0.0` (independent contract)
- Evidence/schema format versions: independently versioned; see [v1 compatibility](V1_COMPATIBILITY.md)

## Exact-candidate verification status

- [x] Focused checks pass at the final `main` candidate: version, doctor, source check, main tests, CLI integration, schema gate, and `git diff --check`.
- [x] The complete release-workflow gate inventory passes at that exact commit with unchanged thresholds; the transparent local contention incident and unchanged successful Eval rerun are recorded in [the exact-candidate evidence record](RELEASE_EVIDENCE_1.0.0.md), and hosted run `31341698867` passed the inventory without a retry on all three platforms.
- [x] Local Markdown links and ShipCheck `scan`/`gate` pass with 16/16 checks and zero warnings.
- [x] Two independent deterministic source-archive builds match at SHA-256 `75cdbe279129f2a5d7a251c9887c8e5de74374f4846811383f353d2200061802`; SHA256SUMS, SPDX SBOM, in-toto provenance, receipt, manifest, normalized inventory and modes, and extracted-package happy/failure smoke checks pass.
- [x] Fresh Workcell success `wc-8994612bfc1549c8939c0347354221f9` and intentional workload failure `wc-22bd739ba3234f778849db21fcf0e10b` manifests verify at that exact commit with image digest `sha256:fc82e1cfb39c617057555ba4069cd64b8d0f7388a39fb748a0709427d61bf5e7` and the pinned Kujo revision label.
- [x] Fresh hosted receipts pass for Linux x86_64, macOS x86_64, and macOS arm64 at that exact commit in run `31341698867`.
- [x] The exact-candidate evidence record is committed through a follow-up reviewed PR without changing the candidate's application source.

The final evidence root is `/Users/robertdevore/2026/Kujolang/kujo-repos/.tribunal-release-v1/1ceed30/`. It is local release-owner evidence and is intentionally outside the package repository. Historical receipts for `8b476e51c5bc219608c8d9fae3bebdb9101e9462`, later branch commits, and 0.7.0 do not satisfy these items.

The follow-up record must name every command and result, archive checksum, Workcell run and image digest, hosted run and job IDs, platform artifact names, and external blocker. No item above may be checked from older evidence.

## External infrastructure requirements

- [x] The self-hosted GitHub Actions runner labelled `self-hosted, kujo` exists and exposes the pinned Kujo binary through `KUJO_BIN`.
- [x] Every current pinned integration repository and exact revision is public and readable by the workflow's scoped `github.token`; `KUJO_ECOSYSTEM_TOKEN` is therefore optional for the present matrix. Run `31341698867` proved the fallback and any inaccessible future pin still fails closed.
- [x] Release signing is optional: a configured `TRIBUNAL_SIGNING_PROVIDER_CONFIG` adds signed evidence, while an absent provider preserves the required reproducible package, checksums, SBOM, provenance, smoke verification, and receipt.
- [x] GitHub Actions run `31341698867` from the final `main` candidate completes the measured platform matrix and retains the three immutable receipt artifacts named in [measured platform support](PLATFORM_SUPPORT.md).
- [x] `main` branch protection and the human-reviewed `release` environment are configured and verified by a repository administrator.

Missing external infrastructure must have a blocker receipt. A substitute local run may narrow risk, but it is not the unavailable certification.

The exact blocker receipt belongs under the final evidence root and must record repository administration, runner, credential-name, and signing-provider facts without exposing credentials.

The current receipt is `.tribunal-release-v1/1ceed30/external-blockers.json`. Exact administrator-ready controls and commands are in [release administration](RELEASE_ADMINISTRATION.md).

## Deployment-specific certification

- [ ] The target operator certifies identity, authorization, storage, remote-custody, shared-filesystem, HSM/KMS, network, retention, backup, disaster recovery, observability, and incident-response controls that apply to its deployment.
- [ ] Live-provider behavior is tested only with explicit credential authorization and target-specific data-handling controls.
- [ ] Any platform not listed as supported in [measured platform support](PLATFORM_SUPPORT.md) is certified before use.

These items are outside the general Tribunal 1.0.0 local contract and cannot be pre-completed for every deployment.

## Independent review requirements

- [ ] The commissioned independent security review is completed and its verifiable report or attestation is linked in the security review register.
- [ ] Any findings are dispositioned under the published vulnerability and release policy.

Until this is complete, Tribunal may be released only with the documented local/operator-controlled boundary. Do not describe the independent review as completed.

## Reserved for the release owner

- [ ] Confirm the candidate commit is the intended immutable release source.
- [x] Decide the signing posture: this local/operator-controlled release proceeds without optional signed evidence and makes no signer-backed provenance claim.
- [ ] Create and push the `v1.0.0` tag.
- [ ] Run the tag-triggered release workflow and validate uploaded artifacts.
- [ ] Publish the package or public GitHub release only after verification.
- [x] No signing, notarization, or live-provider action is required for the documented local/operator-controlled release profile.

No release-preparation task may create the tag, sign, notarize, publish, or use live provider credentials.

## Workcell command template

```bash
export DOCKER_HOST=unix:///Users/robertdevore/.colima/kujo-workcell/docker.sock
export DOCKER_CONFIG=/tmp/kujo-next-batch-docker-config
export TMPDIR=/Users/robertdevore/2026/Kujolang/kujo-repos/.workcell-host-tmp
docker build --platform linux/amd64 \
  --build-arg KUJO_BASE_IMAGE=kujolang/workcell-kujo:tribunal-v1-9b77dce \
  --label org.opencontainers.image.revision=9b77dce592047121cb71066629836ad89252f3ce \
  -t kujolang/workcell-kujo:tribunal-v1.0.0-9b77dce \
  -f docs/workcell-runtime.Dockerfile .
KUJO=../kujo/target/release/kujo ../workcell/bin/workcell run \
  --file docs/workcell-launch-gate.json --repo . --no-pull
KUJO=../kujo/target/release/kujo ../workcell/bin/workcell verify \
  --run .workcell/runs/<run-id> --json
```

The completed record must identify the image digest and prove that its `org.opencontainers.image.revision` is the pinned Kujo revision.
