# Dispatch Benchmarks

Reproducible, offline performance harnesses for Dispatch. Numbers are
hardware-dependent; treat them as relative regression signals, not absolute SLAs.

## Run throughput

Times end-to-end execution of the fixture-backed `research-report` workflow
(9 steps, 1 approval gate, 1 retry probe).

```bash
export DISPATCH_OFFLINE_FIXTURE=true
kujo run tests/benchmarks/run_throughput.kujo 10   # 10 iterations (default)
```

Output reports total wall time, average per-run latency, and runs/sec.

### Interpreting results

- The offline path short-circuits fixture model calls in-process, so benchmark
  results are dominated by Dispatch orchestration, persistence, and trace/report
  artifact work rather than external provider or bridge subprocess latency.
- To benchmark pure orchestration cost, point `AI_SDK_PATH` at a fast local
  stub or compare relative numbers across changes on the same machine.

### Recording a baseline

Capture a baseline on your reference hardware and commit it alongside changes
that affect the hot path (runner, state persistence, trace handling):

```text
# Example shape (values are machine-specific):
Iterations: 10
Total wall time (ms): <T>
Average per-run latency (ms): <T/10>
Throughput (runs/sec): <10000/T>
```

## Release gate sharding

`tests/dispatch_tests.kujo` is intentionally broad and includes many child CLI
smoke checks. Use the release gate for blocking validation:

```bash
export KUJO_BIN=kujo
bash scripts/run_release_gate.sh
```

The script keeps the monolithic test file as the source contract, generates
temporary shards under `tests/tmp/dispatch-test-shards/`, and runs each shard
separately so slow paths are visible by shard instead of turning the whole suite
into one opaque timeout. The default shard count is 24 and can be overridden
with `DISPATCH_TEST_SHARDS=<count>`.

## Index write amplification

Per-step `running` status updates no longer rewrite the full run-index catalog
(`.dispatch-run-index.json`); the index is refreshed at creation and on each
non-`running` status transition. This bounds index writes per run to O(1)
regardless of step count. For very large catalogs, isolate workloads with a
dedicated `--output-root` per service so index writes stay small.

## Focused hardening workloads

```bash
kujo run tests/benchmarks/redaction.kujo
kujo run tests/benchmarks/webhook_sink.kujo
```

The redaction workload processes 200 nested objects and reports elapsed time,
output bytes, and a deterministic output hash. The sink workload appends 200
fixed events to a freshly seeded 1 MiB file and verifies the final size. Both
reset their input per invocation; neither uses provider calls. Compare the same
runtime and machine, and retain raw results when changing these paths. Timing
is evidence, not a blocking CI threshold. Update workload expectations only
when intentionally changing their documented inputs or output contracts.

The release gate now prints one receipt per suite and keeps full runner output
under `tests/tmp/dispatch-test-shards/logs/`. Set `DISPATCH_TEST_VERBOSE=true`
to also print passing logs. Failures retain the full log and print its last 80
lines. This changes verification-script verbosity, not Dispatch CLI output.

The throughput harness exits nonzero if any requested run does not complete.
Its existing output fields are retained, so a failure cannot look like a passing
performance check merely because timing numbers were printed.

An additional local fixture soak of 100 research-report runs completed 100/100
on 2026-09-22 using pinned Kujo 1.4.0. Elapsed wall time was 2,249,762 ms
(22,497 ms per run) on a heavily contended development host. This is a
completion regression check, not a provider test or performance SLA;
the output directory also contains older, unrelated run artifacts.

## Run catalog, state, and trace scale

Run `KUJO_BIN=kujo bash tests/benchmarks/measure_state_scale.sh` on each target
platform. It records three independent samples per size, measures peak resident
memory with the platform's `time` utility, and leaves raw evidence under
`tests/tmp/state-scale.*` (ignored by git). The large case writes 50 runs with
262,144-character input payloads; the small case writes five 128-character
payloads. Trace payloads are capped at 2,400 characters and eight events.

On the local macOS reference machine with Kujo 1.4.0, 2026-09-22:

| Case | Wall time, three runs | Peak RSS, three runs | Last state | Last trace | Run index |
| --- | --- | --- | --- | --- | --- |
| 5 × 128 chars | 2.712 / 2.911 / 3.126 s | 31.7 / 33.0 / 33.1 MB | 20,096 B | 1,065 B | 2,027 B |
| 50 × 262,144 chars | 32.872 / 31.543 / 34.979 s | 42.5 / 44.5 / 42.7 MB | 548,734 B | 5,668 B | 19,797 B |

These are development measurements, not production throughput or memory
guarantees. Choose a per-run input/output budget and disk capacity for the
deployment, cap traces with `DISPATCH_TRACE_MAX_EVENTS` and
`DISPATCH_TRACE_MAX_PAYLOAD_CHARS`, and alert using `doctor` and
`DISPATCH_STATE_MAX_BYTES` (default 5 MiB). Keep output roots partitioned by
service so the index and directory scan do not grow without operational review.

`cleanup --apply` is lossless logical retention: it writes a tombstone and
removes the catalog entry but deliberately keeps run artifacts for recovery.
It does **not** reclaim disk space. Dry-run and completed-status selection
should be reviewed before applying cleanup; archive and physically purge only
after an independently approved retention and backup policy. Do not rotate or
truncate run state/trace files in place: that would break resume and audit.
